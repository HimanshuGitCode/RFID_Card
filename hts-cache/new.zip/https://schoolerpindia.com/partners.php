<!DOCTYPE html>
<html lang="en">
<head>
	
	 <title>School ERP India Software in India Is The Best ERP Software, School Management Software, ERP For Schools in India, India by School ERP, School Software!</title>
<meta name="description" content="School ERP India is an online educational solution for all educational organization including engineering college, medical college, technical college, management college. School ERP is the best software for Schools, Colleges, Engineering Colleges, Management Colleges, Medical Colleges, Degree College, best online educational software for college in india. School ERP College ERP provides modules like Student Management, admission module, fee module, Timetable Management, Director and Principal Module, Library Management, stock module, HR Module, Transport Module, Hostel Module" />
<meta name="keywords" content="School ERP, ERP Solutions Education, ERP for School, Kids School ERP Software, School Management, School ERP System, School Management Software, School ERP Software in India, ERP School" />
<meta name="author" content="School ERP, vaibhav@schoolerpindia.com">
<meta name="revisit-after" content="7 days">
<meta name="og:title" content="School ERP Software in India Is The Best ERP Software, School Management Software, ERP For Schools in India, India by School ERP, School Software!"/>
<meta name="og:type" content="School ERP India"/>
<meta name="og:url" content="http://schoolerpindia.com/index.php"/>
<meta name="og:image" content="https://schoolerpindia.com/images/bg/1.jpeg"/>
<meta name="og:site_name" content="SchoolERPIndia"/>
<meta name="og:description" content="School ERP India is an online educational solution for all educational organization including engineering college, medical college, technical college, management college"/>
<meta name="og:email" content="vaibhav@schoolerpindia.com"/>
<meta name="og:phone_number" content="+91 9893070156"/>


<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<meta name="facebook-domain-verification" content="9izle3q4o4hajikcrolaty9ogahzq7" />
<script async src="https://cdn.ampproject.org/v0.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-130825364-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-130825364-1');
</script>
	<link href="images/favicon.png" rel="shortcut icon" type="image/png">
	<!-- Main Stylesheet -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
		<link rel="stylesheet" href="css/slide.css">
    <link rel="stylesheet" href="css/animate.css">
	<!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
	<link rel="stylesheet" href="css/custom-animation.css">
	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/meanmenu.min.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.js"></script>
 
</head>

<body>
	<!-- Preloader Start -->
	<!--<div class="preloader"></div>-->
	<!-- Preloader End -->
	<!-- header Start -->
	
	 	<header class="header-style-two" style="height: 98px ;">
		<div class="header-wrapper">
			<div class="header-top-area bg-gradient-color d-none d-lg-block">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 header-top-left-part">
						
							<marquee><span class="address"><i class="webexflaticon flaticon-phone"></i> +91-9893070156, +91-6269048888 </span><span class="phone"><i class="webexflaticon flaticon-send"></i> info@schoolerpindia.com </span></marquee>
							<!-- somu28/10/2023 -->
						</div>
						<div class="col-lg-6 header-top-right-part text-right">
							
						<ul class="social-links">
                                	<li><a href="https://www.facebook.com/schoolerps"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="https://www.youtube.com/channel/UCglZwT9PYeAPTKg6rUhQiFA"><i class="fab fa-youtube"></i></a></li>
							</ul>
							
						<div class="language">
								<a href="school-erp-demo.php"><i class="webexflaticon flaticon-man"></i> Free Demo</a>								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="bt_blank_nav"></div>
			<div class="header-navigation-area two-layers-header header-middlee bt_stick bt_sticky ">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<a class="navbar-brand logo f-left mrt-0 mrt-md-0" href="index.php"><!-- somu28/10/2023 -->
								<img id="logo-image" class="img-center" src="images/logo.png" alt="">
							</a>
							<div class="mobile-menu-right"></div>
							<div class="header-searchbox-style-two d-none d-xl-block">
								<div class="side-panel side-panel-trigger text-right d-none d-lg-block">
									<span class="bar1"></span>
									<span class="bar2"></span>
									<span class="bar3"></span>
								</div>
								<div class="show-searchbox">
									<a href="#"><i class="webex-icon-Search"></i></a>
								</div>
								<div class="toggle-searchbox">
									<form action="#" id="searchform-all" method="get">
										<div>
											<input type="text" id="s" class="form-control" placeholder="Search...">
											<div class="input-box">
												<input type="submit" value="" id="searchsubmit"><i class="fas fa-search"></i>
											</div>
										</div>
									</form>
								</div>
							</div>
							<div class="side-panel-content">
								<div class="close-icon">
									<button><i class="webex-icon-cross"></i></button>
								</div>
								<div class="side-panel-logo mrb-30">
									<a href="index.php">
										<img src="images/logo.png" alt="" />
									</a>
								</div>
								<div class="side-info mrb-30">
									<div class="side-panel-element mrb-25">
										<h4 class="mrb-10">Office Address</h4>
										<ul class="list-items">
											<li><span class="fa fa-map-marker-alt mrr-10 text-primary-color"></span>D-218 Old Minal, J.K. Road Bhopal Madhya Pradesh, INDIA.</li>
											<li><span class="fas fa-envelope mrr-10 text-primary-color"></span>info@schoolerpindia.com</li>
											<li><span class="fas fa-phone-alt mrr-10 text-primary-color"></span>+91 7987535570 </li>
										</ul>
									</div>
									
									<body>
<header>
      <div id="carousel" class="carousel slide" data-ride="carousel" style="">
        <ol class="carousel-indicators" style="display: none;">
          <li data-target="#carousel" data-slide-to="0" class="active"></li>
          <li data-target="#carousel" data-slide-to="1"></li>
          <li data-target="#carousel" data-slide-to="2"></li>
        </ol>

        <div class="carousel-inner" role="listbox">
		
		 <!-- <div class="carousel-item active" data-background="images/bg/erp_banner.png" style="background-image: url('images/bg/erp_banner.jpg'); background-size: contain;">somu 28/10/2023-->
      <!-- <div class="carousel-item active" data-background="images/bg/erp_banner.png" style="background-image: url('images/bg/erp_banner.jpg'); background-size: contain;"> -->
        <div class="carousel-item active" data-background="images/bg/erp_banner2.gif" style="background-image: url('images/bg/erp_banner2.gif'); background-size: contain;">
            <div class="caption">
              <button class="book_demobtn" style=""><a href="https://api.whatsapp.com/send/?phone=916269028888&text=I feel good about SCHOOL ERP INDIA. Please help me to%C2%A0know%C2%A0more?" target="_blank"style="color:transparent;">Book Demo</a></button>
             <!-- <h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
            </div>
          </div>

           
          <div class="carousel-item" style="background-image: url('images/bg/erp_banner4.webp'); background-size: contain;">
            <div class="caption">
             <!--  <h1 style="color:black">Create and share your whatever</h1>
              <h2 style="color:black">Make it easy for you to do whatever this thing does.</h2> -->
              <!-- <button><a href="#">Book Demo</a></button>--> <!-- somu 28/10/2023 --> 
              <button class="book_demobtn"style="">
   
    
    <a href="https://api.whatsapp.com/send/?phone=916269028888&text=I feel good about SCHOOL ERP INDIA. Please help me to%C2%A0know%C2%A0more?" target="_blank"style="color:transparent;">Book Demo</a></button>
            </div>
          </div>
          <style>
            .book_demobtn{
              position:relative;
    left: -443px;
    bottom: -138px;
    font-size: 35px;
    font-weight: 800;
    pointer:cursor;
    color: white !important;
    background: none;
            }

      @media(max-width:600px){
        .book_demobtn{
          position:absolute !important;
          left: -73px !important;
          bottom: -25px !important;
        }
      }
    </style>
		      
<!-- somu 28/10/2023 -->
	     <!--  <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
           <!--  </div>
          </div>

          <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
          <!--   </div>
          </div>

          <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
            <!-- </div>
          </div> -->
 


        </div>
        
        <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
          <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
          <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
          <span class="sr-only">Next</span>
        </a>

      </div>
    </header>
    <style >
       @media (max-width: 740px){
   .carousel-inner {
    padding-top: 52.25%;
    display: block;
    content: "";
}
}
    </style>
</body>									
								</div>
								<h4 class="mrb-15">Social List</h4>
								<ul class="social-list">
									<li><a href="#"><i class="fab fa-facebook"></i></a></li>
									<li><a href="#"><i class="fab fa-twitter"></i></a></li>
									<li><a href="#"><i class="fab fa-instagram"></i></a></li>
									<li><a href="#"><i class="fab fa-google-plus"></i></a></li>
								</ul>
							</div>
							<div class="main-menu f-right fff">
								<nav id="mobile-menu-right">
									<ul>
									<li><a href="index.php">Home</a></li>
										   <li class="has-sub">
											<a href="#">Modules/Services</a>
											<ul class="sub-menu">
<li><a href="admission-management.php">Admission Management</a></li>
<li><a href="student-management.php">Student Management</a></li>
<li><a href="fees-management.php">Fee Management</a></li>
<li><a href="attendance-management.php">Attendance Management</a></li>
<li><a href="academics-management.php">Academic Management</a></li>
<li><a href="exam-management.php">Examination Management</a></li>
<li><a href="online_exam.php">Online Examination</a></li>
<li><a href="hr-management.php">HR  Management</a></li>
<li><a href="learning_management.php">Learning Management</a></li>
<li><a href="inventory_management.php">Inventory Management</a></li>
<li><a href="transport-management.php">Transport Management</a></li>
<li><a href="alumni_management.php"> Alumni management</a></li>
<li><a href="followup_management.php">Followup Management</a></li>
</ul>
										</li> 
										
<li class="has-sub">
<a href="#">Integrations</a>
	<ul class="sub-menu">
<li><a href="attendance-machine.php">Attendance Machine</a></li>
<!--<li><a href="bus-tracking.php">Bus Tracking</a></li>-->
<li><a href="payment-gateway.php">Payment Gateway</a></li>
<li><a href="sms-gateway.php">SMS/Whatsup Gateway</a></li>
<li><a href="rfid-card.php">RFID Card</a></li>
<li><a href="bulk-email.php">Bulk Email</a></li>
<li><a href="fee-via-dynamic-qr-code.php">Fee Via Dynamic QR Code</a></li>
<li><a href="googlemeet-zoom.php">Google Meet/Zoom/Webex </a></li>
</ul>									
										
										
										
										</li>
																			
										<li><a href="dynamic_website.php">Website</a></li>
										<li><a href="mobileapp.php">Mobile App</a></li>
											<li><a href="pricing.php"> Pricing  </a></li>
									
										<!-- <li><a href="demo-videos.php"> Demo Videos </a></li> -->
										<li><a href="partners.php"> Partners </a></li>
										
										<li><a href="school-erp-demo.php">  Demo  </a></li>
										<li><a href="client.php"> Clients  </a></li>
									
										 
										
										<!--<li><a href="page-pricing.php">Pricing</a></li>
										
										<li class="has-sub right-view">
											<a href="#">Clients</a>
											<ul class="sub-menu">
												<li><a href="page-news.php">News Classic</a></li>
												<li><a href="page-news-left-sidebar.php">News Left Sidebar</a></li>
												<li><a href="page-news-right-sidebar.php">News Right Sidebar</a></li>
												<li><a href="page-single-news.php">Single News</a></li>
											</ul>
										</li>-->
										<li><a href="contact-us.php">Contact Us</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>		
	<!-- header End -->
  
	<!-- Page Title Start -->
	<section class="page-title-section">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 text-center">
					<div class="page-title-content">
						<h3 class="title text-#755fdb">Become a Partner</h3>
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="index.php">Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">Become a Partner</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Page Title End -->
	<!-- Contact Section Start -->
	<section class="contact-section pdt- pdb-70 pdb-lg-90" data-background="images/bg/abs-bg1.png">
		<div class="container">
			<div class="row mrb-">

                        <div class="col-md-6 how-img">
                            <img src="images/about/partners.jpg" class="rounded-circle img-fluid" alt=""/>
                        </div>
                        <div class="col-md-6">
                            <h4>Let's Join Hands</h4>
                                        <h4 class="subheading"></h4>
                        <p class="text-muted">We want our partners to be trusted solution providers for their customers. Our partnerships program is open to any organization or individual that shares our passion for customers.<br><br>
                        	With flexible terms, packages and affordable pricing offer additional revenue streams to your business.<br><br>We are always open to have new partners in our network.</p>
                        </div>
			</div>

<style>
	.how-section1{
    margin-top:-15%;
    padding: 10%;
}
.how-section1 h4{
    color: #ffa500;
    font-weight: bold;
    font-size: 30px;
}
.how-section1 .subheading{
    color: #3931af;
    font-size: 20px;
}
.how-section1 .row
{
/*    margin-top: 10%;*/
}
.how-img 
{
    text-align: center;
}
.how-img img{
    width: 73%;
}
</style>
		</div>
	</section>
	<section class="contact-section pdt-70 pdb-70 pdb-lg-90" data-background="images/bg/abs-bg1.png">
		<div class="container">
			<div class="row mrb-90 ">
				<div class="col-lg-6 col-xl-3 box2">
					<div class="contact-block  mrb-30 ">
						<i class="fa-solid fa-star" style="color: #17315e; font-size: 40px; margin-bottom: 15px;"></i><br>
						<h4>Reputed Business</h4>
						
					</div>
				</div>

				<div class="col-lg-6 col-xl-3 box2">
					<div class="contact-block  mrb-30">
						<i class="fa-solid fa-indian-rupee-sign" style="color: #17315e;font-size: 40px; margin-bottom: 15px;"></i><br>

						<h4>Lifetime Revenue</h4>
					</div>
				</div>
				<div class="col-lg-6 col-xl-3 box2">
					<div class="contact-block mrb-30">
						<i class="fa-solid fa-headset" style="color: #17315e;font-size: 40px; margin-bottom: 15px;"></i><br>

						<h4>365 Days Support</h4>
					</div>
				</div>
				<div class="col-lg-6 col-xl-3 box2">
					<div class="contact-block mrb-30">
						<i class="fa-solid fa-road" style="color: #17315e;font-size: 40px; margin-bottom: 15px;"></i><br>
						<h4>Work Anywhere	</h4>
					</div>
				</div>
			</div>
			
				<p style="text-align: center;margin: 0 0 0px;line-height: normal;">We Care For You</p>
				<h5 style="text-align: center; margin-bottom: 40px;line-height: normal;">Partnership Benefits</h5>
				<!-- <div class="row mrb-90">
				<div class="col-lg-6 col-xl-6">
					<ul>
						<li><span style="margin-right:4px"><i class="fa-solid fa-star" style="color: #17315e;"></i></span>Maximize your Profits and Growth.</li><br>
						<li><span style="margin-right:4px"><i class="fa-solid fa-star" style="color: #17315e;"></i></span>Be Flexible with Deployment Schemes & Payment plans.</li><br>
						<li><span style="margin-right:4px"><i class="fa-solid fa-star" style="color: #17315e;"></i></span>Get access to our sales and Marketing Resources.</li><br>
						<li><span style="margin-right:4px"><i class="fa-solid fa-star" style="color: #17315e;"></i></span>Grow with our Education and Presales support.</li><br>
					</ul>
				</div>

				<div class="col-lg-6 col-xl-6">
					<ul>
						<li><span style="margin-right:4px"><i class="fa-solid fa-star" style="color: #17315e;"></i></span>Unlimited Training Regarding Sales and Technical Part.</li><br>
						<li><span style="margin-right:4px"><i class="fa-solid fa-star" style="color: #17315e;"></i></span>An Experienced Account Manager to cater your account.</li><br>
						<li><span style="margin-right:4px"><i class="fa-solid fa-star" style="color: #17315e;"></i></span>Attractive Lifetime Revenue Stream.</li><br>
						<li><span style="margin-right:4px"><i class="fa-solid fa-star" style="color: #17315e;"></i></span>Work Anytime Anyday Anywhere in India.</li><br>
					</ul>
				</div>
			</div> -->
			<!-- <div class="row mrb-90">
				<div class="col-lg-12 col-xl-12 d-flex mrb-25" style="justify-content: space-between;">
				   <div class="col-lg-3 col-xl-2 d-flex part"style="justify-content: Center;flex-direction: column; flex-wrap: wrap;">
					   <div class="center_content cir mrb-10" ></div>
					   <div class="center_content"><h5>content</h5></div>
				   </div>
				   <div class="col-lg-2 col-xl-2 d-flex part" style="justify-content: Center;flex-direction: column;flex-wrap: wrap;">
				   	   <div class="center_content cir mrb-10"></div>
				   	   <div class="center_content"><h5>content</h5></div>
				   </div>
				   <div class="col-lg-2 col-xl-2 d-flex part" style="justify-content: Center;flex-direction: column;flex-wrap: wrap;">
				   	  <div class="center_content cir mrb-10"></div>
				   	  <div class="center_content"><h5>content</h5></div>
				   </div>
				   <div class="col-lg-2 col-xl-2 d-flex part" style="justify-content: Center;flex-direction: column;flex-wrap: wrap;">
				   	  <div class="center_content cir mrb-10"></div>
				   	  <div class="center_content"><h5>content</h5></div>
				   </div>
				</div>
			</div> -->

			<div class="row mrb-90 ">
				<div class="col-lg-6 col-xl-3 box1" >
					<div class="contact-block  mrb-30 d-flex part" style="justify-content: center;flex-direction: column;padding-top:42px;">
						<div class="center_content cir mrb-20" ><img src="images/partners/Profits.png " style=""></div>
						<h5 class="text1"style="padding:0px 20px 20px 20px;">Maximize your Profits and Growth.</h5>
						
					</div>
				</div>

				<div class="col-lg-6 col-xl-3 box1">
					<div class="contact-block  mrb-30 d-flex part" style="justify-content: center;flex-direction: column;padding-top:42px;">
						<div class="center_content cir mrb-20" ><img src="images/partners/Payment plane.png "></div>
						<h5 class="text1" style="padding:0px 20px 20px 20px;">Be Flexible with Deployment Schemes & Payment plans.</h5>
					</div>
				</div>
				<div class="col-lg-6 col-xl-3 box1">
					<div class="contact-block mrb-30 d-flex part" style="justify-content: center;flex-direction: column;padding-top:42px;">
						<div class="center_content cir mrb-20" ><img src="images/partners/Market_resource.png "></div>
						<h5 class="text1" style="padding:0px 20px 20px 20px;">Get access to our sales and Marketing Resources.</h5>
					</div>
				</div>
				<div class="col-lg-6 col-xl-3 box1">
					<div class="contact-block mrb-30 d-flex part" style="justify-content: center;flex-direction: column;padding-top:42px;">
						<div class="center_content cir mrb-20"><img src="images/partners/Pre_salessupport.png "></div>
						<h5 class="text1" style="padding:0px 20px 20px 20px;">Grow with our Education and Presales support.</h5>
					</div>
				</div>
				<div class="col-lg-6 col-xl-3 box1" >
					<div class="contact-block  mrb-30 d-flex part" style="justify-content: center;flex-direction: column;padding-top:42px;">
						<div class="center_content cir mrb-20" ><img src="images/partners/Anywhere_sales.png "></div>
						<h5 class="text1"style="padding:0px 20px 20px 20px;">Work Anytime Anyday Anywhere in India.</h5>
						
					</div>
				</div>

				<div class="col-lg-6 col-xl-3 box1">
					<div class="contact-block  mrb-30 d-flex part" style="justify-content: center;flex-direction: column;padding-top:42px; ">
						<div class="center_content cir mrb-20" ><img src="images/partners/Technical_part.png"></div>
						<h5 class="text1"style="padding:0px 20px 20px 20px;">Unlimited Training Regarding Sales and Technical Part.</h5>
					</div>
				</div>
				<div class="col-lg-6 col-xl-3 box1">
					<div class="contact-block mrb-30 d-flex part" style="justify-content: center;flex-direction: column;padding-top:42px;">
						<div class="center_content cir mrb-20" ><img src="images/partners/Account.png"></div>
						<h5 class="text1"style="padding:0px 20px 20px 20px;">An Experienced Account Manager to cater your account.</h5>
					</div>
				</div>
				<div class="col-lg-6 col-xl-3 box1">
					<div class="contact-block mrb-30 d-flex part" style="justify-content: center;flex-direction: column;padding-top:42px;">
						<div class="center_content cir mrb-20" ><img src="images/partners/Revenue_stream.png"></div>
						<h5 class="text1"style="padding:0px 20px 20px 20px;">Attractive Lifetime Revenue Stream.</h5>
					</div>
				</div>
			</div>





<p style="text-align: center;margin: 0 0 0px;line-height: normal;">Start Your Journey Today!</p>
				<h5 style="text-align: center; margin-bottom: 40px;line-height: normal;">Let's Become A Partner</h5>
			<div class="row d-flex" style="justify-content: center;">
				<div class="col-lg-7 col-xl-7">
					<div class="contact-form">
										
											 

						<form   action="https://schoolerpindia.in/vcrm/web_partners1.php" >
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group mrb-25">
										<input type="text" placeholder="Name" name="name" required class="form-control">
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group mrb-25">
										<input type="text" placeholder="Phone" required  name="phone" class="form-control">
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group mrb-25">
										<input type="text" placeholder="City" name="city" required class="form-control">
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group mrb-25">
										<input type="text" placeholder="Occupation" required  name="occupation" class="form-control">
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group mrb-25">
										<input type="text" placeholder="Firm Name" required  name="firm_name" class="form-control">
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group mrb-25">
										<input type="text" placeholder="State" name="state" required class="form-control">
									</div>
								</div>
								
								<div class="col-lg-6">
									<div class="form-group mrb-25">
										<input type="email" placeholder="Email" required name="email" class="form-control">
									</div>
								</div>
								<div class="col-lg-6">
									<p style="line-height: 4px;padding-top: 6px;">Where do you know about us ?</p>
									<div class="form-group mrb-25">
										<select id="reference" name="reference"   >
                                            <option value="select" selected>Select</option>
                                            <option value="facebook">Facebook</option>
                                            <option value="Instagram">Email</option>
                                            <option value="Instagram">Instagram</option>
                                            <option value="x">X</option>
                                            <option value="youtube">Youtube</option>
                                            <option value="reference">reference</option>
                                            <option value="other">Others</option>
                                        </select>
									</div>
								</div>
								<input type="hidden" name="curl" value="https://schoolerpindia.com/partners.php" class="form-control">
								
								<div class="col-lg-12">
									<!--=============================== captcha start===================================== -->

    
                   
   <style>
   	select {
    box-shadow: none;
    outline: none;
    border: 1px solid #dfdce6;
    background: #EDF0F9;
    font-size: 16px;
    font-weight: 400;
/*    line-height: 24px;*/
    font-family: "Poppins", sans-serif;
    color: #17305e;
    height: auto;
/*    padding: 25px 20px;*/
    resize: none;
    min-width: 100%;
    height: 35px;
}
   	.part{
   		height: 280px;
   		background-color: #D5CFF4 !important;
   		transition: transform .2s;
/*   		box-shadow: 0px 4px 4px 0px rgba(0, 0, 0, 0.25) inset;*/

   	}
   	.part:hover{
   		transform: scale(1.1);
   	}

   	.cir{
   		height: 120px;
   		width:120px;
   		border-radius: 50%;
   		background:white;
   		filter: drop-shadow(0px 8px 8px rgba(0, 0, 0, 0.25));
   		display: flex;
   		justify-content: center;
   		align-items: center;
   	}
   	.cir img{
   		height:70px;width:70px;
   	}
        .hidden {
            display: none;
        }
        @media (max-width: 700px) {
        	.wid{
        		width:auto !important;
        	}
        	.wid2{

        		width:100% !important;
/*        		display: flex;*/
/*        		justify-content: center;*/
        	}
        	.wid3{
        		width:100% !important;
        		display: block !important;
/*        		justify-content: center;*/
        	}

        	
        }

        @media (max-width: 700px) {
        	.box1,.box2{
        		width:50% !important;
        	}
        	.cir{
        		display: none;
        	}
        	.part{
        		height: 200px;
        		padding-top: 17px !important;
        	}
        	.text1{
        		padding:0px 0px 0px 0px;

        	}
            
        }
    </style>   
  
  
  
  
   <div class="row"> 
  
                                    
     
                                   
                  <div class="col-md-2 wid">
                  
                   <label for="captcha">  Captcha: </label>
                  
                  </div>
                  
                  
                  <div class="col-md-2 wid" >
                  
                                      <h4  id="captchaInput2" style="font-size: 18px;margin: 0px;text-align: center;border: 1px solid #c1bdb8;padding: px;text-decoration: line-through;width: 75px;line-height: 25px;"  >   </h4>
                      
                                    </div> <br>
                   
                   
                   
                   <div class="col-md-1 wid">
                                      
                      <div class="single-form form-group">
                                        
                                           <input type="text" id="captchaInput" class="input--style-4"  required style="width:75px !important;">
                                           <span id="captchaError" style="color: red;"></span>
                                        </div> <!-- single form -->
                                    </div><br>
     
     </div><br>
     
     
       <div class="row col-lg-12 d-flex" style="justify-content:center; ">
        <button style="padding: 8px 8px !important;" type="submit" id="submitButton" class="hidden  cs-btn-one btn-md btn-round btn-primary-color element-shadow">Submit Now</button>
    
  </div>
                
                
                
     <script>
        // Generate a random 4-digit captcha
        const captcha = Math.floor(1000 + Math.random() * 9000);
        const captchaInput = document.getElementById("captchaInput");
        const captchaError = document.getElementById("captchaError");
        const submitButton = document.getElementById("submitButton");

        captchaInput.placeholder = captcha;
     captchaInput2.textContent = captcha;

        captchaInput.addEventListener("input", () => {
            const enteredCaptcha = parseInt(captchaInput.value);

            if (enteredCaptcha === captcha) {
                captchaError.textContent = "";
                submitButton.classList.remove("hidden");
            } else {
                captchaError.textContent = "Incorrect Captcha. Please try again.";
                submitButton.classList.add("hidden");
            }
        });
    </script>
            
                
  <!--=============================== captcha End===================================== -->	
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>

			 
		</div>
	</section>

	<section class="contact-section pdt- pdb- pdb-lg-90" data-background="images/bg/abs-bg1.png">
				<div class="" style="background-color:#c0b2ff; padding:30px 0px">
					<div class="container wid3 d-flex" style="">
					   <div class=" col-lg-8 wid2">
						   <h4>Want To Digitalize Your Organization?</h4>
					   	 <p style="margin:0 0 0">School / Institute / Coaching Centers / Tutors</p>
					   </div>
					   <div class="col-lg-3 wid2" style="margin-top:10px">
						   <button style="background: white; border-radius:20px; padding: 8px 13px;"><a href="brochure/brochure.pdf" download>Brochure<i class="fa-solid fa-download"></i></button>

					   </div>
					  
				  </div>
      </div>  
     
	</section>

	
	 <!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            call: "+919893070156", // Call phone number
            whatsapp: "+919893070156", // WhatsApp number
            call_to_action: "Message us", // Call to action
            button_color: "#FF6550", // Color of button
            position: "left", // Position may be 'right' or 'left'
            order: "whatsapp,call", // Order of buttons
        };
        var proto = 'https:', host = "getbutton.io", url = proto + '//static.' + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->


<!-- Footer Area Start -->
	<footer class="footer">
		<div class="footer-main-area" data-background="images/footer-bg.png">
			<div class="container">
				<div class="row">
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
						<!--	<img src="images/footer_logo.png" alt="" class="mrb-20">-->
							<address class="mrb-25">
								<p class="text-light-gray">D-326 New Minal,
Near Gate No.5, Bhopal <br/>Madhya Pradesh, INDIA.</p>
								<div class="mrb-10"><a href="#" class="text-light-gray"><i class="fas fa-phone-alt mrr-10"></i>+91 98930-70156 </a></div>
								<div class="mrb-10"><a href="#" class="text-light-gray"><i class="fas fa-envelope mrr-10"></i>info@schoolerpindia.com </a></div>
								<div class="mrb-0"><a href="#" class="text-light-gray"><i class="fas fa-globe mrr-10"></i>www.schoolerpindia.com</a></div>
							</address>
							<ul class="social-list">
								<li><a href= "https://www.facebook.com/schoolerps/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
								<!-- <li><a href="#"><i class="fa-brands fa-linkedin-in" target="_blank"></i></a></li> -->
								<li><a href="https://www.instagram.com/school_erp_india/" target="_blank"><i class="fab fa-instagram"></i></a></li>
								<li><a href="https://www.youtube.com/@schoolerpindia" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30"> School Solutions </h5>
							<ul class="footer-widget-list">
	 <li > <a   href="admission-management.php"> Online Admission / Enrollment</a> </li>
 <li ><a   href="student-management.php">Student Management</a> </li>
 <li ><a   href="fees-management.php">Fees Management</a> </li>
<li ><a   href="progress-card.php">Progress Card</a> </li>
<li ><a   href="alumni_management.php">Alumni Management  </a> </li>
							</ul>
						</div>
					</div>
					<!--<div class="col-xl-2 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Services</h5>
							<ul class="footer-widget-list">
								<li><a href="#">Home</a></li>
								<li><a href="#">About</a></li>
								<li><a href="#">Team</a></li>
								<li><a href="#">Service</a></li>
								<li><a href="#">News</a></li>
								<li><a href="#">Policy</a></li>
								<li><a href="#">Contact</a></li>
							</ul>
						</div>
					</div>
					<div class="col-xl-4 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Newsletter</h5>
							<p class="text-light-gray">Seamlessly visualize quality intellectual capital without superior collaboration and idea sharing listically</p>
							<input type="text" class="form-control" placeholder="Enter Your Email">
							<a href="#" class="cs-btn-one btn-gradient-color btn-sm has-icon mrt-20"><i class="webexflaticon flaticon-send"></i>Submit Now</a>
						</div>
					</div>-->
					
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Integrations</h5>
							<ul class="footer-widget-list">
								<li > <a   href="attendance-machine.php"> Attendance Machine  </a> </li>
<li ><a   href="payment-gateway.php">Payment Gateway </a> </li>
<li ><a   href="fee-via-dynamic-qr-code.php">Fee Via Dynamic QR Code   </a> </li>
<li ><a   href="sms-gateway.php">SMS/Whatsup Gateway  </a> </li>
<li ><a   href="googlemeet-zoom.php">Google Meet/Zoom/Webex</a> </li>
							</ul>
						</div>
					</div>
					
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30"> Our Services</h5>
							<ul class="footer-widget-list">
							<li><a href="dynamic_website.php">Dynamic Website</a></li>
								 
<li ><a   href="student-app.php">Student App</a> </li>
<li ><a   href="teacher-app.php">Teacher App</a></li>
<li ><a   href="admin-app.php">Admin App</a></li>
<li ><a   href="student-web-login.php">Student Web Login</a></li>
							</ul>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<div class="footer-bottom-area">
			<div class="container">
				<div class="row">
					<div class="col-xl-12">
						<div class="text-center">
							<span class="text-light-gray" style="float: left;" >Copyright � 2021 by <a class="text-primary-color" target="_blank" href="#"> School ERp India</a> | All rights reserved    </span>
			
			 <a class="text-primary-color" style="float: right;color: white;"    href="privace-policy.php"> 
      Privacy Policy | Terms of Service | Refund & Cancellation 
 </a>
			 
						</div>
						
						
						
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer Area End --> 
	
	<!-- Footer Area End -->
	<!-- BACK TO TOP SECTION -->
	<div class="back-to-top">
		<i class="fa fa-angle-up"></i>
	</div>
	<!-- Integrated important scripts here -->
	<script src="js/jquery.v1.12.4.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery-core-plugins.js"></script>
	<script src="js/main.js"></script>
	 <script type="text/javascript">
      function callback() {
        const submitButton = document.getElementById("submit-button");
        submitButton.removeAttribute("disabled");
      }
    </script>
</body>


</html>