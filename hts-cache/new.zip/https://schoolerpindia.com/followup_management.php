<!doctype html>
<html lang="en">
<!-- Basic Page Needs =====================================-->
<title>School ERP India Software in India Is The Best ERP Software, School Management Software, ERP For Schools in India, India by School ERP, School Software!</title>
<meta name="description" content="School ERP India is an online educational solution for all educational organization including engineering college, medical college, technical college, management college. School ERP is the best software for Schools, Colleges, Engineering Colleges, Management Colleges, Medical Colleges, Degree College, best online educational software for college in india. School ERP College ERP provides modules like Student Management, admission module, fee module, Timetable Management, Director and Principal Module, Library Management, stock module, HR Module, Transport Module, Hostel Module" />
<meta name="keywords" content="School ERP, ERP Solutions Education, ERP for School, Kids School ERP Software, School Management, School ERP System, School Management Software, School ERP Software in India, ERP School" />
<meta name="author" content="School ERP, vaibhav@schoolerpindia.com">
<meta name="revisit-after" content="7 days">
<meta name="og:title" content="School ERP Software in India Is The Best ERP Software, School Management Software, ERP For Schools in India, India by School ERP, School Software!"/>
<meta name="og:type" content="School ERP India"/>
<meta name="og:url" content="http://schoolerpindia.com/index.php"/>
<meta name="og:image" content="https://schoolerpindia.com/images/bg/1.jpeg"/>
<meta name="og:site_name" content="SchoolERPIndia"/>
<meta name="og:description" content="School ERP India is an online educational solution for all educational organization including engineering college, medical college, technical college, management college"/>
<meta name="og:email" content="vaibhav@schoolerpindia.com"/>
<meta name="og:phone_number" content="+91 9893070156"/>


<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<meta name="facebook-domain-verification" content="9izle3q4o4hajikcrolaty9ogahzq7" />
<script async src="https://cdn.ampproject.org/v0.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-130825364-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-130825364-1');
</script>
	<link href="images/favicon.png" rel="shortcut icon" type="image/png">
	<!-- Main Stylesheet -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
		<link rel="stylesheet" href="css/slide.css">
    <link rel="stylesheet" href="css/animate.css">
	<!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
	<link rel="stylesheet" href="css/custom-animation.css">
	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/meanmenu.min.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.js"></script>

<header class="header-style-two" style="height: 98px ;">
		<div class="header-wrapper">
			<div class="header-top-area bg-gradient-color d-none d-lg-block">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 header-top-left-part">
						
							<marquee><span class="address"><i class="webexflaticon flaticon-phone"></i> +91-9893070156, +91-6269048888 </span><span class="phone"><i class="webexflaticon flaticon-send"></i> info@schoolerpindia.com </span></marquee>
							<!-- somu28/10/2023 -->
						</div>
						<div class="col-lg-6 header-top-right-part text-right">
							
						<ul class="social-links">
                                	<li><a href="https://www.facebook.com/schoolerps"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="https://www.youtube.com/channel/UCglZwT9PYeAPTKg6rUhQiFA"><i class="fab fa-youtube"></i></a></li>
							</ul>
							
						<div class="language">
								<a href="school-erp-demo.php"><i class="webexflaticon flaticon-man"></i> Free Demo</a>								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="bt_blank_nav"></div>
			<div class="header-navigation-area two-layers-header header-middlee bt_stick bt_sticky ">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<a class="navbar-brand logo f-left mrt-0 mrt-md-0" href="index.php"><!-- somu28/10/2023 -->
								<img id="logo-image" class="img-center" src="images/logo.png" alt="">
							</a>
							<div class="mobile-menu-right"></div>
							<div class="header-searchbox-style-two d-none d-xl-block">
								<div class="side-panel side-panel-trigger text-right d-none d-lg-block">
									<span class="bar1"></span>
									<span class="bar2"></span>
									<span class="bar3"></span>
								</div>
								<div class="show-searchbox">
									<a href="#"><i class="webex-icon-Search"></i></a>
								</div>
								<div class="toggle-searchbox">
									<form action="#" id="searchform-all" method="get">
										<div>
											<input type="text" id="s" class="form-control" placeholder="Search...">
											<div class="input-box">
												<input type="submit" value="" id="searchsubmit"><i class="fas fa-search"></i>
											</div>
										</div>
									</form>
								</div>
							</div>
							<div class="side-panel-content">
								<div class="close-icon">
									<button><i class="webex-icon-cross"></i></button>
								</div>
								<div class="side-panel-logo mrb-30">
									<a href="index.php">
										<img src="images/logo.png" alt="" />
									</a>
								</div>
								<div class="side-info mrb-30">
									<div class="side-panel-element mrb-25">
										<h4 class="mrb-10">Office Address</h4>
										<ul class="list-items">
											<li><span class="fa fa-map-marker-alt mrr-10 text-primary-color"></span>D-218 Old Minal, J.K. Road Bhopal Madhya Pradesh, INDIA.</li>
											<li><span class="fas fa-envelope mrr-10 text-primary-color"></span>info@schoolerpindia.com</li>
											<li><span class="fas fa-phone-alt mrr-10 text-primary-color"></span>+91 7987535570 </li>
										</ul>
									</div>
									
									<body>
<header>
      <div id="carousel" class="carousel slide" data-ride="carousel" style="">
        <ol class="carousel-indicators" style="display: none;">
          <li data-target="#carousel" data-slide-to="0" class="active"></li>
          <li data-target="#carousel" data-slide-to="1"></li>
          <li data-target="#carousel" data-slide-to="2"></li>
        </ol>

        <div class="carousel-inner" role="listbox">
		
		 <!-- <div class="carousel-item active" data-background="images/bg/erp_banner.png" style="background-image: url('images/bg/erp_banner.jpg'); background-size: contain;">somu 28/10/2023-->
      <!-- <div class="carousel-item active" data-background="images/bg/erp_banner.png" style="background-image: url('images/bg/erp_banner.jpg'); background-size: contain;"> -->
        <div class="carousel-item active" data-background="images/bg/erp_banner2.gif" style="background-image: url('images/bg/erp_banner2.gif'); background-size: contain;">
            <div class="caption">
              <button class="book_demobtn" style=""><a href="https://api.whatsapp.com/send/?phone=916269028888&text=I feel good about SCHOOL ERP INDIA. Please help me to%C2%A0know%C2%A0more?" target="_blank"style="color:transparent;">Book Demo</a></button>
             <!-- <h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
            </div>
          </div>

           
          <div class="carousel-item" style="background-image: url('images/bg/erp_banner4.webp'); background-size: contain;">
            <div class="caption">
             <!--  <h1 style="color:black">Create and share your whatever</h1>
              <h2 style="color:black">Make it easy for you to do whatever this thing does.</h2> -->
              <!-- <button><a href="#">Book Demo</a></button>--> <!-- somu 28/10/2023 --> 
              <button class="book_demobtn"style="">
   
    
    <a href="https://api.whatsapp.com/send/?phone=916269028888&text=I feel good about SCHOOL ERP INDIA. Please help me to%C2%A0know%C2%A0more?" target="_blank"style="color:transparent;">Book Demo</a></button>
            </div>
          </div>
          <style>
            .book_demobtn{
              position:relative;
    left: -443px;
    bottom: -138px;
    font-size: 35px;
    font-weight: 800;
    pointer:cursor;
    color: white !important;
    background: none;
            }

      @media(max-width:600px){
        .book_demobtn{
          position:absolute !important;
          left: -73px !important;
          bottom: -25px !important;
        }
      }
    </style>
		      
<!-- somu 28/10/2023 -->
	     <!--  <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
           <!--  </div>
          </div>

          <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
          <!--   </div>
          </div>

          <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
            <!-- </div>
          </div> -->
 


        </div>
        
        <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
          <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
          <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
          <span class="sr-only">Next</span>
        </a>

      </div>
    </header>
    <style >
       @media (max-width: 740px){
   .carousel-inner {
    padding-top: 52.25%;
    display: block;
    content: "";
}
}
    </style>
</body>									
								</div>
								<h4 class="mrb-15">Social List</h4>
								<ul class="social-list">
									<li><a href="#"><i class="fab fa-facebook"></i></a></li>
									<li><a href="#"><i class="fab fa-twitter"></i></a></li>
									<li><a href="#"><i class="fab fa-instagram"></i></a></li>
									<li><a href="#"><i class="fab fa-google-plus"></i></a></li>
								</ul>
							</div>
							<div class="main-menu f-right fff">
								<nav id="mobile-menu-right">
									<ul>
									<li><a href="index.php">Home</a></li>
										   <li class="has-sub">
											<a href="#">Modules/Services</a>
											<ul class="sub-menu">
<li><a href="admission-management.php">Admission Management</a></li>
<li><a href="student-management.php">Student Management</a></li>
<li><a href="fees-management.php">Fee Management</a></li>
<li><a href="attendance-management.php">Attendance Management</a></li>
<li><a href="academics-management.php">Academic Management</a></li>
<li><a href="exam-management.php">Examination Management</a></li>
<li><a href="online_exam.php">Online Examination</a></li>
<li><a href="hr-management.php">HR  Management</a></li>
<li><a href="learning_management.php">Learning Management</a></li>
<li><a href="inventory_management.php">Inventory Management</a></li>
<li><a href="transport-management.php">Transport Management</a></li>
<li><a href="alumni_management.php"> Alumni management</a></li>
<li><a href="followup_management.php">Followup Management</a></li>
</ul>
										</li> 
										
<li class="has-sub">
<a href="#">Integrations</a>
	<ul class="sub-menu">
<li><a href="attendance-machine.php">Attendance Machine</a></li>
<!--<li><a href="bus-tracking.php">Bus Tracking</a></li>-->
<li><a href="payment-gateway.php">Payment Gateway</a></li>
<li><a href="sms-gateway.php">SMS/Whatsup Gateway</a></li>
<li><a href="rfid-card.php">RFID Card</a></li>
<li><a href="bulk-email.php">Bulk Email</a></li>
<li><a href="fee-via-dynamic-qr-code.php">Fee Via Dynamic QR Code</a></li>
<li><a href="googlemeet-zoom.php">Google Meet/Zoom/Webex </a></li>
</ul>									
										
										
										
										</li>
																			
										<li><a href="dynamic_website.php">Website</a></li>
										<li><a href="mobileapp.php">Mobile App</a></li>
											<li><a href="pricing.php"> Pricing  </a></li>
									
										<!-- <li><a href="demo-videos.php"> Demo Videos </a></li> -->
										<li><a href="partners.php"> Partners </a></li>
										
										<li><a href="school-erp-demo.php">  Demo  </a></li>
										<li><a href="client.php"> Clients  </a></li>
									
										 
										
										<!--<li><a href="page-pricing.php">Pricing</a></li>
										
										<li class="has-sub right-view">
											<a href="#">Clients</a>
											<ul class="sub-menu">
												<li><a href="page-news.php">News Classic</a></li>
												<li><a href="page-news-left-sidebar.php">News Left Sidebar</a></li>
												<li><a href="page-news-right-sidebar.php">News Right Sidebar</a></li>
												<li><a href="page-single-news.php">Single News</a></li>
											</ul>
										</li>-->
										<li><a href="contact-us.php">Contact Us</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
<body>
      <!-- End of Nav --> 
    
<!-- End of Header area -->
    <!-- Page Title Start -->
	<section class="page-title-section">
		<div class="container">
			<div class="row">
				<div class="col-xl-12 text-center">
					<div class="page-title-content">
						<h3 class="title text-white">
Followup management

</h3>
						<nav aria-label="breadcrumb">
							<ol class="breadcrumb">
								<li class="breadcrumb-item"><a href="index.php">Home</a></li>
								<li class="breadcrumb-item active" aria-current="page">
Followup management

</li>
							</ol>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Page Title End -->  
    
   <!-- Slider Area End -->
    
     
  


<section id="welcome-to">
  <div class="container">
    <div class="row text-center">
      <div class="col section-heading-15 wow fadeInDown" style="visibility: visible; animation-name: fadeInDown;">
        <h1 class="heading-titel">Followup     <span>   management</span></h1>
      </div>
    </div>
    <div class="row wow" >
      <div class="col-lg-12 ml-auto col-md-12">
	  
	  	    <div class="main-point-titel-blue">Tags Followup  </div>
			
			 <img src="softimages/tag-followup.png">
			<hr/><br/>
			  <img src="softimages/tag-followup-1.png">
			   <hr/><br/>
			   <img src="softimages/tag-followup-2.png">
         <br/>
	  	  	    <div class="main-point-titel-blue">Fees Followup  </div>
 <img src="softimages/fees-followup.png">
 	<hr/><br/>
 <img src="softimages/fees-followup2.png">
			<hr/><br/>
	   
	   <div class="main-point-titel-blue">Enquiry Followup  </div>
	   
	    <img src="softimages/enquiry-followup.png">
<br/>
	   
     </div>
        
    </div>
  </div>
</section>






<!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            call: "+919893070156", // Call phone number
            whatsapp: "+919893070156", // WhatsApp number
            call_to_action: "Message us", // Call to action
            button_color: "#FF6550", // Color of button
            position: "left", // Position may be 'right' or 'left'
            order: "whatsapp,call", // Order of buttons
        };
        var proto = 'https:', host = "getbutton.io", url = proto + '//static.' + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->


<!-- Footer Area Start -->
	<footer class="footer">
		<div class="footer-main-area" data-background="images/footer-bg.png">
			<div class="container">
				<div class="row">
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
						<!--	<img src="images/footer_logo.png" alt="" class="mrb-20">-->
							<address class="mrb-25">
								<p class="text-light-gray">D-326 New Minal,
Near Gate No.5, Bhopal <br/>Madhya Pradesh, INDIA.</p>
								<div class="mrb-10"><a href="#" class="text-light-gray"><i class="fas fa-phone-alt mrr-10"></i>+91 98930-70156 </a></div>
								<div class="mrb-10"><a href="#" class="text-light-gray"><i class="fas fa-envelope mrr-10"></i>info@schoolerpindia.com </a></div>
								<div class="mrb-0"><a href="#" class="text-light-gray"><i class="fas fa-globe mrr-10"></i>www.schoolerpindia.com</a></div>
							</address>
							<ul class="social-list">
								<li><a href= "https://www.facebook.com/schoolerps/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
								<!-- <li><a href="#"><i class="fa-brands fa-linkedin-in" target="_blank"></i></a></li> -->
								<li><a href="https://www.instagram.com/school_erp_india/" target="_blank"><i class="fab fa-instagram"></i></a></li>
								<li><a href="https://www.youtube.com/@schoolerpindia" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30"> School Solutions </h5>
							<ul class="footer-widget-list">
	 <li > <a   href="admission-management.php"> Online Admission / Enrollment</a> </li>
 <li ><a   href="student-management.php">Student Management</a> </li>
 <li ><a   href="fees-management.php">Fees Management</a> </li>
<li ><a   href="progress-card.php">Progress Card</a> </li>
<li ><a   href="alumni_management.php">Alumni Management  </a> </li>
							</ul>
						</div>
					</div>
					<!--<div class="col-xl-2 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Services</h5>
							<ul class="footer-widget-list">
								<li><a href="#">Home</a></li>
								<li><a href="#">About</a></li>
								<li><a href="#">Team</a></li>
								<li><a href="#">Service</a></li>
								<li><a href="#">News</a></li>
								<li><a href="#">Policy</a></li>
								<li><a href="#">Contact</a></li>
							</ul>
						</div>
					</div>
					<div class="col-xl-4 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Newsletter</h5>
							<p class="text-light-gray">Seamlessly visualize quality intellectual capital without superior collaboration and idea sharing listically</p>
							<input type="text" class="form-control" placeholder="Enter Your Email">
							<a href="#" class="cs-btn-one btn-gradient-color btn-sm has-icon mrt-20"><i class="webexflaticon flaticon-send"></i>Submit Now</a>
						</div>
					</div>-->
					
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Integrations</h5>
							<ul class="footer-widget-list">
								<li > <a   href="attendance-machine.php"> Attendance Machine  </a> </li>
<li ><a   href="payment-gateway.php">Payment Gateway </a> </li>
<li ><a   href="fee-via-dynamic-qr-code.php">Fee Via Dynamic QR Code   </a> </li>
<li ><a   href="sms-gateway.php">SMS/Whatsup Gateway  </a> </li>
<li ><a   href="googlemeet-zoom.php">Google Meet/Zoom/Webex</a> </li>
							</ul>
						</div>
					</div>
					
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30"> Our Services</h5>
							<ul class="footer-widget-list">
							<li><a href="dynamic_website.php">Dynamic Website</a></li>
								 
<li ><a   href="student-app.php">Student App</a> </li>
<li ><a   href="teacher-app.php">Teacher App</a></li>
<li ><a   href="admin-app.php">Admin App</a></li>
<li ><a   href="student-web-login.php">Student Web Login</a></li>
							</ul>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<div class="footer-bottom-area">
			<div class="container">
				<div class="row">
					<div class="col-xl-12">
						<div class="text-center">
							<span class="text-light-gray" style="float: left;" >Copyright � 2021 by <a class="text-primary-color" target="_blank" href="#"> School ERp India</a> | All rights reserved    </span>
			
			 <a class="text-primary-color" style="float: right;color: white;"    href="privace-policy.php"> 
      Privacy Policy | Terms of Service | Refund & Cancellation 
 </a>
			 
						</div>
						
						
						
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer Area End -->
  
<script src="js/jquery.v1.12.4.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery-core-plugins.js"></script>
	<script src="js/main.js"></script>
	
 <script src="js/rTabs.js" type="text/javascript"></script> 
      
</body>

</html>