<!DOCTYPE html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <title>School ERP India Software in India Is The Best ERP Software, School Management Software, ERP For Schools in India, India by School ERP, School Software!</title>
<meta name="description" content="School ERP India is an online educational solution for all educational organization including engineering college, medical college, technical college, management college. School ERP is the best software for Schools, Colleges, Engineering Colleges, Management Colleges, Medical Colleges, Degree College, best online educational software for college in india. School ERP College ERP provides modules like Student Management, admission module, fee module, Timetable Management, Director and Principal Module, Library Management, stock module, HR Module, Transport Module, Hostel Module" />
<meta name="keywords" content="School ERP, ERP Solutions Education, ERP for School, Kids School ERP Software, School Management, School ERP System, School Management Software, School ERP Software in India, ERP School" />
<meta name="author" content="School ERP, vaibhav@schoolerpindia.com">
<meta name="revisit-after" content="7 days">
<meta name="og:title" content="School ERP Software in India Is The Best ERP Software, School Management Software, ERP For Schools in India, India by School ERP, School Software!"/>
<meta name="og:type" content="School ERP India"/>
<meta name="og:url" content="http://schoolerpindia.com/index.php"/>
<meta name="og:image" content="https://schoolerpindia.com/images/bg/1.jpeg"/>
<meta name="og:site_name" content="SchoolERPIndia"/>
<meta name="og:description" content="School ERP India is an online educational solution for all educational organization including engineering college, medical college, technical college, management college"/>
<meta name="og:email" content="vaibhav@schoolerpindia.com"/>
<meta name="og:phone_number" content="+91 9893070156"/>

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="css/custom-animation.css">
<link rel="stylesheet" href="css/magnific-popup.css">
<link rel="stylesheet" href="css/meanmenu.min.css">
<link rel="stylesheet" href="css/owl.carousel.min.css">


<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />


<meta name="facebook-domain-verification" content="9izle3q4o4hajikcrolaty9ogahzq7" />
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-130825364-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-130825364-1');
</script>
    <link href="images/favicon.png" rel="shortcut icon" type="image/png">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
        <link rel="stylesheet" href="css/slide.css">
    <link rel="stylesheet" href="css/animate.css">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>



    <link rel="schema.DC" href="http://purl.org/dc/elements/1.1/" />
    <!-- Dependency Styles -->
    <link rel="stylesheet" href="dependencies/bootstrap/css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="dependencies/fontawesome/css/all.min.css" type="text/css">
    <link rel="stylesheet" href="dependencies/swiper/css/swiper.min.css" type="text/css">
    <link rel="stylesheet" href="dependencies/wow/css/animate.css" type="text/css">
    <link rel="stylesheet" href="dependencies/magnific-popup/css/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="dependencies/components-elegant-icons/css/elegant-icons.min.css" type="text/css">
    <link rel="stylesheet" href="dependencies/simple-line-icons/css/simple-line-icons.css" type="text/css">
    <!-- Site Stylesheet -->
    <link rel="stylesheet" href="assets/css/app-1.css" type="text/css">
    <link rel="stylesheet" href="fonts/fonts.css" type="text/css">  
    <!-- Google Web Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800" rel="stylesheet">
       <style> .feature-image { background: #fff; margin: 0 auto; text-align: center; } .post-post-grid .feature-image img { max-width: 100%; width: auto; } .service { padding-top: 120px; padding-bottom: 100px; } .pixsass-portfolio-items.portfolio-one .pixsass-portfolio-item { margin-bottom: 25px; } .pixsass-isotope-filter li.current a { border-color: transparent; color: #fa7070; } .pixsass-isotope-filter li a { padding: 0; } /* current-class css */ .h_map ul li.current .place_name { background: #7052fb; box-shadow: 0px 20px 30px 0px #7052fb47; } .h_map ul li.current .place_name:before { color: #333; border-color: #7052fb transparent transparent transparent; } .h_map ul li.current .round { background: #7052fb; } .h_map ul li.current .round:before, .h_map ul li.current .round:after { content: ""; background: #7052fb; } .h_map ul li.current .round .dot { background: rgba(112, 82, 251, 0.27); } .testimonials-two { background: #efedfd; } .op-4 { opacity: 0.4; } .portfolios { padding: 60px 0 125px; } .font-500 { font-weight: 500; } .bg-cl { background: url('media/background/bg-client.svg') no-repeat center top; background-size: 100%; } .max-w { max-width: 70%; margin: 0 auto; } svg.h100 { width: 570px; } .pixsass-isotope { max-height: 551px; overflow: hidden; } .page-banner { background: #f9f9f9; background-image: linear-gradient(-60deg, #ffffff 0%, #ffffff 100%); } .s-red { color: #403434 !important; } .animate-ball .ball { background: #f4f7fb; } .pt-country-image { display: inline-block; width: 32px; height: 22px; background: url(general-sprite1.png); } .pt-country-detail>span { vertical-align: text-top; height: 25px; display: inline-block; font-size: 16px; font-weight: 500; text-align: center; padding-left: 15px; line-height: 6px; } .pt-country-Qatar { background-position: -6px -151px; } .pt-country-Nepal { background-position: -35px -133px; } .pt-country-Myanmar { background-position: -91px -57px; } .pt-country-Kuwait { background-position: -132px -56px; } .pt-country-eastafrica { background-position: -177px -56px; } .pt-country-India { background-position: -216px -56px; } .blog-grid-two { padding: 50px 0; background: #efefef; } .testimonials-two { padding: 35px 0 60px; } .entry-meta { margin-bottom: 20px; margin-top: 15px; } .i-color { font-size: 52px; margin-right: 4px; color: #7f8092; } .entry-meta a { color: #2b2350; margin-right: 10px; font-size: 15px; display: inline-block; } .blog-post-two .blog-content { padding: 2px 8px !important; text-align: left; background: #fff; } b, strong { font-weight: 600; } .count-col.slide-left { display: inline-block; padding-right: 20px; } .pt-list { width: 80%; border: 1px solid lightgray; border-radius: 10px; margin: 80px auto 35px; padding: 40px 20px; text-align: center; line-height: 1.5; background-color: rgba(255, 255, 255, 0.5); } @media (max-width: 991px) {.font-style-xs {font-size: 20px;line-height: 30px;letter-spacing: .5px;} .pixsass-isotope { max-height: initial;    margin-top: 12%; } .portfolios { padding: 20px 0 40px; } .max-w { max-width: 90%; margin: 0 auto; }.faq-forms1 { padding-bottom: 76px; } } .faq-forms1 { padding-bottom: 34px; } </style>

   <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-83806328-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-83806328-1');
</script>



    <script>
    (function(i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function() {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
            m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '../www.google-analytics.com/analytics.js', 'ga');

    ga('create', 'UA-83806328-1', 'auto');
    ga('send', 'pageview');
    </script>

    <!-- Meta Pixel Code -->
        <script>
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        '../connect.facebook.net/en_US/fbevents.js');
        fbq('init', '797143521467545');
        fbq('track', 'PageView');
        </script>
        <noscript><img height="1" width="1" style="display:none"
        src="https://www.facebook.com/tr?id=797143521467545&amp;ev=PageView&amp;noscript=1"
        /></noscript>
    <!-- End Meta Pixel Code --><script type="text/javascript">     (function(c,l,a,r,i,t,y){         c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};         t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;         y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);     })(window, document, "clarity", "script", "ix4i2xaftm"); </script>
</head>

<body id="home-version-1" class="home-version-1" data-style="default">
    <!-- header start -->
   <header class="header-style-two" style="height: 98px ;">
		<div class="header-wrapper">
			<div class="header-top-area bg-gradient-color d-none d-lg-block">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 header-top-left-part">
						
							<marquee><span class="address"><i class="webexflaticon flaticon-phone"></i> +91-9893070156, +91-6269048888 </span><span class="phone"><i class="webexflaticon flaticon-send"></i> info@schoolerpindia.com </span></marquee>
							<!-- somu28/10/2023 -->
						</div>
						<div class="col-lg-6 header-top-right-part text-right">
							
						<ul class="social-links">
                                	<li><a href="https://www.facebook.com/schoolerps"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="https://www.youtube.com/channel/UCglZwT9PYeAPTKg6rUhQiFA"><i class="fab fa-youtube"></i></a></li>
							</ul>
							
						<div class="language">
								<a href="school-erp-demo.php"><i class="webexflaticon flaticon-man"></i> Free Demo</a>								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="bt_blank_nav"></div>
			<div class="header-navigation-area two-layers-header header-middlee bt_stick bt_sticky ">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<a class="navbar-brand logo f-left mrt-0 mrt-md-0" href="index.php"><!-- somu28/10/2023 -->
								<img id="logo-image" class="img-center" src="images/logo.png" alt="">
							</a>
							<div class="mobile-menu-right"></div>
							<div class="header-searchbox-style-two d-none d-xl-block">
								<div class="side-panel side-panel-trigger text-right d-none d-lg-block">
									<span class="bar1"></span>
									<span class="bar2"></span>
									<span class="bar3"></span>
								</div>
								<div class="show-searchbox">
									<a href="#"><i class="webex-icon-Search"></i></a>
								</div>
								<div class="toggle-searchbox">
									<form action="#" id="searchform-all" method="get">
										<div>
											<input type="text" id="s" class="form-control" placeholder="Search...">
											<div class="input-box">
												<input type="submit" value="" id="searchsubmit"><i class="fas fa-search"></i>
											</div>
										</div>
									</form>
								</div>
							</div>
							<div class="side-panel-content">
								<div class="close-icon">
									<button><i class="webex-icon-cross"></i></button>
								</div>
								<div class="side-panel-logo mrb-30">
									<a href="index.php">
										<img src="images/logo.png" alt="" />
									</a>
								</div>
								<div class="side-info mrb-30">
									<div class="side-panel-element mrb-25">
										<h4 class="mrb-10">Office Address</h4>
										<ul class="list-items">
											<li><span class="fa fa-map-marker-alt mrr-10 text-primary-color"></span>D-218 Old Minal, J.K. Road Bhopal Madhya Pradesh, INDIA.</li>
											<li><span class="fas fa-envelope mrr-10 text-primary-color"></span>info@schoolerpindia.com</li>
											<li><span class="fas fa-phone-alt mrr-10 text-primary-color"></span>+91 7987535570 </li>
										</ul>
									</div>
									
									<body>
<header>
      <div id="carousel" class="carousel slide" data-ride="carousel" style="">
        <ol class="carousel-indicators" style="display: none;">
          <li data-target="#carousel" data-slide-to="0" class="active"></li>
          <li data-target="#carousel" data-slide-to="1"></li>
          <li data-target="#carousel" data-slide-to="2"></li>
        </ol>

        <div class="carousel-inner" role="listbox">
		
		 <!-- <div class="carousel-item active" data-background="images/bg/erp_banner.png" style="background-image: url('images/bg/erp_banner.jpg'); background-size: contain;">somu 28/10/2023-->
      <!-- <div class="carousel-item active" data-background="images/bg/erp_banner.png" style="background-image: url('images/bg/erp_banner.jpg'); background-size: contain;"> -->
        <div class="carousel-item active" data-background="images/bg/erp_banner2.gif" style="background-image: url('images/bg/erp_banner2.gif'); background-size: contain;">
            <div class="caption">
              <button class="book_demobtn" style=""><a href="https://api.whatsapp.com/send/?phone=916269028888&text=I feel good about SCHOOL ERP INDIA. Please help me to%C2%A0know%C2%A0more?" target="_blank"style="color:transparent;">Book Demo</a></button>
             <!-- <h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
            </div>
          </div>

           
          <div class="carousel-item" style="background-image: url('images/bg/erp_banner4.webp'); background-size: contain;">
            <div class="caption">
             <!--  <h1 style="color:black">Create and share your whatever</h1>
              <h2 style="color:black">Make it easy for you to do whatever this thing does.</h2> -->
              <!-- <button><a href="#">Book Demo</a></button>--> <!-- somu 28/10/2023 --> 
              <button class="book_demobtn"style="">
   
    
    <a href="https://api.whatsapp.com/send/?phone=916269028888&text=I feel good about SCHOOL ERP INDIA. Please help me to%C2%A0know%C2%A0more?" target="_blank"style="color:transparent;">Book Demo</a></button>
            </div>
          </div>
          <style>
            .book_demobtn{
              position:relative;
    left: -443px;
    bottom: -138px;
    font-size: 35px;
    font-weight: 800;
    pointer:cursor;
    color: white !important;
    background: none;
            }

      @media(max-width:600px){
        .book_demobtn{
          position:absolute !important;
          left: -73px !important;
          bottom: -25px !important;
        }
      }
    </style>
		      
<!-- somu 28/10/2023 -->
	     <!--  <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
           <!--  </div>
          </div>

          <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
          <!--   </div>
          </div>

          <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
            <!-- </div>
          </div> -->
 


        </div>
        
        <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
          <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
          <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
          <span class="sr-only">Next</span>
        </a>

      </div>
    </header>
    <style >
       @media (max-width: 740px){
   .carousel-inner {
    padding-top: 52.25%;
    display: block;
    content: "";
}
}
    </style>
</body>									
								</div>
								<h4 class="mrb-15">Social List</h4>
								<ul class="social-list">
									<li><a href="#"><i class="fab fa-facebook"></i></a></li>
									<li><a href="#"><i class="fab fa-twitter"></i></a></li>
									<li><a href="#"><i class="fab fa-instagram"></i></a></li>
									<li><a href="#"><i class="fab fa-google-plus"></i></a></li>
								</ul>
							</div>
							<div class="main-menu f-right fff">
								<nav id="mobile-menu-right">
									<ul>
									<li><a href="index.php">Home</a></li>
										   <li class="has-sub">
											<a href="#">Modules/Services</a>
											<ul class="sub-menu">
<li><a href="admission-management.php">Admission Management</a></li>
<li><a href="student-management.php">Student Management</a></li>
<li><a href="fees-management.php">Fee Management</a></li>
<li><a href="attendance-management.php">Attendance Management</a></li>
<li><a href="academics-management.php">Academic Management</a></li>
<li><a href="exam-management.php">Examination Management</a></li>
<li><a href="online_exam.php">Online Examination</a></li>
<li><a href="hr-management.php">HR  Management</a></li>
<li><a href="learning_management.php">Learning Management</a></li>
<li><a href="inventory_management.php">Inventory Management</a></li>
<li><a href="transport-management.php">Transport Management</a></li>
<li><a href="alumni_management.php"> Alumni management</a></li>
<li><a href="followup_management.php">Followup Management</a></li>
</ul>
										</li> 
										
<li class="has-sub">
<a href="#">Integrations</a>
	<ul class="sub-menu">
<li><a href="attendance-machine.php">Attendance Machine</a></li>
<!--<li><a href="bus-tracking.php">Bus Tracking</a></li>-->
<li><a href="payment-gateway.php">Payment Gateway</a></li>
<li><a href="sms-gateway.php">SMS/Whatsup Gateway</a></li>
<li><a href="rfid-card.php">RFID Card</a></li>
<li><a href="bulk-email.php">Bulk Email</a></li>
<li><a href="fee-via-dynamic-qr-code.php">Fee Via Dynamic QR Code</a></li>
<li><a href="googlemeet-zoom.php">Google Meet/Zoom/Webex </a></li>
</ul>									
										
										
										
										</li>
																			
										<li><a href="dynamic_website.php">Website</a></li>
										<li><a href="mobileapp.php">Mobile App</a></li>
											<li><a href="pricing.php"> Pricing  </a></li>
									
										<!-- <li><a href="demo-videos.php"> Demo Videos </a></li> -->
										<li><a href="partners.php"> Partners </a></li>
										
										<li><a href="school-erp-demo.php">  Demo  </a></li>
										<li><a href="client.php"> Clients  </a></li>
									
										 
										
										<!--<li><a href="page-pricing.php">Pricing</a></li>
										
										<li class="has-sub right-view">
											<a href="#">Clients</a>
											<ul class="sub-menu">
												<li><a href="page-news.php">News Classic</a></li>
												<li><a href="page-news-left-sidebar.php">News Left Sidebar</a></li>
												<li><a href="page-news-right-sidebar.php">News Right Sidebar</a></li>
												<li><a href="page-single-news.php">Single News</a></li>
											</ul>
										</li>-->
										<li><a href="contact-us.php">Contact Us</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>   <!-- header end -->
    <a href="#main_content" data-type="section-switch" class="return-to-top">
        <i class="fa fa-chevron-up"></i>
    </a>
         
   <section class="page-title-section">
        <div class="container">
            <div class="row">
                <div class="col-xl-12 text-center">
                    <div class="page-title-content">
                        <h3 class="title text-white">Clients</span></h3>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Clients</span></li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <div id="main_content">
        <!--=========================-->
        <!--=        Navbar         =-->
        <!--=========================-->
   <!--      <script>
var Tawk_API = Tawk_API || {},
    Tawk_LoadStart = new Date();
(function() {
    var s1 = document.createElement("script"),
        s0 = document.getElementsByTagName("script")[0];
    s1.async = true;
    s1.src = 'https://embed.tawk.to/58f9d1434ac4446b24a6b643/default';
    s1.charset = 'UTF-8';
    s1.setAttribute('crossorigin', '*');
    s0.parentNode.insertBefore(s1, s0);
})();
</script> -->
<style>
   @media (min-width: 1401px) and (max-width: 16550px)
.container {
    max-width: 1200px !important;
}
.header-top-area{
    height: 36px !important;
}
.pix-header-fixed .nav-right a.s-red {
    color: #fa7070;
}

.s-red {
    color: #fff;
}

.site-header .heder-inner .site-nav .nav-right .nav-btn {
    padding: 1px 12px;
}
 
.call-d {
    position: fixed;
    top: 150px;
    right: -129px;
    font-size: 13px;
    text-align: center;
    z-index: 99;
    color: #7a58fc;
    transition: all 0.6s ease-in-out;
    -webkit-transition: all 0.6s ease-in-out;
}

.call-d:hover {
    /* right: 0;
    transition: all 0.6s ease-in-out;
    -webkit-transition: all 0.6s ease-in-out; */
}

.call-d span i {
    width: 42px;
    height: 42px;
    background: #4a2cc2;
    display: block;
    float: left;
    margin-right: 10px;
    padding: 7px 0;
    color: #fff;
    line-height: normal;
    border-radius: 4px 0px 0px 4px;
}

.call-d span {
    display: flex;
    background: #efe7e7;
    line-height: 42px;
    padding-right: 10px;
    border-radius: 12px 0 0 12px;
    color: #040404;
    letter-spacing: 0.4px;
    transition: all 0.6s ease-in-out;
    -webkit-transition: all 0.6s ease-in-out;
    font-size: 17px;
}

.call-d:hover p {
    /* opacity: 1;
    filter: alpha(opcity=100);
    transition: all 0.4s ease-in-out;
    -webkit-transition: all 0.4s ease-in-out; */
}

.call-d p {
    margin-left: 24%;
    margin-bottom: -1px;
    background-color: white;
}

.gh {
    border-top-left-radius: 0px;
    border-top-right-radius: 0px;
    border-bottom-right-radius: 20px;
    border-bottom-left-radius: 20px;
    left: 13%;
    /*background: rgb(122, 88, 252);*/
    background: #2b2350;
    position: absolute;
    top: 0px;
    width: 40%;
}


dl, ol, ul {
     margin-top: -11px; 
     margin-bottom: 1rem; 
}
h2.blink {
    font-size: 23px;
    color: #ffffff;
    display: inline-block;
    margin: 0;
    line-height: 20px;
    font-weight: 100;
    text-transform: uppercase;
    padding: 1px 30px;
    font-family: 'Francois One', sans-serif;
}

.gh h2 {
    color: #fff;
    font-weight: 700;
    overflow: hidden;
    font-size: 16px;
}

.blink {
    text-decoration: blink;
    -webkit-animation-name: blinker;
    -webkit-animation-duration: 1.2s;
    -webkit-animation-iteration-count: infinite;

    -webkit-animation-timing-function: ease-in-out;
    -webkit-animation-direction: alternate;
}

@-webkit-keyframes blinker {
    from {
        opacity: 1.0;
    }

    to {
        opacity: 0.3;
    }
}

.site-header .site-main-menu li {
    padding: 45px 0px 18px 0;
}

.pix-header-fixed .site-main-menu li {
    padding: 45px 0px 18px 0;
}

.mainss {
    right: 0;
}

@media (min-width:992px) and (max-width:1240px) {
    .gh {
        width: 50%;
        text-align: center;
    }
}

@media (max-width: 991px) {
    .site-header .site-mobile-logo {
        width: 100px;
        transform: translateX(50%);
    }

    .site-header .site-nav .site-main-menu li.menu-item-has-children i {
        position: absolute;
        top: 6px;
        right: -20px;
        width: 100%;
        padding: 0px 182px 20px;
        font-size: 25px;
    }

    .mobile-banner {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-flow: column;
    }

    .mob-btn--gif {
        position: absolute;
        bottom: 5px;
        width: 36%;
    }

}

@-moz-document url-prefix() {
    .site-header .heder-inner .site-logo a img {
        width: 228px;
    }
}

#footer.footer-two .footer-social-link li a {
    background: #7052fb;
    border-color: #7052fb;
    color: #fff;
}

.offer-area {
    background: url('diwali.jpg') no-repeat center;
    min-height: 35px;
    display: none;
    align-content: center;
    justify-content: center;
    align-items: center;
    background-size: cover
}

.offer-area h2 {
    margin-bottom: 0px;
    font-size: 20px;
    color: #ffe555;
}

span.offer-area-cta {
    color: #fff;
}.site-header .site-main-menu li .sub-menu.min-260 {
    min-width: 290px;
}

@media (max-width: 991px) {
    .gh {
        border-top-left-radius: 0px;
        border-top-right-radius: 0px;
        border-bottom-right-radius: 20px;
        border-bottom-left-radius: 20px;
        left: 6% !important;
        /* background: rgb(122, 88, 252); */
        font-size: 1rem;
        background: #2b2350;
        position: absolute;
        top: -94px !important;
        width: 88% !important;
    }

    .gh h2 {
        font-size: 0.87rem;
        padding: 1px 12px;
    }

    .offer-area {
        min-height: 30px;
    }

    .offer-area h2 {
        font-size: 16px;
    }

    .site-header .heder-inner {
        padding: 4px 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
}
.footer-widget-list li a:before {
    top: -11px !important;
}
</style>


       <!-- /.site-header -->
        <!--==========================-->
        <!--=         Banner         =-->
        <!--==========================-->
        
        <!-- /.page-banner -->
        <!--=============================-->
        <!--=         Portfolio         =-->
        <!--=============================-->
                <section class="portfolios">
            <div class="container">

                <div class="section-title color-two text-center">
                    <h2 class="title wow pixFadeUp d-none d-lg-block" data-wow-delay="0.3s">
                        Our Clients
                    </h2>
                    <h2 class="font-style-xs wow pixFadeUp mb-25 d-block d-lg-none" data-wow-delay="0.3s" style="">
                         We are Present in 20+ States in India with<span
                                    style="color: #7052fb;"><br> 1000+ </span> Clients
                    </h2>
                </div>
                <div class="portfolio-inner row">
                    <div class="col-lg-6">
                        <div class="h_map">
                            <ul class="list-unstyled pixsass-isotope-filter">
                                <li class="wow fadeIn" data-wow-delay="0.7s" title="Jammu & Kashmir">
                                    <!-- <a href="#" data-id="26" data-filter=".jammu "> -->
                                        <!-- <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s" > Jammu & Kashmir <br> -->
                                            <!-- <span style="color:goldenrod;">200 +</span> -->
                                        <!-- </div> -->
                                        <!-- <div class="round">
                                            <div class="dot"></div>
                                        </div> -->
                                    <!-- </a> -->
<!-- style="text-align:center;line-height: 18px;padding:5px 10px" -->
                                </li>
                                <li class="wow fadeIn" data-wow-delay="0.9s" title="Himachal"> 
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Himachal Pradesh</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Uttarakhand"><a href="#" data-id="5"
                                        data-filter=".Uttarakhand ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s">Uttarakhand
                                        </div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="0.7s" title="Haryana"> <a href="#" data-id="6"
                                        data-filter=".Haryana ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Haryana</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="0.3s" title="Delhi"><a href="#" data-id="7"
                                        data-filter=".Delhi">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Delhi </div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Rajasthan"><a href="#" data-id="8"
                                        data-filter=".Rajasthan ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Rajasthan</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Uttar Pradesh"><a href="#"
                                        data-id="9" data-filter=".Uttar ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s">Uttar Pradesh
                                        </div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Bihar"><a href="#" data-id="10"
                                        data-filter=".Bihar">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s">Bihar</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Punjab"><a href="#" data-id="3"
                                        data-filter=".Punjab">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s">Punjab</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Tripura"><a href="#">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s">Tripura</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Assam">
                                    <!-- <a href="">data-id="18" data-filter=".Assam"</a> -->
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s">Assam</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="West Bengal">
                                    <a href="#" data-id="19" data-filter=".Bengal">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s">West Bengal
                                        </div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a>
                                </li>
                                <li class="wow fadeIn" data-wow-delay="1.1s" title="Jharkhand"><a href="#" data-id="20"
                                        data-filter=".Jharkhand ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Jharkhand</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s">
                                    <a href="#" data-id="21" data-filter=".Odisha ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Odisha</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a>
                                </li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Chhattisgarh"><a href="#"
                                        data-id="22" data-filter=".Chhattisgarh ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Chhattisgarh
                                        </div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Madhya Pradesh"><a href="#"
                                        data-id="23" data-filter=".Madhya ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Madhya Pradesh
                                        </div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="0.5s" title="Gujarat"> <a href="#" data-id="24"
                                        data-filter=".Gujarat">
                                        <div class="place_name hide wow" data-wow-delay="0.2s"> Gujarat</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Maharashtra"><a href="#" data-id="27"
                                        data-filter=".Maharashtra ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Maharashtra
                                        </div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>
                                <li class="wow fadeIn" data-wow-delay="0.1s" title="Andhra Pradesh"><!-- <a href="#"
                                        data-id="28" data-filter=".Andhra" class="selected">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Andhra Pradesh
                                        </div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a>  --></li>
                                <li class="wow fadeIn" data-wow-delay="1.3s" title="Karnataka"><!-- <a href="#" data-id="29"
                                        data-filter=".Karnataka ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Karnataka</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a> --></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Sikkim">
                                    <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s">Sikkim</div>
                                    <div class="round">
                                        <div class="dot"></div>
                                    </div>
                                </li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Kerala"> 
                                    <!-- data-id="32" data-filter=".Kerala " -->
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Kerala</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div> </li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Tamil Nadu"><!-- <a href="#" data-id="33"
                                        data-filter=".Tamil ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s"> Tamil Nadu
                                        </div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a> --></li>
                                <li class="wow fadeIn" data-wow-delay="1.5s" title="Telangana"><a href="#" data-id="37"
                                        data-filter=".Telangana ">
                                        <div class="place_name hide wow fadeInUp" data-wow-delay="0.2s">Telangana</div>
                                        <div class="round">
                                            <div class="dot"></div>
                                        </div>
                                    </a></li>


                            </ul>
                        </div>
                        
                        <div class="shape-bg">
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg"
                                xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 1080 1080"
                                style="enable-background:new 0 0 1080 1080;" xml:space="preserve" class="h100">
                                <style type="text/css">
                                .st0 {
                                    fill: #E8E8E8;
                                    stroke: #898989;
                                    stroke-miterlimit: 10;
                                }
                                </style>
                                <g id="Layer_2">
                                    <g>
                                        <path class="st0 st-1 state_10" d="M609.34,367.85c1.51,0.29,1.7,4.74,2.63,6.28c0.18,0.31,0.4,1.27,0.48,1.41c0.23,0.42,1.75,0.79,2.25,1.63
                      c0.99,1.64-0.66,4.2,0.55,5.75c1.91,2.45,5.23-0.04,6.6,2.2c1.13,1.85-0.06,3.24,1.7,4.91c0.97,0.92,3.82-0.71,3.6,2.17
                      c-0.23,2.96-9.03,1.71-11.15,2.64c0.27-0.12-2.32,1.68-2.19,1.56c-0.86,0.74-2.52-0.11-1.89,1.99c0.56,1.87,6.22,1.44,7.58,3.15
                      c2.8,3.51-1.66,6.09-4.7,6.4c1.97,3.75,5.57,6.78,9.06,8.81c1.94,1.13,3.23,1.98,5.13,2.86c1.43,0.66,3.65,0.84,4.7,2.07
                      c5.71,6.67-7.18,4.29-9.07,4.78c-1.64,0.42-1.83,2.18-4.12,1.64c-0.57-0.13-0.17-2.95-2.81-1.19c-0.47,0.32-0.26,1.94-0.79,2.48
                      c-1.03,1.03-2.25,1.15-3.45,1.94c-1.48,0.98-2.19,1.84-3.3,3.33c-2.15,2.89-3.44,3.05-6.46,4.84c-1.99,1.19-5.15,2.38-6.87,3.63
                      c-4.31,3.13-3.8,10.28-1.66,14.69c1.35,2.77,9.99,9.05,3.13,12.16c3.43,2.09,7.45,1.6,11.33,1.73c1.23,0.04,4.16,0.69,5.23-0.21
                      c0.52-0.44,0.09-2.31,0.42-2.43c-0.05,0.02,0.33-0.39,0.61-0.49c2.63-0.99,3.63,2.71,4.9,3.37c0.02,1.01,0.41,1.46,1.16,1.36
                      c0.68,0.12,1.28-0.11,1.8-0.7c2.39,0.17,3.71-2.66,5.43,1.05c0.74,1.61-0.47,3,1.03,4.6c1.7,1.81,4.71,1.09,5.68,0.37
                      c0.47-0.34-0.26-1.94,0.14-2.38c0.26-0.28,1.25,0.18,1.53-0.05c1.08,0.22,1.91-0.05,2.51-0.81c0.19-0.78,0.46-1.52,0.83-2.24
                      c1.46-0.64,2.49-1.62,4.2-0.49c2.71,1.79,1.6,5.11,5.61,4.12c0.01,0,2.99-1.53,3.37-1.75c0.82,0.05,1.57-0.14,2.25-0.57
                      c0.18-0.47,0.21-0.94,0.11-1.42c2.41-1.36,5.32-0.64,7.54-1.67c1.27-0.59,0.81-1.22,1.78-1.84c0.26-0.17,1.98-0.99,2.14-1.2
                      c0.8-1.02,1.66-2.39,2.21-4.03c2.22-6.71,4.74-2.33,8.88-2.54c2.4-0.12,2.39-0.94,4.2,0.02c2.4,1.27,2.87,4.56,2.74,7.05
                      c1.11,0,3.04-1.45,4.17-0.63c1.43,1.03,0.41,2.7,0.98,3.83c0.81,1.62-0.12,1.28,1.04,2.27c0.85,0.73,2.52,1.21,3.36,0.38
                      c-0.1,0.1,5.34-14.36,6.54-5.44c1.73-0.09,3-1.72,2.89-3.35c1.56,0.15,3.59,2.94,4.78,2.63c0.15-3.41,2.41-2.61,3.48-5.34
                      c0.53-1.36-0.21-3.14,0.32-4.48c0.74-1.86,1.83-0.94,2.26-3.69c0.36-2.3-0.83-3.7,0.93-5.65c0.96-1.06,2.19-0.74,3.17-2.07
                      c0.66-0.9,0.46-3.28,1.3-3.96c0.94-0.76,4.18-0.24,5.34-0.28c0-0.13,1.27-4.55,1.28-4.56c3.27-2.14,7.49,2.39,9.94,3.73
                      c0.05-1.54,2.39-2.3,2.42-3.36c0.01-0.24-1.54-2.92-1.65-3.12c-0.56-1.08-2.3-3.54-1.59-4.85c0.06-0.11,1.53-0.16,1.44-0.05
                      c0.57-0.02,1.14-0.02,1.7-0.02c0.04-0.36,0.07-0.72,0.11-1.07c1.37-0.96,0.02-1.9,2.37-2.4c1.35-0.29,2.17,0.64,3.27,1.15
                      c-0.38-2.4-0.41-6.03-2.71-7.68c-0.83-0.6-2.35-0.67-2.98-1.03c-5.07-2.85-1.89-6.35-1.93-10.82c2.66,0.77,2.36-0.45,3.78-1.62
                      c2.09-1.72,3.74-3.53,5.64-5.52c3.09-3.24,1.92-2.52,1.28-7.22c-0.46-3.39,1.16-4.75-2.06-6.39c-0.03,1.41-2,7.25-3.24,2.92
                      c-1.45,1.47-0.26,6.98-2.66,7.06c-1.34,0.05-2.9-3.42-4.31-3.94c0.23,2.07-4.22,2.05-5.78,2.48c-1.11,0.3-2.08,0.91-3.23,0.97
                      c-1.49,0.08-3.77-1.54-5.16-0.84c-3.67,1.83-0.71,3.84-6.12,1.91c0.5,0.18-3.84-1.44-3.49-1.09c-0.82-0.82-0.66-4.91-1.38-6.26
                      c-0.71,0.14-3.34,2.88-4.1,3.46c-2.17,1.63-5.3,3.55-7.33,3c-1.16-0.31-3.32-2.62-4.63-3.27c-1.7-0.83-2.97-1.13-4.82-1.7
                      c-1.21-0.37-2.19-1.12-3.51-1.24c-1.16-0.1-2.25,1-3.91,0.63c-1.62-0.36-2.85-1.88-4.59-1.8c-1.6,0.07-2.66,1.98-4.03,2.56
                      c-2,0.85-0.68,0.69-2.68,0.43c0.13,0.02-4.09-2.25-3.72-1.74c-2.2-3.09,3.36-10.21-3.94-8.07c-2.7,0.79-3.98,3.56-6.49,4.42
                      c-0.72,0.25-3.3,0.49-4.02,0.08c-1.52-0.87-0.87-2.44-1.75-3.14c-1.66-1.32-2.39-0.28-4.1-0.96c-1.21-0.49-2.09-2.41-3.6-3.33
                      c-2.84-1.72-7.99,0.39-10.09-1.76c-2.08-2.13,1.31-6.91-0.1-9.87c-1.1-2.31-0.55-1.55-3.28-2.14c-1.51-0.32-3.16,0.18-4.7-0.18
                      c-3.72-0.88-4.11-3.55-7.48-4.48c-1.14-0.31-1.4-1.25-2.79-1.08c1.75-0.21-2.54,2.44-1.79,2.15c-1.43,0.56-4.3,0.11-5.52,1.3
                      C607.36,365.73,606.74,368.02,609.34,367.85z" />
                                        <path class="st0 st-2" d="M743.52,366.49c1.34,2.61,1.41,2.06,4.7,2.36c2.43,0.22,5.16,1.72,7.07,0.3c2.94-2.19,0.24-3.25,5.05-3.1
                      c0.43,0.01,1.25,0.75,1.66,0.81c0.41,0.06,0.95-0.67,1.54-0.6c1.39,0.17,0.44,0.53,1.77,0.15c0.78-0.22,0.56-0.25,1.72,0.42
                      c-0.08-2.45,3.03-2.06,2.5-5.08c-0.45-2.6-3.74-3.08-3.77-6.58c-0.01-1.64,1.06-3.17,1.58-4.81c0.91-2.83,0.88-4.13,0.79-6.45
                      c-0.09-2.19-0.39-7.76-3.64-9.2c-1.23-0.54-1.64,0.4-2.7,0.07c-0.57-0.18-0.59-1.3-0.66-1.31c-1.93-0.11-3.27-0.09-3.45,2.92
                      c-0.79-0.29-1.54-0.66-2.25-1.1c-0.07,0.22-1.86,3.77-2.28,3.17c-1.69-2.46-1.09-0.12-2.83,0.38c-1.64,0.48-4.19,0.44-5.85,0.54
                      c0,2.47,2.01,3.07,1.49,5.96c-0.34,1.88-1.7,4.84-2.64,6.61c-1.4,2.65-1.37,2.79-1.57,5.9c-0.08,1.2,0.07,6.72-0.77,7.38
                      C741.9,365.41,743.03,365.53,743.52,366.49z" />
                                        <path class="st0 st-3 state_20" d="M594.79,483.73c0.56,0.77,3.89,0.4,4.92,1.61c1.72,2.02,0.74,4.1,3.01,6.18c1.79,1.64,2.97,2.27,4.45,4.3
                      c0.85,1.17,0.55,2.67,2.49,2.11c-0.1,4.24,1.21,2.76,3.91,3.59c4.44,1.37,2.95,4.16,2.55,8.02c-0.34,3.29,1.23,2.6,1.97,4.94
                      c0.63,2.01,0.51,3.86,1.3,5.49c2.03,4.15,4.77,3.93,8.82,4.15c-0.64,2.34-0.51,6.59-1.94,8.46c-1.69,2.22-6.96,2.55-6.63,6.47
                      c-0.07-0.78,3.78,4.33,3.58,4.17c1.1,0.9,1.95,0.98,3.28,1.47c4.41,1.62,5.49-0.12,9.44-1.54c3.6-1.3,7.74,0.04,11.53-1.11
                      c1.93-0.59,5.88-3.76,7.88-2.54c0.73,0.45,0.46,10.91,0.02,11.92c-0.34,0.76-1.3,1.78-2.19,2.39c3.6,0.75,5.19,2.77,8.5,0.59
                      c3.43-2.26,4.1-3.91,8.71-2.64c2.66,0.73,4.33,2.04,7.09,2.18c1.15,0.06,0.91-1.15,1.79-0.8c1.77,0.72,1.98,2.23,0.91,3.73
                      c3.44,0.92,1.82-0.33,3.3-1.89c-0.51,0.53,2.71-3.67,2.39-2.27c0.27-1.2-1.18-2.87-1.2-4.13c-0.03-1.74,0.98-1.87,0.8-3.98
                      c-0.17-2.03-2.05-4.26-2.84-6.15c4.2-0.37,6,0.22,9.52,1.1c4.3,1.08,6.85,1.78,8.64,6.55c1.1-0.17,1.07-1.84,2.35-2.22
                      c2.42-0.72,3.75,1.14,5.32,2.41c1.71,1.37,0.11,2.18,2.27,2.29c1.28,0.06,2.32-0.86,3.17-1.66c-1.28-0.47-1.32-2.83-2-3.83
                      c-0.99-1.44-4.2-1.57-0.67-3.28c-0.38-2.37-3.7-4.13-5.82-3.55c1.36-2.82-2.76-3.67-4.3-5.81c-1.74-2.41-2.92-5.58,1.04-7.18
                      c-1.33-1-4.24-0.03-5.76-0.08c-2.76-0.09-5.75-2.06-7.94-3.97c-0.05-0.04-1.18,0.01-1.27-0.04c-0.61-0.32-0.59-1.55-1.49-1.94
                      c-1.76-0.75-4.58,1.17-4.63-1.81c-0.54-0.27-2.19,0.36-2.46-0.19c-0.76-1.5,0.53-3.76,0.99-5.06c0.63-1.78,2.14-4.24-1.25-5.68
                      c2.31-0.2,4.6-0.11,6.91-0.18c-0.43-2.44,0.23-5.59,4.36-3.23c1.12,0.64,0.09,1.94,1.16,3.12c3.77,4.14,5.52-2.24,7.59-3.94
                      c1.21-0.99,2.56-2.06,3.94-2.81c1.66-0.91,4.17-0.82,5.61-1.7c2.05-1.26,1.04-1.82,2.22-3.86c-0.04,0.07,2.91-2.19,2.43-1.98
                      c1.47-0.65,1.21-0.83,3.25-0.56c1.8,0.24,3.28,1.44,5.24,1.44c0.16-3.1-1.8-2.38,2.66-1.97c0.09-1.15,1.03-2.3,1.01-3.28
                      c-0.03-1.47-2.63-1.73-0.96-3.38c2.38-2.34,5.02,2.04,6.63,2.08c0.08-3.71,1.66-6.54,5.93-6.76c-1.82-2.26-0.57-1.97,1.52-4.33
                      c2.13-2.41,1.74-3.87,1.46-6.26c-0.12-0.98-0.43-3.05-0.75-4.31c2.58-0.22,5.99,0.31,3.97-3.7c-0.94-1.87-2.57-0.68-2.46-3.53
                      c0.03-0.79,1.15-0.28,1.26-0.85c0.78-3.94,0.99-7.67-2.32-10.45c-2.19-1.84-7.25-4.69-10.17-4.47c-0.07,1.51-0.63,4.09-1.62,4.74
                      c-1.23,0.81-3.87-0.78-5.06,0.05c-0.73,0.51-0.67,2.81-1.2,3.64c-1.13,1.77-3.3,1.73-4.13,3.25c-0.6,1.1,0.51,3.02,0.29,4.14
                      c-0.4,1.98-1.44,2.15-1.93,3.52c-0.52,1.45-0.09,4.38-0.96,5.87c-1,1.71-2.25,1.69-3.36,2.61c-2.48,2.07,1.7,1.38-1.02,2.3
                      c-1.68,0.56-2.65-1.31-3.8-2.13c-1.05,3.2-4.22,2.23-5.3,2.29c-0.57,0.03,0.08-1.64-1.35-1.24c-0.04,0.01-1.87,2.61-2.01,2.99
                      c-1.27,3.45-0.54,4.94-4.23,4.66c-2.4-0.18-2.81-1.95-3.39-4.35c-1.37-5.68-1.17,0.89-4.89-1.95c-0.7-0.53,0.34-1.03-0.19-2.08
                      c-1.01-1.98,0.25-2.38-1.97-4.13c-2.74-2.16,0.49-0.41-3.77-0.64c-1.18,0.39-2.32,0.3-3.42-0.24c-0.08-0.74-0.38-1.12-0.91-1.13
                      c-3.46,0.04-3,1.15-4.13,4.26c-0.28,0.77,0.15,2.14-0.5,2.8c-0.86,0.88-2.16,0.38-2.95,1c-0.82,0.65-0.54,2.07-1.69,2.77
                      c-1.42,0.86-4.07-0.25-5.66,0.48c-2.29,1.05-3.08,2.16-5.52,3.27c-0.49,0.22-2.81,1.9-2.99,1.93c-1.83,0.4-4.01,0.04-5.42-1.43
                      c-0.91-0.95-0.75-3.06-2.11-3.26c-2.41-0.34-1.28,1.47-2.42,2.41c-0.51,0.41-3.98,1.54-3.96,1.51c-2.04,2.96,1.41,4.23-4.35,3.13
                      c-2.75-0.52-3.97-1.47-4.96-3.95c-0.79-1.97,1.04-3.32-1.85-3.83c-2.77-0.49-3.07,3.12-6.17,0.57c-1.55-1.28-0.68-2.77-3.41-3.46
                      c-0.54,7.19-15.98,1.9-19.99,0.62c-0.16,1.72,0.72,2.79,0.59,4.38c-0.05,0.66-0.83,2.04-0.94,2.87c-0.14,1,0.5,1.87,0.2,3.19
                      C596.06,482.33,593.33,481.71,594.79,483.73z" />
                                        <path class="st0 st-4 state_8" d="M192.91,453.4c-0.14,1.28,0.83,2.3,2.17,1.99c0.13-4,4.72-2.29,7.86-1.81c1.47,0.22,3.35,0.07,4.76,0.36
                      c2.71,0.56,2.66,3.45,4.4,3.96c0.49-4.02,2.47-2.01,3.64-1.6c0.65-1.62,3.71-3.77,5.54-2.93c0.69,0.32,0.15,2.96,1.34,3.77
                      c2.28,1.55,3.83-0.22,5.91,2.05c1.02,1.11,3.19,3.72,3.37,5.27c1.44-1.21,0.82-2.33,2.68-2.47c0.46-0.03,4.23,2.61,4.46,2.92
                      c0.1,0.14,0.44,0.92,0.53,1.03c0.73,0.82-0.2,1.53,0.76,2.15c0.51,0.33,2.89-0.23,3.44-0.11c0.69,0.14,3.44,1.71,3.5,1.69
                      c1.01-0.43,0.81-3.66,1.84-4.49c0.66-0.54,4.12-1.11,4.97-0.26c0.82,0.82-0.14,3.03-0.12,4.29c1.37-0.01,2.54,0.28,3.53,1.24
                      c-1.98,1.23-4.64,1.9-5.03,4.53c-0.37,2.54,1.45,4.27,3.9,3.83c-1.76,3.95,0.04,2.47,1.55,2.15c2.11-0.44,0.57-2.57,3.46-1.03
                      c1.75,0.93,2.11,3.37,1.64,5.04c-0.54,1.95-4.81,4.31-4.13,6.48c0.32,1,1.87,0.34,2.4,0.96c1.6,1.88,0.86,2.95,2.01,4.92
                      c4.24-2.02,3.89,0.77,4.2,3.63c0.56,5.12,0.89,1.58,5.14,3.61c1.34,0.64,1.82,2.16,3.06,2.82c0.72,0.38,1.52,0.22,2.34,0.46
                      c2.02,0.58,3.55-0.18,4.53,2.3c0.23,0.58-0.46,3.33-0.24,3.57c0.51,0.53,5.24,0.23,5.65,0.24c1.41,0.02,1.42-1.05,3.18-0.23
                      c1.07,0.5,1.51,2.54,2.28,3.29c0.44-1.04,1.88-0.08,2.72-0.21c1.34-0.2,6.11-1.94,7.45-2.85c3.86-2.6-1.41-3.45-4.29-4.5
                      c1.15-0.83,0.94-1.88,1.4-2.88c1.31-2.84-0.79-2.12,3.49-3.6c4.88-1.69,8.7-2.27,9.09-8.08c0.15-2.22-0.73-4.57-0.03-6.76
                      c0.61-1.91,2.24-2.82,2.38-4.91c0.04-0.67-0.9-1.63-1.07-2.29c-0.67-2.51-0.02-3.52-1.85-4.39c-1.19-0.57-3.79-0.02-5.2-0.13
                      c0.66-0.99,1.78-1.86,2.24-2.92c0.55-1.27,0.1-3.67,1.23-4.65c-2.05-1.97-2.42-0.02-3.34-2.21c-1.33-3.17,2.15-4.59,2.63-6.57
                      c0.5-2.06-1.53-5.33,2.62-3.81c0.16,0.06,2.12,2.91,3.14,3.26c-0.25-1.01-7.92-10.38-3.68-11.18c3.15-0.6,2.68,6.77,7.25,4.22
                      c2.11-1.18,0.85-3.83,2.73-5.4c0.94-0.78,5.28-1.5,6.27-0.62c1.26,1.11,0.72,4.14,0.57,6.2c-2.31-0.36-1.08,1.02-1.9,2.16
                      c0.82-1.14-1.52,3.75-1.34,1.95c-0.09,0.95-1.66,0.11-0.46,1.71c0.32,0.42,2.99,0.45,3.44,0.5c2.55,0.31,5.11,0.45,7.67,0.6
                      c-0.15,0.59-0.13,1.03-0.06,1.64c2.16-1.04,4.6-3.8,7.23-3.01c3.18,0.95,0.28,3.79,2.22,6.11c1.79,2.14,2.72-1.33,2.54,3.09
                      c-0.24,5.86-5.5,0.67-5.54,5.33c-0.01,1.45,0.94-0.09,1.16,1.05c0.38,2.02-0.47,4.88,0.24,6.71c1.08,2.75,3.77,1.25,0.99,3.83
                      c-1.13,1.05-3.01,1.56-4.5,1.75c-1.19,0.15-5.22-1.32-5.56-1.16c-0.96,0.46-1.37,3.71-0.86,4.63c0.39,0.71,3.74,2.51,4.92,3.54
                      c0.67-6.27,3.45-1.33,7.48-3.68c3.33-1.95-0.41-1.75,0.77-4.23c0.34-0.71,1.61-0.37,2.16-0.92c1.51-1.49,2.61-1.63,3.5-4.2
                      c0.28-0.82,0.22-2.62,0.79-3.09c2.11-1.73,11.45,1.16,14.09,1.87c0.08-0.56,0.11-1.09-0.07-1.63c2.02-0.07,3.7,0.4,4.4-1.91
                      c0.42,3.22-0.04,5.52,4.27,4.68c-0.08,0.82-0.49,2.45,0.63,2.68c0.55-1.75,2.75-1.31,3.42-2.78c-3.41-2.09-1.45-9.34-2.68-12.64
                      c2.7-0.84,9.82,4.68,8.05-2.8c-1.04-4.41-7.09-2.54-8.73-7.79c8.87-0.62-1.01-4.1,2.58-8.39c0.92-1.1,6.15,0.04,7.51-0.11
                      c3-0.34,5.1-2.02,7.83-3.1c-0.35,0.77-0.41,1.63-0.32,2.46c5.56-1.46,0.44-7.32,0.56-10.89c-2.58,0.07-1.51,2.2-2.94,3.21
                      c-1.28,0.91-0.33-0.28-2.44-0.1c-3.22,0.28-7.19,0.72-10.78,0.34c-3.19-0.34-7.11-1.13-8.77-4.08c-1.82-3.24-2.47-8.32-3.79-11.91
                      c3.08,0.95,2.01-2.97,3.73-4.43c1.94-1.65,4.7-0.8,6.66-3.07c3.24-3.77,4.23-5.95,9.05-7.91c3.5-1.42,5.7-4.02,9.29-5.78
                      c1.11-0.54,2.36-1.78,3.26-2.18c2.14-0.95,4.22-0.68,6.29-2.16c0.79-0.89,1.63-1.73,2.52-2.52c1.1-0.37,2.21-0.66,3.35-0.85
                      c1.04-0.74,1.04-2.69,2.64-3.56c1.38-0.75,3.02-0.62,4.53-0.72c0.96,0.01,1.92,0.02,2.88,0.03c1.28,0.36,1.88-0.14,1.8-1.5
                      c0.26-0.24,1.99-3.64,1.96-3.51c0.5-2.62-0.1-2.07-1.16-4.44c-0.97,0.73-4.31,8.62-5.43,1.72c-1.71-0.03-2.06,1.79-4,1.58
                      c-1.42-0.15-1.12-1.9-2.82-1.68c-1.55,0.2-1.85,0.98-1.4,2.65c-2.62,0.19-9.38-1.47-8.18,3.25c-4.82,0.95-2.52-5.28-0.25-6.77
                      c0.67-0.44,0.59-0.7,1.24-0.91c1.11-0.36,2.5,0.19,3.63-0.08c1.43-0.34,1.25-1.71,3.49-1.69c-2.2-2.72-8.85,1.44-5.12-5.14
                      c0.78-1.37,3.01-1.15,2.2-3.09c-0.37-0.88-2.58-0.47-2.52-2.14c0.19-0.03,1.85-0.41,0.72-0.62c0.38-0.02,0.73-0.14,1.03-0.37
                      c-0.46-0.97-3.66-0.92-4.42-1.35c-2.41-1.36-2.61-3.31-3.45-5.86c-0.64-1.96-1.33-3.58-1.48-5.69c-0.08-1.1-0.26-2.43,0.06-3.51
                      c0.29-0.96,2.18-2.48,2.02-3.07c-3.19,2.85-5.22,4.38-9.73,3.68c-0.02-0.15-0.06,1.91,0.06,2.35c-3.38-1.04-2.84,4.29-6.11,1.9
                      c-2.43-1.78-0.3-15.34,1.84-16.75c-1.2-0.47-2.8-2.99-4.14-2.68c-0.11,2.89,0.43,2.29-0.7,3.07c-0.78,0.54-2.75-0.74-3.54-0.04
                      c-0.54,0.48,0.16,1.86-0.35,2.34c-1.19,1.13-1.62,2.28-4.22,0.63c-2.84-1.81-2.72-4.33-6.7-5.33c0.55,1.86-0.02,3.38,0.97,5.63
                      c-1.06,0.07-3.98-0.61-4.81,0.06c-1.92,1.53,1.22,4.83-0.05,6.06c-0.52,0.5-4.78,0.16-5.17-0.5c-0.65,1.11-1.68,0.36-2.58-0.57
                      c-1.75-1.81-0.8-3.8-0.34-5.78c1.05-4.51,3.01-7.3-1.41-11.25c-1.13-1.01-3.09-1.5-4.03-2.61c-0.98-1.16-0.9-2.66-1.75-3.21
                      c-1.3,0.24-2.52,0.03-3.66-0.64c-0.67-0.67-1-1.47-0.99-2.41c-0.86-1.51-2.01-3.67-2.55-5.39c-0.68-2.14-0.61-4.45-0.55-6.67
                      c0.06-1.58,0.19-3.16,0.38-4.73c-0.57-0.13-1.09-0.35-1.57-0.66c-0.49-1.65-0.18-4.64-0.78-6.04c-0.78-1.84-1.1-1.11-2.62-1.75
                      c-0.12-0.05,0.12-1.15-0.13-1.17c-1.59-0.1-2.9,1.56-4.52,1.6c-2.56,0.06-4.32-2.61-6.62-1.89c0.85-2.79-2.1-4.76-4.72-4.57
                      c0.03,0.01-0.32,1.67-0.27,2.03c-2.42-0.83-5.14-0.92-7.55-0.01c1.05-3.47-6.7-5.17,0.43-5.39c-0.05-1.93-0.04-3.58,0.19-5.42
                      c0.17-1.35,1.54-1.63,0.51-3.36c-0.85-1.43-2.12,0.71-2.95-1.39c-0.81-2.04,1.31-3.17,1.31-4.17c0.24-0.12,0.47-0.25,0.71-0.37
                      c0.32-1.04-0.12-1.49-1.32-1.35c-0.18-0.27-1.82-2.08-2.09-2.34c0.25-1.73-0.51-2.25-2.26-1.56c-1.06,0.12-2.11,0.06-3.15-0.17
                      c-2.11-0.32-3.91-0.97-6.09-1.09c-4.16-0.21-3.13-0.01-4.53-2.99c-0.51-1.09,0.49-2.87-1.8-2.64c-1.67,0.17-1.93,3.37-3.1,4.17
                      c-2.48,1.7-7.05-0.3-10.04,0.69c-4.16,1.37-3.62,6.19-4.8,10.01c-1.19,3.84-2.1,8.41-4.45,11.75
                      c-4.43,6.29-8.27,12.36-15.31,15.85c-6.35,3.14-12.51,4.85-16.33,10.98c-0.76,1.23-1.74,1.91-2.1,3.22
                      c-0.34,1.25,0.61,2.64,0.08,3.92c-1.27,3.1-5.63,3.27-7.62,5.81c-2.11,2.69-1.83,6.45-4.41,8.94c-2.53,2.44-5.96,2.59-9.26,2.54
                      c-4.32-0.08-8.54-0.79-12.8,0.43c-3.75,1.07-7.84,5.31-11.95,4.28c-6.85-1.73-3.96-10.18-8.8-12.56
                      c-7.73-3.81-12.99,6.47-16.51,11.05c-2.26,2.94-4.36,6.2-7.25,8.55c-2.73,2.22-6.66,3.21-9.11,5.78
                      c-2.24,2.35-1.71,4.48-2.61,7.38c-1.03,3.33-3.65,6.46-1.23,9.88c1.78,2.52,8.87,6.91,11.15,7.41c2.04,0.45,5.34-1.05,7.74,1.09
                      c2.19,1.94,2.53,7.51,1.48,10.19c-1.38,3.55-4.55,4.49-4.06,8.97c0.27,2.45,1.62,3.66,2.71,5.6c-0.02,0.46-0.04,0.92-0.05,1.39
                      c-0.41,1.15,0.03,1.77,1.33,1.83c1.16,1.76,1.39,2.18,3.49,3.06c2.47,1.03,7.88-0.22,9.78,1.19c2.31,1.72,1.19,5.39,1.56,8.05
                      c0.58,4.24,2.47,8.24,4.63,11.9c2.11,3.56,3.42,7.2,5.89,10.58C188.63,447.08,193.13,451.33,192.91,453.4z" />
                                        <g>
                                            <g>
                                                <path class="st0" d="M776.91,572.31c0.55-0.07,3.51-4.79,3.61-5.12c0.29-0.96-0.05-2.81-0.24-3.82
                          c-0.23-1.29-0.63-2.53-1.2-3.71c-0.95,0.16-1.87,0.07-2.77-0.25c-0.26,0.7-1.35,6.67-0.6,6.84c-0.55-0.19-0.92-0.03-1.1,0.49
                          C778.09,567.04,776.73,569.54,776.91,572.31z" />
                                                <path class="st0" d="M753.03,570.5c2.61,0.07,2.05-1.45,2.51-3.59c0.24-1.12,1.27-2.1,0.86-3.33c-0.91-2.75-1.98,4.5-1.94,4.37
                          C754.41,568.11,752.66,570.49,753.03,570.5z" />
                                                <path class="st0" d="M781.79,563.67c0.71,1.71,1.47,5.05,3.09,5.55c3.83,1.18,1.89-3.02,1.48-4.41
                          c-0.47-1.59-1.1-6.21-3.38-6.39C780.08,558.19,781.1,562.03,781.79,563.67z" />
                                                <path class="st0" d="M780.46,553.28c-0.31,1.09,3.59,3.86,4.91,3.02c0.93-0.59,1.08-2.42,0.4-3.19
                          C784.63,551.84,781.85,553.19,780.46,553.28z" />
                                                <path class="st0" d="M776.32,555.02c-1.07,1.13-1.93,0.6-2.74,1.47c3.23,0.94,5.99,2.94,6.33-1.14c0.14-1.69,0.78-2.38-1.2-2.9
                          C775.89,551.7,777.66,553.6,776.32,555.02z" />
                                                <path class="st0" d="M774.37,560.26c0.28,0.02,2.55-1.31,3.06-1.33c0.09-0.25,0.1-0.49,0.03-0.75
                          c-0.59-0.04-2.79-1.15-3.38-0.61C773.5,558.11,773.03,560.14,774.37,560.26z" />
                                                <path class="st0" d="M785.34,548.67c-0.45-0.98-3.38-3.05-4.39-3.08c-0.19,2.14,1.03,0.62,1.32,2.42c0.25,1.55-0.47,3.2-0.7,4.7
                          C782.11,550.49,787.65,553.72,785.34,548.67z" />
                                                <path class="st0" d="M780.24,546.24c0.3,0.01-3.74,2.9-3.52,2.49c-0.45,0.84,0.25,2.92,2.01,3.01
                          C781.45,551.9,782.65,546.34,780.24,546.24z" />
                                                <path class="st0"
                                                    d="M760.34,569.85c0.25-1.87-1.31-2.66-0.49-4.87C758.38,565.72,757.48,570.4,760.34,569.85z" />
                                                <path class="st0" d="M775.55,553.22c0.03-0.09,1.52-2.15,0.94-2.23c-2.68-0.41-6.57,1.27-5.51,4.68
                          C771.24,556.56,775.26,554.07,775.55,553.22z" />
                                                <path class="st0"
                                                    d="M766.23,570.01c0.3-1.4,1.02-7.19-0.15-6.67C764.55,564.02,762.87,569.35,766.23,570.01z" />
                                                <path class="st0 st-5 state_21" d="M736.81,570.46c-0.38,5.56-5.53,2.86-9,3.45c-4.93,0.84-11.5,6.36-13.29,10.97
                          c-2.11,5.46,1.73,9.29,3.37,14.02c2.08,6.02-4.98,1.74-5.15,7.88c1.53-1.08,6.9-4.19,8.65-3.81c-1.26,3.3-3.63,5.53-6.45,7.48
                          c-2.11,1.46-5.65,2.68-4.99,5.97c3.24,0,2.25,3.04,0.22,4.78c-1.68,1.45-4.48,1.69-6.32,2.9c-4,2.63-4.09,6.58-7.46,9.55
                          c-4.5,3.97-11.74,3.97-17.05,6.28c-3.31,1.44-6.39,3.18-9.85,4.25c-1.41,0.43-4.98,2.87-6,2.77c-0.19-3.61,2.09-2.61,4.57-4.55
                          c3.6-2.82,2.42-6.39-2.02-5.32c-2.29,0.55-6.76,3.83-8.1,5.56c-1.84,2.38-0.73,5.71-3.35,7.13c3.81-0.08,3.51-5.51,6.66-4.51
                          c-0.63,0.87-2.12,1.13-2.34,2.33c7.88-2.47,1.24,2.16-1.57,4.55c-2,1.7-4.35,2.91-6.04,4.96c-1.63,1.99-2.27,4.55-3.73,6.58
                          c-0.45,0.63-3.24,3.73-3.65,3.61c-1.43-0.42,0.29-2.6-0.54-3.33c-2.1-1.85-7.32,2.55-3.56,3.48c0.04-0.85-4.99,1.4-5.3,1.54
                          c0.22-0.1-2.09,1.43-1.88,1.12c-0.49-0.1-0.91,0.08-1.24,0.53c0.04,1.03,0.42,1.94,1.14,2.71c-1.22,2.98-5.93,4.91-8.64,4.29
                          c-1.69-0.39-2.92-1.53-4.69-1.83c-0.44-0.08-2.29,0.22-2.79,0.05c-2.95-1.01-1.79-1.84-3.84-4.76
                          c-2.67-3.81-2.73-0.22-5.11-3.12c-1.39-1.69,0.03-4.16-3.17-3.99c-0.01,0.8,0.24,4.11-0.55,4.41c-1.14,0.41-0.74-1.61-1.8,0.1
                          c-0.9-2.21-0.94-0.93-1.71-2.01c-0.65,1.46-1.06,3.02-1.23,4.61c-1.09-1.32-2.81-2.31-4.32-0.76c-2.62,2.67,1.2,1.76,1.31,3.34
                          c0.31,4.71-4.94,2.95-7.81,4.38c-2.17,1.08-0.45,1.51-1.51,3.48c-0.78,1.46-3.06-0.3-2.93,3.17c0.06,1.63,2.84,3.1,2.9,3.66
                          c-2.26,0.09-1.46,3.55-3.36,4.59c-3.19,1.74-3.13-3.51-6.74-2.3c-1.35,0.45,0.28,1.61-0.66,2.54c-0.36,0.36-5.38,3.99-5.36,3.99
                          c0.35,0.1,0.67-3.04,0.51-3.8c-0.33-1.58-0.92-1.53-1.48-2.33c-0.91-1.29-1.87-4.25-4.09-3.89c1.09-0.18-4.58,4.15-4.26,3.61
                          c-0.72,1.19,0.14,4.44,0.71,5.43c-2.61,1.22-2.17,4.57,0.08,5.08c0.03,0.69-1.02,1.51-0.96,2.65c-2.27-0.05-1.61,2.71-2.7,2.97
                          c-1.32,0.31-2.14-2.22-3.48-2.77c-2.44-1-3.76,0.56-5.55,1.6c-1.41,0.82-2.84,0.98-4.2,1.63c-1.89,0.9-1.4,1.9-2.67,2.81
                          c-1.42,1.01-3.96,0.92-5.52,1.14c-2.45,0.35-5.21,0.73-7.87,1.03c-1.12,0.13-2.47,0.61-3.59,0.55c-1.41-0.08-2.2-1.45-3.82-1.08
                          c1.98-1.21,3.69-1.05,5.58-2.56c1.57-1.25,3.21-2.96,4-4.84c1.65-3.89,0.34-7.14,4.93-9.3c1.35-0.64,2.75-0.13,4.07-0.93
                          c2.27-1.38,1.91-5.58,3.98-6.87c1.66-1.04,7.45-1.21,2.15-5.36c1.17-0.12,2.56-0.33,3.33-0.66c-0.28,0.12,1.59-1.66,1.42-1.53
                          c0.59-0.44,1.47-0.32,2.07-0.92c1.2-1.21,0.35-2.86,1.18-4.01c0.12-0.16,1.06-1.41,1.03-1.34c0.12-0.24,1.38,0.08,1.46-0.09
                          c0.21-0.44-0.12-1.21,0.06-1.62c1-2.25-0.81-6.83-1.21-9.11c-0.4-2.29,0.15-5.03-0.42-7.19c-0.76-2.91-2.51-5-5.17-5.24
                          c0.1-3.27,3.47-7.16,1.19-10.21c-1.09-1.46-3.3-0.33-3.28-2.85c-3.78,1.48-4.46-2.63-2.46-5.44c1.18-1.66-0.88-1.56,1.78-1.49
                          c1.41,0.04,1.21,0.66,1.05,1.64c3.12,0.21,9.43-0.86,11.12,2.01c0.79,1.35-1.08,4.9,1.69,5.31c1.1,0.17,1.41-0.64,1.61-0.7
                          c0.52-0.13,0.75-1.69,2.84-1.83c4.5-0.31,1.46,1.78,3.13,3.8c1.12,1.36,3.9,0.04,4.78-1.72c0.46-0.92,0.48-3.81,0.05-4.68
                          c-1.2-2.44-1.75-1.43-4.2-1.48c-5.9-0.12-6.39-1.88-5.6-7.06c0.32-2.1,1.31-4.61,1.08-6.74c-0.27-2.5-1.53-2.44-2.54-4.14
                          c-2.05-3.45-1.03-10.79-0.79-15.04c2.45,0.24,2.15,5.06,5.68,1.14c2.28-2.53,1.55-7.52,3.38-9.69c1.48-1.77,7.5-0.72,10.32-0.66
                          c1.62,0.03,7,1.78,8.08,1.32c3.36-1.43,0.62-7,4.75-8.29c1.38-0.43,3.36,0.91,4.04-0.46c0.69-1.39-1.35-2.29-1.55-3.3
                          c-0.26-1.33-0.16-2.73,0.2-4.03c0.46-1.69,1.88-2.41,2.3-3.17c0.62-1.13,0.46-2.28,0.86-3.29c-0.18,0.45,1.7-3.08,1.09-2.16
                          c0.43-0.65,4.09-2.98,4.19-3.49c0.29-1.59-3.08-2.96-2.93-4.71c0.21-2.35,1.14-0.87,2-2.31c0.8-1.33,0.31-1.95,1.34-3.24
                          c1.8-2.26,6.62-4.83,9.09-6.2c3.72-2.07,4.54-2.04,4.04-6.74c2.83-0.11,3.86,4.12,6.29,5.33c4.62,2.3,6.77,0.61,10.97-0.87
                          c3.1-1.09,6.28-0.41,9.53-0.9c2.85-0.43,6.34-3.3,8.89-3.26c0.19,3.26,0.6,7.83-0.56,10.36c-0.67,1.46-2.06,2.34-2.66,3.96
                          c2.85,0.04,5.34,2.2,8.1,2.08c4.05-0.19,4.87-4.42,9.2-4.32c3.07,0.07,5.67,2.22,8.62,2.63c1.65,0.23,1.85-1.29,2.65,0.03
                          c0.28,0.46-1.26,1.95-1.71,2.31c1.47,0.35,4.94,1.83,6.18,0.9c0.76-0.57,0.51-2.82,0.91-3.6c0.32-0.61,1.83-0.81,1.87-0.92
                          c0.71-1.82-0.89-3.61-0.83-5.71c0.03-1.07,1.08-2.1,0.93-3.7c-0.16-1.76-1.44-3.52-2.25-5.04c1.92-0.35,3.15,0.48,3.95,0.68
                          c0.38,0.09,2.03,0.53,3.58,0.63c3.39,0.22,7.55,2.54,7.44,6.57c2.74,0.34,2.58-2.01,4.28-2.21c2.63-0.31,4.82,2.4,4.2,4.91
                          c2.86-0.68,2.47,1.46,4.26,2.69c2.13,1.48,5.28,0,6.46,2.86c1,2.41-1.5,5.98,2.69,6.84c1.48,0.31,4-2.62,4.51-3.86
                          c1.94,0.2,1.36,3.46,2.19,4.53c1.14,1.47,3.21,1.61,4.76,2.37C735.13,566.66,736.99,567.76,736.81,570.46z M543.72,710.67
                          c1.06-0.38,1.23-0.81,1.22-2.02C543.76,708.72,543.79,709.68,543.72,710.67z" />
                                                <path class="st0" d="M773.37,560.88c-0.5-1.42-3.21-1.53-4.14-0.48c-0.32,0.36,0.05,2.14-0.03,2.58
                          c-0.49,2.57,0.18,5.4-0.13,8.01C772.51,571.3,774.22,563.35,773.37,560.88z" />
                                                <path class="st0"
                                                    d="M772.88,558.78c0.31-3.98-4-0.68-3.71,0.66C769.81,559.51,772.8,559.88,772.88,558.78z" />
                                                <path class="st0" d="M782.21,557.97" />
                                            </g>
                                        </g>
                                        <path class="st0 st-6 state_23" d="M297.78,561.63c0.49,2.69-0.07,5.86,2.07,8.03c2.19,2.23,3.85,0.96,6.53,0.74c5.39-0.43,7.92,0.24,10.55,4.8
                      c2.24,3.88,3.8,4.55,8.46,4.61c4.8,0.06,9.35,0.03,14.33-0.32c3.57-0.26,7.34,0.33,10.1,2.45c2.25,1.73,1.62,4.27,2.28,6.84
                      c0.75,2.9-0.62,2.3,3.17,2.49c0.52,0.03,4.66,0.4,5.08,0c0.6-0.57-0.51-2.42,0.09-2.9c1.08-0.87,3.67,0.32,5.12-0.67
                      c1.96-1.34,1.69-2.07-0.79-2.45c1.7-3.33,7.86-5.41,6.24-9.47c2.14,0.1,1.73-1.84,2.75-2.49c3.19-2.03,7.44-1.94,10.73-1.6
                      c2.75,0.28,1.73-0.04,3.46-1.07c1.94-1.17,2.81-2.65,5.67-2.26c4.81,0.66,5.12,5.98,7.91,9.16c-1.4,0.21-2.55,1.13-3.12,2.42
                      c1.11,0.05,1,1.08,1.76,1.52c0.74,0.43,1.45,0.05,2.34,0.23c3.9,0.76,8.45-0.13,11.98-1.93c1.24,0.38,1.92,0.01,2.04-1.11
                      c0.27-0.98,0.83-1.77,1.69-2.37c2.39-1.47,3.57,0.99,5.42,0.49c1.32-0.35,2.11-2.99,3.94-2.03c1.54,0.8-1.36,3.39,1.27,3.78
                      c-0.8-0.12,2.59-1.17,2.55-1.18c1.17,0.09,2.08,1.57,3.05,2.01c2.37,1.09,3.76,1.3,6.45,0.68c2.71-0.63,2.07-0.16,3-1.86
                      c1.01-1.83-0.69-2.13,0.25-2.89c0.95-0.77,5.23,0.85,6.25,0.99c0.13-2.08,0.39-0.16,2.25-1.72c2.27-1.92,0.28-2.94,3.89-2.09
                      c0.34,0.57,0.68,1.14,1.02,1.71c0.7,0.5,1.47,0.67,2.32,0.52c3.9,1.44,3.16,3.1,7.38,2.85c2.33-0.13,3.85-0.59,6.21,0
                      c1.92,0.48,3.16,1.41,5.23,1.58c4.2,0.34,5.99-2.74,9.33-2.7c0.29,0,2.4,1.03,2.83,1.25c2.71,1.42,2.86,3.1,5.19,5.49
                      c2.07,2.14,2.07,1.56,4.52,1.54c1.42-0.01,2.24-1.17,2.92,0.13c0.74-1.68,2.55-1.84,3.22-4.61c0.69-2.9-0.44-5.88-0.52-8.74
                      c2.16,0.45,3.69-0.47,4.08-2.51c0.26-1.39-0.95-2.73-0.97-4.08c-0.04-2.59,0.43-1.64,1.11-3.52c0.06-0.15,1.17-0.48,1.42-1.01
                      c0.41-0.85-0.58-2.63,0.06-3.29c0.95-0.99,3.01,0.46,4.3,0.53c0.07-2.01-0.7-2.68-0.21-4.77c0.21-0.91,0.79-1.7,1-2.63
                      c0.62,0.31,2.11,0.42,2.48,0.4c0.28-7.23-1.32-5.9,5.44-7.1c0.74-0.13,1.55-0.85,2.25-0.9c0.93-0.07,2.42,0.73,3.17,0.59
                      c0.42-0.08,4.39-2.22,5.15-2.75c0.88-0.61,1.92-2.23,2.7-3.02c0.57-0.58,1.68-0.5,2.19-1.21c0.66-0.91,0-1.91,0.42-2.78
                      c0.75-1.57,2.17-2.16,2.98-3.64c0.52-0.94,0.23-2.26,0.69-3.25c0.69-1.52,2.52-1.88,2-3.81c3.73-0.17,7.08,0.36,7.17-4.3
                      c0.05-2.41-1.28-4.37-2.98-5.97c-0.83-0.78-2.66-1.28-3.16-1.79c-0.98-0.99-1-1.67-2-2.2c0.12,0.06-2.89-1.12-3.32-1.21
                      c-2.3-0.47-3.45,1.4-5.57,0.36c-1.8-0.88-2.19-3.37-1.57-4.84c0.65-1.54,4.04-2.55,3.73-4.45c-0.25-1.55-3.24-1.1-3.58-2.96
                      c-0.46-2.49,2.98-3.11,4.64-2.75c1.14,0.25,1.16,2.21,1.76,2.41c1.34,0.46,2.36-0.1,3.63-0.19c3.82-0.29,7.26-0.14,10.94,0.71
                      c1.2,0.28,9.85,0.73,10.08,3c0.09-0.44,0.16-2.15,0.68-2.38c0.01,0,2.42-0.55,2.22-0.35c0.27-0.27,0.92-1.22,1.11-1.41
                      c0.15-0.6,0.29-1.2,0.44-1.81c0.67-0.74,1.49-1.06,2.47-0.95c3.56-3.33-0.81-3.64-1.38-7.17c-0.19-1.14,2.36-3.15,2.83-4.74
                      c0.11-0.38,0.23-0.87,0.28-1.26c0.14-0.48,0.27-0.97,0.41-1.45c0.31-1.02-0.06-1.46-1.13-1.32c-0.07-0.28-0.69-1.56-0.73-3.03
                      c-0.35-0.06-0.68,0.05-1.02,0.14c-0.1-1.6-0.1-3.2,0.04-4.79c3.91,2.22,3.29-0.67,1.05-2.5c-1.32-1.07-0.62-1.29-2.9-1.15
                      c-2.5,0.15-5.12,0.72-7.85,0.7c0.18,5.4-0.46,1.59-3.83,2.04c0.75-3.16-1.62-1.37-2.23-2.78c-0.27-0.64,0.35-2.09-0.05-2.64
                      c-0.79-1.07-1.86-0.15-3.27-0.61c-0.93-0.3-0.62-0.56-0.66-1.9c-5.39,0.22-6.73-0.22-6.56-5.76c-1.37-0.1-2.91,0.49-4.24-0.12
                      c-0.64-0.29-1.59-2.21-1.75-2.27c-0.93-0.31-3.48,0.56-4.11-0.03c-1.04-0.97,1.35-3.82,0.13-5.13c-2.18-2.35-3.12,2.37-2.98,3.75
                      c-2.16,0.41-3.58-0.77-4.17-2.55c-1.28-0.06-1.86,0.99-2.19,2.03c-0.14-0.55-0.57-2.33-2.21-1.6c1.41,2.72-1.91,4.62-0.2,7.36
                      c-2.94,0.21-6.03-0.12-8.9,0.1c-1.59,0.12-4.2,1.53-6.08,0.81c1.52-2.09,1.41-4.13,1.64-6.56c-0.23,0.6-0.65,1.14-0.89,1.74
                      c0.28-1.84-0.2-3.28-2.14-2.93c0.7,0.97,0.21,0.66,0.06,1.86c-0.92-0.05-1.66,0.54-2.42,0.26c-0.14-0.05-2.21-1.83-2.26-2.02
                      c-0.22,0.44-0.81,1.58-1.01,2.4c-0.35-0.77-0.49-2.07-1.64-1.55c0.43,1.34,0.53,6.32-2.39,4.61c-0.92-0.54,0.45-2.8-0.28-3.33
                      c-1.97-1.42-2.22,0.73-2.57,0.85c-1.36,0.48-2.06,1.55-3.48,1.38c0.04-1.96,1.92-1.82,2.62-3.07c0.06-0.11,0.09-2.16,0.45-2.91
                      c1.2-2.57,2.53-1.07,0.11-4.26c-1.45-1.91-2.67-1.3-2.9-4.2c-1.51,0.28-3.09,0.71-3.09,2.33c-1.08-0.41-2.25-0.68-3.4-0.69
                      c0.59,3.2-3.11,2.87-4.67,3.86c-0.66,0.42-0.66-0.61-1.11-0.24c-1.34,1.09,0.37,3.02-0.44,4.06c-0.82,1.06-2.46,0.8-4.32,0.86
                      c-1.43,0.05-3.25,0.31-4.62-0.05c-0.61-0.16-0.42-1.41-0.8-1.87c-0.7-0.84-0.67,1.53-0.64,1.85c-2.54,0.11-3.94-0.76-4.57,2.55
                      c-7.04-0.33,1.05-6.17,1.26-7.69c-2.75,0.01-3.23-1.55-5.42-2.81c0.36,1.84,2.34,5.29,0.5,6.75c-0.37,0.29-7.59,0.41-8.66,0.37
                      c0.04-0.89-0.38-3.44-0.81-3.73c-1.63-0.3-2.01,1.91-3.27,1.81c-2.47-0.19-0.08-0.61-1.35-2.32c-0.35-0.46-1.97-0.73-2.07-1.25
                      c-0.54-2.61,1.2-4.02,3.65-4.26c-1.14-3.03-0.17-3.03-0.03-5.49c-1.8,0.7-3.66,2.61-3.14,4.62c-2.56-0.7-2.7,3.81-5.97,2.01
                      c-1.13-0.62,0.86-1.95-1.32-2.2c-2.23-0.26-2.12,2.84-3.43,3.63c2.73,0.22,2.53,2,3.45,3.98c0.04,0.76,0.11,1.52,0.19,2.27
                      c0.41,0.13,0.83,0.27,1.24,0.4c0.6,1.73,0.54,2.18,0.75,4.1c0.16,1.45-0.18,2.48,0.6,3.78c0.45,0.75,2.05,0.15,2.39,0.82
                      c1.48,2.95-0.08,6.17,0.01,9.34c2.28-0.02,3.67-1.24,4.97-0.19c1.64,1.32,1.53,3.6,1.26,5.46c-0.26-0.01-1.12-0.28-1.22,0.1
                      c1.58,0.67,2.55,2.27,3.62,3.54c-2.11,0.92-1.09,2.98-2.17,4.03c-0.99,0.97-4.94,3-6.29,3.42c0.27-1.33-0.24-2.35-1.92-2.08
                      c-0.06,0.58-0.11,1.12,0.09,1.69c-2.47,0.04-2.6-1.76-3.82-3.1c-0.67-0.74-0.35-1.56-1.14-2.29c-0.86-0.79-2.42,0.13-3.33-1.21
                      c-1.07,1.1-0.69,6.61-4.4,3.68c-0.88-0.69-0.19-1.65-0.3-3.1c-0.1-1.35,0.51-2.27-0.55-3.47c-0.57-0.63-1.91-0.22-2.31-0.71
                      c-2.82-3.45-0.16-2.14-0.04-4.94c0.17-3.83-3.85-7.36-3.34-10.98c4.38,0.41,5.31-3.93,5.44-7.35c0.96-0.11,1.25,0.16,1.75-0.97
                      c0.6-1.37,1.2-0.4,1.02-1.9c-0.14-1.19-1.54-0.9-2.05-1.94c-1.64-3.33-1.24-8.15,2.67-8.13c-0.03-5.43,2.27-3.51,6.37-4.32
                      c1.81-0.36,6.37-1.47,6.61-2.91c0.11-0.64-1.34-2.2-1.36-3.16c0.01,0.3,0.98-2.79,0.63-1.93c0.2-1.01,0.77-1.43,1.68-1.25
                      c0.57-1.27,1.11-2.55,1.62-3.84c0.35-0.68,1.01-1.3,1.42-2.06c1.22-2.27,1.68-5.07,2.66-6.96c1.51-2.92,3.33-4.28,2.46-8.26
                      c-0.42-1.92-1.89-3.46-2.55-5.34c-0.56-1.6,0.4-2.11-0.73-3.31c-0.39-0.42-3.11-2.06-3.58-2.39c-1.32-0.94-2.4-1.87-4.12-1.88
                      c-0.65,4.56-17.64-6.3-18.53,4.64c-0.05,0.63-2.31,0.82-4.17,0.86c-2.43,0.06-4.35-0.06-6.38,1.32c-0.7,0.48-0.37,1.76-0.86,2.19
                      c-1.13,0.98,0.68-0.81-2.26,0.99c-4.52,2.77-9.05,5.08-13.92,7.39c-3.25,1.54-3.83,2.78-6.47,4.68c-2.29,1.65-5.02,1.4-7.34,3.3
                      c-1.73,1.42-2.51,3.48-3.88,5.15c-1.85,2.25-2.88,2.07-5.38,3.37c-3.04,1.58-0.97,0.34-2.57,2.59c-0.06,0.08-1.72,2.4-1.71,2.29
                      c-0.22,1.97,1.82,4.56,2.35,6.36c1.53,5.12,2.93,6.3,8.51,6.93c4.19,0.48,8.24-1.38,11.93,0.21c0.53-1.75,3.16-5.42,5.32-3.49
                      c1.14,1.02-1.4,4.3,1.65,3.66c0.07,1.56,1.04,7.42-0.01,8.88c-0.6,0.84-3.55,0.81-4.93,1.04c0.16-0.6,0.17-1.19,0.1-1.81
                      c-2.06,1.12-3.71,1.95-6.08,2.2c-1.3,0.13-5.68-0.72-6.39,0.19c-2.09,2.65,6.06,8.19-1.93,8.19c1.82,4.28,7.83,0.99,8.18,7.08
                      c0.1,1.76-0.53,4.66-2.4,5.33c-2.3,0.83-3.22-1.86-5.25-1.94c0.44,2.34,0.03,4.81,0.52,7.13c0.11,0.5,1.59,3.48,1.59,3.49
                      c0.02,1.7-1.22,3.22-3.17,4.06c-1.54,0.67-0.82,0.83-3.24-0.42c0.07-1.2-0.58-1.7-1.96-1.49c-0.57-0.25-1.15-0.38-1.75-0.38
                      c-0.56-0.28-0.34-1.55-0.36-2.28c-1.97-0.45-2.53,0.61-1.77,2.35c-2.64-1.07-9.43-3.07-12.23-2.76c-4.06,0.45-1.93,2.33-4.16,5.28
                      c-1.49,1.98-2.07,1.78-4.29,2.52c0.75,2.87,1.4,4.43-1.62,5.22c-1.23,0.32-2.92-0.37-4.21-0.12c-3.38,0.64-1.85,1.13-3.18,4.27
                      c-0.98-0.6-1.68-1.61-2.6-2.2c-0.66-0.42-3.35-1.32-3.51-1.48c-0.74-0.74-0.7-1.25-0.78-2.92c-0.2-4.19,0.65-4.51,4.01-4.18
                      c3.25,0.32,5.01,0.5,8.04-1.59c-4.24-0.37-1.45-5.81-1.95-8.07c-0.16-0.73-1.52-0.63-1.58-2.5c-0.05-1.63,1.22-3,2.62-3.54
                      c0.61-0.24,1.78,1.87,2.64,0.93c0.42-0.45,0.51-3.5,0.26-3.81c-0.4-0.52-2.51,0.04-3.1-0.67c-0.55-0.66-0.07-4.94-0.09-5.62
                      c-2.59-0.1-3.58,1.35-5.68,2.21c-3.46,1.41-1.65-0.3-3.13-0.63c-1.95-0.44-5.77-0.29-7.99-0.99c-0.79-0.25-2.22-0.05-2.85-0.81
                      c-2.06-2.5,0.93-2.59,1.63-4.02c0.38-0.79-0.05-1.91,0.42-2.82c0.76-1.49,1.83-0.89,1.6-2.96c-0.32-2.79-3.83-2.75-5.57-0.49
                      c-1.46,1.9,0.23,3.86-3.07,4.94c-4.19,1.38-4.08-2.29-6.41-4.02c-1.22,2.99,6.38,8.74,4.38,10.69c-1.07,1.05-5.77-2.66-5.8-3.48
                      c-0.26-0.06-0.5-0.03-0.72,0.07c-0.54,0.67,1.1,2.44,1.01,3.21c-0.29,2.41-0.66,0.67-1.6,2.44c-0.82,1.53-1.39-0.49-1.39,2.07
                      c0,3.5-0.16,0.13,1.57,2.04c1.25,1.38,1.66,1.69,1.79,2.58c0.2,1.37-1.01,4.48-2.12,5.61c4.75,0.06,4.49-0.92,5.29,3.27
                      c0.41,2.15,1.99,4.22,1.46,6.44c-0.54,2.29-2.25,3.23-2.45,5.89c-0.33,4.25,1.17,8-2.99,10.83c-1.96,1.33-4.5,1.58-6.64,2.51
                      c-4.23,1.84-1.01,1.66-3.13,4.72c4.1,1.45,7.28,3.63,2.49,6.26c-1.41,0.77-4.95,2.46-6.33,2.9c-0.22,0.07-0.23,0.3-0.52,0.37
                      c0.14-0.03-3.77,0.09-3.39,0.24c-2.11-0.85-3.55-6.47-5.89-2.74c-0.35,0.56-0.29,4.07-0.16,5c0.42,2.82,0.55,1.95,2.4,3.28
                      c1.29,0.92,1.48-0.72,2.77,1.26c0.68,1.03,0.04,3.11-0.35,4.12c-0.46,1.21-2.08,3.29-3.06,4.02c-1.34,1-2.44,0.64-3.72,1.29
                      c-1.46,0.74-1.28,1.49-2.78,2.62c-2.1,1.57-3.16,0.97-5.55,1.06c-0.14,2.48,11.1,2.42,7.16,6.75c-0.83,0.91-8.36-1.15-8.49,2.19
                      c-0.04,0.95,2.77,3.29,3.02,4.82c0.37,2.24-1.2,3.1-0.66,5.59c0.91,4.15,2.96,1.59,5.18,1.81c1.41,0.14,3.29,1.44,4.6,1.33
                      c2.34-0.18,1.36-1.43,2.78-2.01c4.12-1.69,2.68,1.06,6.05,2.19c-0.43-0.02-0.66,0.19-0.67,0.64
                      C296.92,561.79,297.35,561.71,297.78,561.63z" />
                                        <path class="st0"
                                            d="M448.4,440.6c-0.91,0.04-1.05,1.41-0.99,2.23C448.23,442.32,448.56,441.58,448.4,440.6z" />
                                        <path class="st0" d="M512.11,447.4c-0.38,0-0.86,0.42-0.95,0.58c-0.06,0.1,0.35,0.58,0.73,0.32
                      C512.02,448.2,512.08,447.84,512.11,447.4z" />
                                        <path class="st0" d="M398.37,579.94c0.06-2.74-1.79-2.04-3.83-2.24c0.37,1.28,0.7,2.78,1.45,3.89
                      C396.2,580.55,397.37,579.9,398.37,579.94z" />
                                        <path class="st0 st-7 state_22" d="M491.54,679.43c0.21,0.2,0.43,0.39,0.64,0.59c-0.41,0.16-0.82,0.51-1.21,0.7c2.3,1.5,2.06,2.85,5.04,2.97
                      c1.75,0.07-0.25-1.47,2.93-0.71c0.62,0.15,3.01,2.7,3.43,3.17c2,2.3,3.27,4.83,4.31,7.59c0.23,0.6,0.75,1.44,0.84,2.03
                      c0.29,1.78-0.57,2.85-0.44,4.35c1.42,0.5,2.55-1.86,4.41-1.42c1.07,0.26,0.56,1.03,0.81,2.4c3.64-0.67,1.7-0.71,2.44,2.18
                      c0.32,1.25,1.13,2.38,1.56,3.82c0.45,1.52-0.24,3.26,0.19,4.7c1.21,4.1,3.07-0.38,6.02-1.86c1.52-0.77,1.91-0.16,3.32-1.07
                      c1.33-0.87,3.24-2.97,3.97-4.43c1.09-2.19,0.27-5.51,1.33-7.28c1.2-1.99,5.12-2.79,6.88-3.66c3.03-1.5,3.45-5.1,5.88-7.52
                      c1.26-1.26,3.58,0.8,2.26-2.44c-0.38-0.93-2.25-1.71-3.15-2.13c5.37-2.02,10.76-1.93,10.01-9.33c5.34,1.77,1.06-9.89,0.89-12.8
                      c-0.16-2.71-0.38-9.13-5.04-7.64c-0.37-4.36,3.11-7.9,0.44-11.11c0.39,0.47-3.18-2.31-2.43-1.92c-0.54-0.28-2.26,0.58-2.69,0.07
                      c-1.52-1.78-0.86-6.39,0.28-8.27c1.91-3.16,5.3,0.1,8.82,0.22c2.09,0.08,6.45,0.02,7.55,2.13c0.33,0.64-0.84,5,0.63,5.1
                      c0.11-2.82,5.42-3.29,7.31-2.15c1.82,1.1,1.2,1.2,1.3,4.06c1.97-0.07,2.51-2.37,2.42-3.88c-0.2-3.37-1.96-1.84-4.93-2.25
                      c-8.3-1.14-4.8-6.37-4.24-12.82c0.39-4.47-2.54-4.89-2.91-8.92c-0.23-2.52-1.9-13.17,1-13.61c3.76-0.57,2.54,6.24,5.7-0.2
                      c0.93-1.89,1.25-7.48,2.34-8.7c0.98-1.1-0.52-0.29,2.64-0.67c2.99-0.36,6.47,0.22,9.5,0.27c1.53,0.03,5.89,1.88,6.98,1.38
                      c1.93-0.88,0.92-4.9,1.71-6.38c1.3-2.44,3.83-1.86,6.27-1.84c-0.44-3.03-2.43-3.24-1.33-7.05c0.66-2.26,1.97-2.52,2.93-4.06
                      c0.45-0.73,0.29-1.89,0.61-2.81c0.89-2.5,2.02-3.8,4.43-5.21c-0.93-1.41-2.77-2.69-2.51-4.63c0.24-1.75,1.52-1.52,2.21-2.67
                      c0.79-1.31,0.25-1.88,1.46-3.4c1.24-1.56,3.44-2.43,5.04-3.55c2.15-1.5,7.05-2.87,7.94-5.24c0.69-1.85-0.32-3.72-2.05-4.31
                      c3.79,0.64,3.99-3.48,6.65-5.61c2-1.6,2.78-1.4,3.74-3.42c0.56-1.18,0.43-3.47,0.86-4.87c-3.73,0.08-6.71-1.26-8.49-4.64
                      c-0.47-0.89-0.44-2.58-0.86-4.02c-0.59-2.02-1.82-2.02-2.1-2.86c-0.98-2.86,1.81-7.95,0.05-10.16c-1.55-1.94-3.69,0.48-5.57-1.23
                      c-0.85-0.78-1.26-2.47-1.68-3.21c-0.42-0.72-1.41-2.24-1.96-3.06c-1.46-2.22-3.94-2.67-5.49-4.68c-2.26-2.92,0.01-5.94-4.89-6.38
                      c0.1,0.34,0.17,0.71,0.21,1.06c-1.69-0.33-3.27,0.77-3.97,1.91c-1.93,3.12,0.56,5.59-4.75,6.34c-1.51,0.21-4.5,0.32-5.97-0.32
                      c-1.28-0.56-1.16-1.65-2.4-2.16c-2.87-1.19-2.03-0.19-4.11,0.77c-0.9,0.42-2.11-0.07-2.85,0.68c-0.82,0.82-0.2,2.49-1.35,3.5
                      c-0.85,0.75-1.88,0.09-2.67,0.68c-0.7,0.53,0.26,1.89-1,2.43c-1.58,0.67-1.24-1-1.77-1.07c-0.73-0.1-3.59-0.99-4.55-1.03
                      c-0.92-0.04-3.54-0.14-5.14-0.16c0.28-2.77-6.95-1.95-8.9-1.82c-2.02,0.14-4.05,1.2-6.11,0.2c-1.06-0.51,0.35-3.17-2.6-2.19
                      c-3.23,1.07,1.63,2.35,2.03,3.07c1.68,3.04-1.7,3.56-2.79,5.72c-0.82,1.64-1.11,3.51,1.26,4.12c0.36,0.09,2.6-1.27,3.54-1.15
                      c1.36,0.17,2.1,1.16,3.08,1.91c1.82-2.22,4.4,1.29,6.15,3.09c3.32,3.41,7.22,10.96,0.39,13.14c-2.77,0.89-3.42-0.35-5.08,2.47
                      c-0.71,1.22-0.58,2.84-1.26,4.06c-0.48,0.87-1.74,1.33-2.13,2.15c-0.51,1.07-0.31,2.94-0.91,3.96c-0.76,1.3-2.03,1.2-3.05,2.06
                      c-1.16,0.98-1.59,2.09-2.79,3.07c-2.67,2.18-4.06,2.22-6.68,2.59c-1.67,0.23-3.31,0.47-5.2,0.81c-4.93,0.89-2.26,0.11-3.37,4.51
                      c-0.73,2.9,0.11,1.16-0.64,2.33c-1.48,2.33-2.06-1.38-3.22,1.94c-0.27,0.77,0.32,1.04,0.31,1.3c-0.18,4.51,0.89,3.66-4.09,2.95
                      c-0.15,5.61-0.79,2.25-2.6,5.43c-1.67,2.92,4.56,9.06-2.97,9.42c1.29,6.16,1.07,11.52-5.7,12.79c5.27,0.69,2.37,5.14-0.55,6.76
                      c-1.18,0.66-2.61,1.07-3.64,1.62c-0.33,0.18,0.03-1.24-0.75-1.24c0.37,1.54-0.04,4.09,0.55,5.42c0.72,1.62,1.55,0.93,2.58,2.04
                      c4,4.3,0.26,7.31-0.38,12.17c5.14-1.39,3.55,0.66,3.21,5.43c-0.23,3.23-0.38,4.18-2.94,6.02c-2.16,1.56-4.26,0.79-3.88,4.38
                      c5.02-2.1,7.53,8.37,1.37,8.24c0.12,0.75,1.06,1.36,0.78,2.18c-0.21,0.61-1.2,1.69-1.27,2.27c6.27-4.5,6.54,3.31,8.55,6.37
                      c-1.26-1.92,3.92,2.29,2.15,1.59c1.54,0.61,3.71-0.26,4.88,1.49c1.57,2.33-0.54,2.13-0.75,4.08c0.64,0.28,1.21,0.58,1.94,0.62
                      c-1.47,0.99-1.8,2.64-3.01,3.63c-1.45,1.18-2.06,1.4-3.81,1.51c-3.44,0.22-3.96-1.97-6.27-3.45c-1.7,1.77-4.71,3.23-6.09,4.83
                      c-0.91,1.06-1.41,3.12-1.88,4.55c-1,3.05-0.47,3.26,0.87,6.04C495.96,677.24,488.39,676.55,491.54,679.43z" />
                                        <path class="st0 st-8 state_24" d="M234.8,620.38c0.55-2.69,2.07-1.48,3.7-2.5c1.92-1.2,3.3-4.41,6.63-3.62c2.81,0.67,3.68,2.79,1.56,4.6
                      c-0.5,0.43-2.25,0.38-3.01,0.94c-0.04,1.24,3.64-0.66,4.43-0.5c1.4,0.29,0.1,1.45,1.99,1.71c0.77,0.1,1.7-0.41,2.17-0.56
                      c0.59-0.96,0.66-0.02,1.29-0.72c0.6-0.67,1.98-4.22,2.33-5.64c0.51-2.08,2.83-9.6-0.83-9.69c1.63-3.07,0.55-4.17,3.98-3.15
                      c0.2,0.06,1.65,1.91,2,2.08c0.63,0.32,2.05-0.32,2.59,0.08c0.59,0.44,0.22,1.6,0.64,1.91c1.3,0.95,2.21,1.76,4.4,0.65
                      c3.84-1.94-0.26-1.05,1.16-3.69c0.83-1.55,3.43-0.12,4.27-1.17c0.4-0.5-0.05-2.99-0.16-3.58c-0.47-2.81-1.72-4.4-3.96-6.05
                      c-1.26-0.93-1.77-1.14-3.1-1.79c-0.53-0.26-1.58,0.18-2.06-0.12c-0.94-0.59-2.02-1.64-0.97-2.7c0.6-0.61,4.4-0.11,5.67-0.73
                      c2.65-1.3,1.3-1.84,3.03-3.96c1.22-1.49,2.53-0.55,3.94-1.47c0.07-0.04,2.37-2.1,1.36-1.67c-0.02,0.01,2.09-0.54,2.08-0.53
                      c3.05-2.31,5.56-1.12,8.95-2.56c-1.81-1.46-4.18-2.14-6.51-1.83c-1.89,0.25-3.01,1.84-4.62,2.06c-1.74,0.23-4.77-2.68-4.89-3.98
                      c-0.17-1.87,1.92-2.84,1.67-4.43c-0.23-1.45-3-1.63-2.11-3.6c0.22-0.48,0.32-0.19,0.58-0.46c0.11-0.11,3.04-0.23,3.45-0.42
                      c1.21-0.55,0.95-1.91,2.59-2.27c-3.64-3.54,0.2-6.64-1.99-10.33c-1.3-2.19-2.86-2.6-0.97-4.99c1.79-2.26,5.39-1.66,7.82-1.68
                      c-0.14-3.67-6.83-0.88-7.62-4.74c-0.68-3.34,1.86-1.23,3.9-1.79c2.34-0.64,1.78-2.53,3.37-3.46c0.28-0.17,2.51-0.59,2.33-0.47
                      c0.74-0.47,1.87-0.29,2.78-0.89c1.26-0.84,3.66-3.89,3.22-5.66c-0.67-2.74-3.35-0.84-4.97-3.57c-1.13-1.9,0.44-4.32-0.14-6.21
                      c-0.96-3.15,0.07-1-2.29-2.11c-1.98-0.94-2.19,0.79-3.41-1.78c-0.16-0.33,0.71-1.76,0.6-1.95c-1.68-2.96-2.52-1.34-5.4-2.29
                      c-1.51-0.5-2.13-2.23-3.41-2.86c-4.66-2.26-5.97,0.86-6.61-5.56c-0.13-1.31,0.66-1.94-0.53-2.74c-0.7-0.47-2.19,1.25-2.72,1.02
                      c-1.31-0.58-0.85-2.45-1.32-3.35c-0.58-1.11-1.15-1.4-1.81-2.26c-1.51-1.95-3-1.22-1.4-4.52c0.71-1.47,3.24-2.61,3.43-4.38
                      c0.11-1.08,0-3.16-1.35-3.55c-1.53-0.44-1.04,1.32-2.29,1.76c-2.2,0.77-1.83,0.81-3.47-0.71c-0.23-0.58-0.25-1.19-0.07-1.81
                      c-0.95-0.1-1.75-0.49-2.41-1.18c-1.94-3.5-1.19-6.62,2.48-8.45c-3.09-0.1-1.9-1.46-1.67-4.37c-4.43-0.6-2.21,0.17-3.97,2.43
                      c-3.06,3.95-1.94,1.35-4.92,0.77c-1.69-0.33-4.31,0.59-5.6-0.17c-0.68-0.4,0.09-2.33-0.33-3.11c0.07,0.12-4.02-2.95-3.93-2.96
                      c-0.98,1.5-1.78,2.81-3.61,3.28c0.04-1.09-0.13-2.22-0.65-3.17c-0.08-0.15-3.04-4.35-2.86-4.22c-2.67-1.98-6.8,1.07-7.05-4.35
                      c-1.47,0.16-4.63,5.4-6,1.77c-1.67,1.05,0.14,4.48-3.24,2.12c-1.99-1.39-0.97-2.48-3.65-3.23c-1.52-0.43-5.14-0.99-6.75-1.14
                      c-0.06-0.01-2.19,0.21-2.27,0.23c-0.62,0.08-1.24,0.15-1.86,0.23c-0.01,0.43-0.03,0.85-0.04,1.28c-0.13,0.05,0.01,0.5-0.45,0.6
                      c-0.9,0.19-2.01,0.45-2.88-0.06c-0.57-0.34-1.23-2.39-1.45-2.48c-1.06-0.44-3.62-0.21-3.87,1.88c1.9,0.32-0.04,3,0.24,4.09
                      c0.73,2.8,1.45,1.68,4.7,1.88c-0.53,3.71-6.45,2.57-8.5,3.95c-0.78,0.53-0.7,2.51-1.15,2.76c-0.78,0.43-3.1,0.23-3.98,0.18
                      c-3.1-0.17-4.87-0.45-5.41-3.53c-0.67-3.83,1.19-4.19-3.63-4.1c-2.81,0.05-4.24,0.92-6.71,1.81c-1.69,0.61-3.68,0.57-5.28,1.28
                      c-1.99,0.88-3.44,3.56-5.4,4.3c-2.91,1.09-7.98,0.26-10.22-1.71c-1.44-1.27-1.88-3.17-3.64-3.96c-1.05-0.47-4.92-0.45-5.97-0.4
                      c-1.78,0.09-2.06,0.46-3.7,0.63c-1.07,0.11-3.37,0.19-4.62,0.19c-2.02,0.01-3.45-1.02-5.09-1.19c-2.59-0.25-2.55,1.85-3.7-1.72
                      c-1.52-0.22-2.29,2.65-2.62,3.64c-2.16,0.04-0.73-4.49-2.4-5.24c-0.23-0.1-1.63,7.92-1.76,8.55c-0.23,1.12-0.13,4.11-1.08,4.98
                      c-1.09,1.01-7.02,0.05-8.52,0.05c-4.99,0.01-9.35-1.66-11.58,3.6c-1.38,3.26-5.77,12.16,2.66,9.82c2.53-0.7,1.39-0.92,2.78-2.58
                      c1.51-1.81,1.04-1.84,3.41-2.8c1.54-0.62,2.8,0.08,4.48-0.79c0.95-0.5,2.55-2.84,3.72-2.51c-1.87,3.02-1.3,2.97-4.64,4.75
                      c-0.88,0.47-4.61,1.55-5.08,2.13c-0.81,1.01-1.05,4.21-0.53,5.32c0.39,0.85,1.66,0.63,2.62,1.75c0.7,0.82-1.18,1.54-1.46,1.87
                      c0.84-0.02,4.09,0.57,4.39,1.81c0.22,0.91-1.69,1.75-1.36,3.01c1.34-0.03,1.25-1.81,2.55-1.91c0.11,1.24-1.72,3.2-1.29,3.88
                      c1.07-0.47,2.25-2.6,3.69-2.13c-0.03,0.32-2.04,3.37-2.78,3.27c3.91,5.06,9.37,7.38,14.59,11.37c2.4,1.84,4.18,4.22,7.07,5.07
                      c1.04,0.31,2.2,0.02,3.29,0.35c2.96,0.89-1.58,1.24,3.22,1.73c0.81,0.08,3.65-0.41,5.19-0.23c4.08,0.46,5.51-0.66,8.69-1.52
                      c1.76-0.48,3.68,0.28,5.43-0.43c1.01-0.41,1.31-1.75,2.32-2.06c0.59-0.18,8.68-2.22,2.77-2.35c-0.27-2.68,2.54-0.74,2.9-0.89
                      c0.1,0.45,0.37,0.72,0.8,0.81c1.01-0.21,1.43-0.84,1.25-1.89c1.61-0.93,2.21-2.55,4.58-2.12c1.11,0.21,0.91,3.91,3.72,1.52
                      c-2.05,3.31-3.54,5.24-5.05,8.88c-1.27,3.07-4.59,4.41-6.43,7.36c-0.6,0.41-0.87,1.01-0.81,1.79c0.25,1.55-0.45,1.95-2.1,1.21
                      c0.09-0.03-2.89,0.51-2.43,0.6c-3-0.56-2.72-2.43-6.44-0.02c3.38-0.05,1.03,3.07-0.76,4.1c-2.75,1.58-1.84-0.98-3.98-0.79
                      c-2.34,0.2-3.99,3.53-5.76,3.64c-0.4-2.6-3.75-1.12-5.87-1.01c0.83,0.11,1.01,0.66,0.56,1.66c-0.86,0.25-1.51-0.96-1.78-0.91
                      c-0.41,0.07-2.03-0.04-2.78,0.02c-2.24,0.18-3.86,1.78-5.84,2.41c0.2-1.11,1.73-0.77,1.46-2.11c-3.58,0.27-0.34-3.49,0.27-4.76
                      c-0.44,0.38-5.58,1.18-6.11,0.58c-1.67-1.89,2.12-1.76,2.14-3.03c-2.33-0.15-5.16,2.7-5.32,5.23c-0.16,2.58,4.81,9.03,6.17,11
                      c3.03,4.41,6.91,9.01,10.74,12.68c1.9,1.83,4.01,3.53,5.8,5.48c1.39,1.51,3.26,5.8,5.73,5.52c-3.97,3.91,24.89,26.15,30.08,26.86
                      c1.29,0.18,1.85-0.79,3.04-0.81c0.9-0.02,1.67,1.02,2.48,1.19c-0.21-0.04,4.8,0.93,4.28,1.03c1.27-0.25,2.8-1.75,4.07-2.14
                      c2.95-0.9,6.89-1.08,9.7-2.24c1.05-0.43,1.97-1.84,3.31-2.36c0.96-0.37,3.79,0.44,3.67-1.49c-0.98,0.08-2.44,0.11-2.8,1.31
                      c-1.26-1.85,2.85-2.32,3.7-2.42c3.27-0.38,4.81-0.89,7.76-1.98c2.57-0.95,4.57-1.42,6.82-3.24c0.53-0.53,1.18-0.76,1.97-0.71
                      c0.02-0.7,0.04-1.41,0.07-2.11c0.38-0.55,1.42-1.86,2.08-2.74c1.81-2.42,4.07-3.99,4.77-7.02c0.57-2.43,0.67-4.75,0.9-7.08
                      c0.21-2.1-0.89-3.64-1.04-5.43c-0.23-2.87,1.45-5.9,3.43-7.87c-0.97,0.14-1.89-0.02-2.76-0.48c0.58-0.36,1.73-3.38,1.79-3.4
                      c1.2-0.44,2.29,1.29,3.45,1.27c0.39,0,3.03-1.15,3.02-1.13c0.73-1.55-2.8-0.82-3.44-0.87c0.07-0.18,3.16-2.45,3.32-2.47
                      c1.73-0.24,3.03,0.95,4.46,1.65c4.3,2.09,6.24,0.45,10.57,0.46c-3.37,1.74-3.74,4.8-8.1,2.58c-1.65-0.84-2.41-2.9-4.15-1.88
                      c-1.72,1.01-0.57,4.07-2.22,4.93c2.6,2.08-2.06,5.49,1.22,6.73c2.17,0.82,5.42-2.67,8.35-1c-1.74,0.66-3,1.52-4.86,1.87
                      c-0.87,0.16-2.14-0.5-2.91,0.02c-1.53,1.04-2.55,6.17-1.93,8.21c1.58,0.28,6.51-0.23,6.66,1.8c-2,0.12-4.1-0.26-6.06,0.29
                      c1.88,1.65,0.83,2.52,3.97,1.76c1.69-0.41,2.3-2.66,4.28-1.85c-1.35,0.01-5.72,5.64-6.27,6.99c0.06-0.15-0.68,3.73-0.74,4.25
                      c-0.09,0.72,0.41,1.79,0.37,2.18c-0.06,0.53-0.7,2.09-0.5,2.93c0.51,0.03,3.31-0.45,3.43,0.66c-1.03,0.19-1.74,0.78-2.12,1.74
                      c1.43-0.02,2.87-0.07,4.3-0.15c0.28,1.27-1.85,0.89-2.74,1.55c1.17,0.58,0.77,2.2,0.83,3.18c1.36-0.13,2.72-0.17,4.09-0.14
                      c-1.18,2.63-0.89,1.91-4.05,2.83c1.27,2.43,1.41,3.09,4.25,3.27c0.1,1.01-0.35,1.54-1.35,1.58c-1.44,0.05-1.87,0.88-1.31,2.47
                      c-0.64,2.13,0,4.4-1.03,6.52c2.31,0.33,2.38,1.98,0.91,3.43c-1.16,1.14-2.45,0-3.51,0.76c-0.59,0.42-0.07,2.3-0.62,2.77
                      c-0.48,0.41-2.51,0.59-2.74,1.14C231.4,618.92,232.71,620.38,234.8,620.38z" />
                                        <path class="st0 st-9 state_27" d="M254.52,780.78c-3.24,0-2.84-0.32-4.1-3.41c-0.96-2.36-2.6-4.11-3.61-6.24c-0.97-0.4-1.64-1.1-1.98-2.1
                      c0.97-0.61,1.52-1.47,1.67-2.6c0.02-0.22-1.14-3.81-1.27-4.4c-0.94-4.26-2.27-8.77-2.6-13.11c-0.28-3.61,1.47-9.22-1.06-12.38
                      c1.04,0.29,1.6-0.08,1.68-1.1c-2.31-0.2-0.87-1.44-1.08-3.09c-0.02-0.13-0.44-1.83-0.46-1.62c-0.09,0.96,0.1-3.83,0.67-1.9
                      c-0.44-1.5-1.17-1.83-1.78-3.17c-1.04-2.28,4.19-2.33-1.01-2.74c1.69-1.85,0.71-4.09,0.5-6.2c-0.35-3.41-1.22-1.77,1.05-4.01
                      c-2.53-2.13-1.11,1.86-2.2-2.62c-0.58-2.4,0.12-3.41-0.89-5.89c-0.68-1.67-3.6-4.81-0.29-5.83c-2.6,0.8-1.44-4.01-3.38-4.01
                      c0.68-1.68,1.01-2.33,0.6-3.76c-0.44-1.54-2.21,0.29-1.69-2.51c1.12-0.07,3.87-0.7,4.11,1.09c-0.02-0.95,0.04-1.89,0.19-2.83
                      c-1.36-0.26-1.55,1.17-3.45,1.01c0.44-0.49,0.67-2.19,0.38-2.77c-0.49-0.17-0.97-0.34-1.46-0.51c-0.09-0.94-0.12-1.88-0.08-2.83
                      c0.07-4.05,0.52-1.66,2.38-2.14c-1.5-1.6-4.43-6.56-3.9-8.81c1.18-5.02,3.78,0.22,6.58-2.27c-2.69-1.38-5.75-1.85-3.42-5.22
                      c0.8-1.16,2.4-1.11,2.85-1.67c1.45-1.81-0.21-2.76,0.11-5.13c-1.58-0.23-0.51,2.77-0.96,3.24c-0.89,0.93-2.26,0.07-3.12,0.9
                      c-1.04,1-0.45,4.91-2.52,3.32c-1.1-0.84,0.46-2.13,0.49-2.73c0.04-0.83,0.2-1.83,0.22-2.4c0.04-1.52-1.2-3.59-0.96-5.01
                      c0.68-4.07,1.88-1.43,4.92-3.4c-2.93-0.3-5.69-0.06-5.2-3.94c0.37-2.96,2.21-1.55,3.88-3.69c-2.26-1.02-2.79-3.5-3.07,0.57
                      c-4.01,0.38-1.12-3.12-1.28-5.6c-0.11-1.69-0.84-0.54-0.97-2.83c-0.1-1.82,0.22-3.32,2.03-3.57c-1.66,0.28-2.66-8.64,1.57-2.64
                      c0.4-3.04-4.87-5.53,0.06-6.9c0.91-0.25,2.17,0.65,3.2,0.22c0.59-0.24-0.16-1.65,0.56-1.8c0.35-0.37,0.74-0.56,1.17-0.56
                      c1.92-0.67,2.55,0.03,1.9,2.09c1.03,1.26,0.92,2.43,2.59,3.42c1.76,1.05,5.46,1.08,6.68,0.19c0.06-0.87,0.08-1.74,0.08-2.61
                      c0.36-0.05,0.73-0.04,1.09,0.03c0.36-0.32,3.09-0.91,3.66-1.27c2.7-1.71,1.02,1.12,2-3.58c0.47-2.25,1.27-3.86,1.69-6.27
                      c0.28-1.64,1.21-2.39,1.1-4.27c-0.15-2.39-1.43-2.85-0.74-5.07c-0.3-0.03,5.13,3.15,4.83,2.85c0.32,0.33,0.34,1.94,0.55,2.12
                      c0.8,0.7,2.54,1.06,3.57,2.5c0.28-4.14,6.69-0.79,4.54-6.47c3.31-0.89,3.59,0.29,4.31-2.64c0.62-2.52-0.75-5.86-2.29-7.77
                      c-0.84-1.05-2.81-2.95-3.97-3.53c-0.24-0.12-4.27-0.47-4.36-0.77c2.76,0.07,6.33-0.21,8.09-2.51c1.06-1.38-0.12-2.09,1.52-3.22
                      c1.24-0.86,3.27-0.16,4.63-0.79c0.26-0.12-0.03-1.53,0.33-1.77c0.47-0.32,3.5-2.07,4.02-2.22c1.43-0.41,3.76-0.01,5.27-0.16
                      c1.35-0.13,2.26-0.57,3.68-0.28c-2.48-2.15-4.52-3.91-7.85-4.33c-2.91-0.36-6.91,2.56-8.68,1.55c-2.7-1.53-0.22-4.07-0.02-5.26
                      c0.18-1.01,0.13-2.31-0.03-3.3c-0.07-0.45-2.09-0.16-2.18-0.83c4.21,0.21,6.33-4.01,10.87-3.97c1.11,0.01,1.96,0.99,3.01,1.1
                      c3.23,0.34,1.61-0.5,4.25-1.6c1.96-0.82,1.6-1.25,3.52,0.97c1.91,2.2,1.09,5.05,2.8,7.8c2.41,3.88,4.63,2.78,8.61,2.43
                      c3.27-0.29,5.98-0.37,8.22,2.12c1.65,1.84,1.75,5.3,4.3,6.49c3.29,1.54,8.9,0.43,12.47,0.94c5.69,0.82,10.74-2.07,15.44,1.22
                      c2.89,2.02,3.3,1.6,3.68,5.95c0.07,0.83-0.74,1.63-0.5,2.09c1.42,2.77,12.22,3.71,11.42-0.91c2.03,0.09,6.45-0.19,6.66-2.68
                      c0.06-0.69-1.47-3.11-1.57-2.54c0.24-1.3,1.62-1.41,2.39-2.05c0.25-0.2,0.43-0.39,0.65-0.58c2.89-2.43,3.04-5.57,6.04-7.34
                      c1.74-1.02,9.3-4.58,7.66,0.26c1.4-2.24,2.66-0.48,4.41-1.51c2.31-1.35,0.84-3.17,4.34-3.54c2.3-0.24,7.5,3.27,6.39,5.99
                      c-0.71,1.73-4.7,0.7-5.93,0.75c0.93,2.53,1.27,6.97,4.65,7.18c-0.96-3.8,1.24-1.14,2-1.09c3.64,0.21,6.99,1.28,10.95,0.11
                      c1.93-0.57,5.96-1.32,7.04-2.28c2.49-2.23,0.73-2.74,4.56-2.88c2.13-0.08,3.06,1.57,4.38-1.25c0-0.05-0.16,2.51,0.14,2.63
                      c0.16,0.77,0.6,1.17,1.32,1.21c0.72,0.4,1.37,0.22,1.95-0.51c31.15,5.18-32.45-8.34,2.13-0.53c0.83,0.19,2.08,1.82,2.91,2.17
                      c1.76,0.76,8.25,1.02,9.87-0.3c1.1-0.89,0.49-2.21,0.49-4.3c2.41,0.12,4.67,1.09,7.11,1.12c-1.49-2.19,0.84-0.91,1.5-1.83
                      c0.63-0.88-0.07-2.5,1.22-2.83c-0.14,0.04,3.67,2.74,4.14,2.94c0.83,0.34,1.75-0.17,2.58,0.3c0.69,0.39,0.45,1.4,0.96,1.72
                      c2.13,1.34,3.15,0.96,5.85,0.67c4.77-0.5,8.46,2.54,13.4,1.63c2.26-0.42,4.35-2.3,5.57-2.33c1.42-0.04,3.98,1.09,4.98,2.03
                      c1.4,1.32,1.88,3.8,3.46,5.11c1.87,1.56,4.43,0.79,6.08,1.93c3.78,2.6-0.61,3.91-3.16,5.77c-0.45-2.1-2.73-1.17-3.25-0.45
                      c-0.03,0.05,0.6,5.93,0.67,6.13c0.8,2.35,1.86,1.44,2.85,2.85c3.32,4.72-1.12,5.78-0.52,10.76c0.32,2.63,0.56,1.56,3.47,0.95
                      c-0.07,1.89,0.34,6.06-0.52,7.72c-1.02,1.97-2.78,1.88-4.13,2.67c-2.09,1.23-2.89,3.25-2.45,6.33c1.69-0.93,3.72-0.78,4.71,1.01
                      c0.16,0.29,0.2,2.54,0.06,2.89c-0.66,1.68-1.08,0.62-1.88,1.58c-0.14,0.17-1.31-0.21-1.51,0.04c-0.67,0.84,0.57,2.14,0.45,2.77
                      c-0.28,1.44-1.63,3.07-0.4,4.74c5.06-2.62,4.83-1.02,7.16,3.11c0.72,1.27,2.55,3.91,3.54,4.33c1.35,0.56,4-0.43,4.7,1.42
                      c-0.1-0.25-0.94,4.25-0.84,4c-1.45,3.56-4.41,4.01-7.91,1.92c-2.45-1.46-1.44-2.11-3.92-0.91c-1.41,0.68-2.45,2.49-3.67,3.44
                      c-1.55,1.2-1.18-0.36-2.03,0.68c-1.17,1.44-0.59,2.33-1.17,3.77c-0.61,1.5-1.66,1.68-1.85,3.85c-0.08,0.88,0.08,2.2,0.49,3
                      c0.19,0.37,2.51,2.22,2.52,2.45c0.06,1.5-7.5,3.85-3.52,6c-2.84,1.1-8.39-0.26-9.65-3.34c2.36-0.93,0.24-5.46-0.65-7.48
                      c-0.51-1.16-1.88-0.22-2.03-1.7c-0.1-1.04,1.93-2.67,2.3-3.55c0.71-1.72,0.92-4.95,1.13-6.83c0.62-5.49-1.39-4.74-5-7.46
                      c-2.38-1.79-3.38-3.22-6.68-2.41c-4.18,1.02-0.29-1.38-2.96,1.7c-1.37-3.92-3.11,1.51-2.88,1.5c-1.29,0.07-1.85-1.42-1.5-2.73
                      c-1.54,0.38-1.65,0.27-1.46-1.11c-1.48-0.02-3.64,0.4-4.2-1.27c0.41,1.22-0.74-0.64-0.86-0.61c-1.52,0.4-2.63,3.99-1.95,5.59
                      c-3.71-2.11-4.35-1.32-8.66-1.17c-0.1-1.68,2.67-3.55,1.87-4.92c-0.54-0.92-3.82-0.15-4.69-0.13c-0.19-6.07,0.03-5.3-6.42-5.75
                      c-1.12-0.08-2.64,0.19-3.68,0.07c-2.19-0.26-1.59-0.25-3.49-1.21c-1.67-0.85-3.73-1.88-4.94-3.38c-0.31,0.72-2.02,1.81-2.06,2
                      c-0.35,1.59,2.22,2.61,2.26,3.92c0.05,1.62-1.91,2.29-2.28,3.86c0.1-0.42,0.48,2.91,0.47,2.78c0.48,4.9-1.63,4.87-5.46,6.31
                      c-3.51,1.32-1.01,1.88,0.93,4.85c-1.88,1.88-3.92-0.46-5.03-1.25c-0.78-0.55-0.12-1.52-0.71-1.81c-2.84-1.4-3.83,1.36-4.36,3.09
                      c-0.56,1.85-1.19,3.88-2.06,5.28c-1.54,2.49-2.35,1.26-0.94,4.18c0.98,2.03,1.86,4.25,3.94,4.37c-0.09,1.37-4.21,3.69-5.15,5.17
                      c-0.8,1.25-1.59,5.05-2.12,5.41c-0.64,0.43-3.46-0.09-4.46,0.15c-0.28,0.07,0.38,1.87-1.82,1.1c0.37,0.52,1.19,5.28,1.13,5.68
                      c-0.5,3.37-1.6,0.3-4.03,0.7c-1.48,0.24-1.07,0.59-2.36,1.75c-1.55,1.4-3.68,4.58-5.57,5.39c-2.68,1.15-7.64-1.41-8.65,3.56
                      c3.82,0.4,0.21,2.41,0,2.82c-0.82,1.61,0.43,1.92-1.43,3.05c-1.56,0.95-3.84,1.01-3.47-1.16c-3.36-0.72-2.07,3.68-0.4,5.04
                      c-0.93,1.74-3.05,1.36-3.39,3.85c-1.86-1.64-1.18-2.98-4.88-2.43c-2.94,0.44-4.01,2.75-4.42,5.39c-1.75,1.79-3.1-2.3-4.43,0.94
                      c-0.13,0.31-0.06,3.91-0.02,4.51c0.11,1.77,2,3.61,1.32,4.81c-2.89-2.29-6.62-1.95-9.95-3.25c-0.11-0.04-3.63,1.47-5.63,0.22
                      c-2.06-1.3-1.36-2.28-4.15-3.03c-0.08-0.02-1.25,0.33-1.76,0.19c-1.39-0.38-0.84-1.26-2.14-1.85c-4.04-1.84-3.13-1.08-3.7,1.89
                      c-0.49,2.59,0.68,4.51,0.65,6.72c-0.03,2.19-1.24,2.15-1.02,4.96c0.08,1.05,0.74,1.97,0.73,3.24c-0.02,4.32-0.14,0.64-2.37,0.4
                      c-2.03-0.21-1.92,0.29-1.92,2.17c-2.69,0.08-8.23-1.72-10.65,0.13c-0.64,0.49,0.52,2.28,0.12,2.51c-2.47,1.43-3.19-0.69-5.11-1.77
                      c-2.84-1.6-6.4-1.07-9.49-0.75c3.67,0.57,2.01,3.06,1.02,4.36c-1.71,2.25-1.11,1.91-3.91,2.98c-1.4,0.54-7.78,2.45-5.7,4.99
                      c-0.75,0.19-1.5,0.35-2.26,0.48c-0.22-3.85-6.17-3.88-6.4-0.1c-1.68,0.18-3.13,0.13-3.23,2.25c-0.87-0.3-2.52-2.07-3.24-0.94
                      c-1.45,2.25,2.78,4.07,3.21,5.69c0.2,0.76-3.14,2.87-0.8,5.09c2.1,2,2.75-1.61,4.85,2.33c2.83,5.32-5.56,1.8-3.98,5.92
                      c1.59,4.12,4.85-0.96,1.78,4.66c-0.88,1.61-1.15-0.12-1.18,3.06c-4.42-0.66-4.37,0.74-8.7,3.21c-2.13,1.22-0.96,2.7-4.34,1.07
                      c-1.03-0.5-1.77-1.36-2.62-1.78C259.43,780.65,257.47,780.74,254.52,780.78z M399.33,576.83c-0.14-0.23-0.28-0.47-0.43-0.7
                      C398.73,576.8,398.67,577.19,399.33,576.83z" />
                                        <path class="st0" d="M268.99,810.62c-0.01-0.59-0.15-1.16-0.4-1.7c1.33,0.17,2.28,1,3.49,1.43c-0.12-1.53,1.38-3.41,1.64-5.21
                      c0.18-1.3-0.19-1.43,0.47-2.09c0.03-0.84-2.37-1.56-1.66-3.07c0.45-0.97,3.28,0.28,3.09-1.77c-0.15-1.66-2.21-1.25-2.58-2.22
                      c-0.67-1.75,1.54-3.46,0.26-5.29c2.27-0.85-0.72-3.9-2.21-4.53c-0.87-0.36-2.53,0.03-3.54-0.14c-1.63-0.27-3.19-1.34-4.86-1.45
                      c0.5,0.09-1.45-1.84-2.18-2.11c-2.39-0.89-5.54-0.51-8.07-0.35c1.57,3.48,2.3,8.89,7.39,8.41c-0.87,0.08-2.59-0.08-2.86,1.05
                      c-0.44,1.85,3.96,0.88,4.61,1.79c-1.15-0.14-2.28-0.04-3.39,0.31c1.97,3.67,2.33,7.48,3.54,10.5c0.35,0.88,2.32,3.48,2.93,4.26
                      C266.4,810.73,265.43,810.77,268.99,810.62z" />
                                        <path class="st0 st-37 state_37" d="M395.39,693.44c-1.54,2.52,5.2,1.75,5.89,2.4c1.51,1.41-0.47,1.96-1.06,2.04c-0.19,2.07,0.71,3.87,0.32,6.04
                      c-0.02,0.12-1.19-0.13-1.22,0.12c-0.08,0.7,0.63,1.44,0.57,2.09c-0.32,3.19,0.31,3.61-1.79,6.25c-0.41,0.51-2,1.18-2.25,1.58
                      c-0.36,0.59,0.39,1.97-0.04,2.53c-0.21,0.28-1.45,0.3-1.49,0.38c-0.24,0.5-0.44,2.22-0.82,2.88c-0.31,0.53-2.44-0.55-2.58,0.69
                      c1.35,0.08,3.33,1.05,4.8,1.3c1.37,0.23,5.5-0.27,5.67,1.96c0.16,2.12-1.61,1.54-3.17,2.19c-3.2,1.33-4.23,4.05-6.34,6.58
                      c-0.75,0.9-2.06,1.21-2.88,2.55c1.5,1.98,3.03-0.12,3.88,2.72c0.67,2.25-1.85,5.64-1.93,7.56c-0.11,2.7,2.41,5.08-1.15,5.12
                      c0.28,3.48,2.25,4.47,0.51,7.37c-0.06,0.1-1.94,2.24-2.28,2.46c-1.22,0.78-5.27-0.71-5.31,1.12c1.63,0.22,12.62,2.02,13.26,3.13
                      c0.77,1.36-0.54,2.41-1.38,3.32c-4.62,5.02,0.18-3.83-2.49,1.62c-0.48,0.97-0.19,3.56-0.19,4.66c-0.01,3.78-0.24,4.54,3.71,4.45
                      c2.5-0.06,1.93-0.08,4.32,0.67c1.34,0.42,3.07,1.39,4.53,1.22c3.15-0.37,2.4-3.11,4.37-0.17c0.41-0.49,4.43-0.5,4.78-0.54
                      c2.74-0.32,0.92,1.74,4.11-0.49c0.63-0.44,1.26,0.44,1.82-0.46c0.76-1.22-1.2-2.52-0.83-3.6c0.78-2.33,3.11-1.43,5.42-1.53
                      c2.93-0.12,5.37-1.04,8.72-0.6c1.79,0.24,4.03,3.33,5.89,1.06c0.46-0.57-0.48-2.12-0.18-2.43c1.38-1.41,2.36,0.63,3.73,1.6
                      c-0.2-3.68,0.2-7.29,4.93-7.22c3.51,0.05,3.77,3.57,6.43-0.4c0.37-0.55,0.79-3.95,1.05-4.69c0.36-1.03,0.37-2.02,1.15-3.06
                      c0.85-1.13,1.58-1.49,2.82-1.93c0.46-0.16,1.9,0.11,2.45,0c0.58-0.12,1.36-1.25,1.98-1.51c0.55-0.23,1.47,0.46,2,0.25
                      c0.82-0.32,1.76-1.31,2.52-1.54c0.02-0.01,2.63-0.61,2.16-0.38c0.2-0.1,2.47-1.55,2.51-1.57c2.3-0.69,1.35-0.41,3.41,0.68
                      c0.61,0.32,1.85,0.24,2.52,0.45c-0.21-0.07,0.39,1.52,0.32,1.52c0.94,0.02,1.66-0.72,2.44-1.1c1.26-0.61,2.14-1.28,2.79-2.52
                      c0.88-1.68-0.58-2.87,0.3-4.03c-4.94-0.24-0.85-4.42,0.98-5.67c0.5-0.34,2.96-2.03,3.6-1.92c1,0.17,1,1.66,1.76,2.3
                      c0.76,0.64,1.57,0.74,2.39,1.57c0.45,0.46,0.77,1.6,1.26,2.19c1.3,1.57,3.38,3.11,5.19,3.35c2.51,0.34,2.47,0.24,2.3-1.92
                      c-0.2-2.61-1.21-2.01-3.74-2.68c-3-0.78-3.45-0.9-3.26-3.92c0.22-3.56,0.78-2.2,3.59-0.39c1.62-0.92,1.3-2.98,2.9-3.73
                      c1.9-0.89,3.89,0.87,4.39,2.36c1.36-0.58,5.13,0.6,6.42,1.16c-0.02-2.8-0.62-1.64,0.84-3.93c0.14-0.21,0.87-2.07,0.92-2.09
                      c1.15-0.42,3.58,0.37,4.95,0.22c1.39-0.15,2.68-0.59,4.11-0.77c0.21-0.71-0.86-1.73-0.07-2.43c0.85-0.74,3.01-1.47,4.14-1.9
                      c2.45-0.95,5.69-0.29,7.17-3.04c1.32-2.45,0.67-6.17,2.44-9c0.67-1.08,1.2-1.9,2.11-2.62c0.77-0.61,2.68-0.22,2.84-1.35
                      c-3.34,1.08-7.25,1.2-10.81,1.49c-1.6,0.13-3.49,0.73-5.07,0.66c-1.66-0.07-2.17-1.21-3.96-0.95c-4.21,0.62-5.24,4.18-6.25-2.12
                      c-0.56-3.52-1.67-5.98-1.37-9.31c-1.73,0.74-2.07-0.17-2.78-0.33c-0.27-0.06-0.09-1.22-1.09-1.46c-0.47-0.11-0.53,0.94-0.97,0.92
                      c-3.48-0.11-2.22,1.13-2.88-1.98c-0.11-0.54,0.56-1.43,0.46-2.21c-0.07-0.54-0.96-2.28-1.15-2.74c-1.31-3.17-4.21-9.53-7.91-10.06
                      c-0.5-0.07-1.96,1.23-3.17,1.06c-1.79-0.25-1.96-1.63-3.25-2.37c-2.11-1.2-4.08-0.85-6.55-1.68c-2.47-0.83-5.05-2.23-5.66-4.86
                      c1.12-0.51,1.39-1.34,0.82-2.5c-0.17-0.53-0.34-1.06-0.51-1.59c-0.29-0.69-0.28-1.45-0.64-2.13c-0.45-0.83-1.79-0.38-2.07-1.81
                      c-0.38-2.03,0.87-2.32,1.53-3.89c0.86-2.03,1.79-5.86,1.82-8.12c0.04-3.53-5.21-6.91-7.92-7.7c-0.29-0.08-2.53-0.14-2.98-0.02
                      c-0.67,0.17-1.55,1.64-2.06,1.64c-3.48,0.04-0.08-0.14-2.05-1.13c-1.34,1.61,0.35,3.64-3.03,2.25c-1.65-0.68-0.68-2.89-2.99-1.99
                      c0.99-2.49-2.47-0.96-3.53-2.98c-0.09,2.13-1.38,3.75,0.91,5.01c-2.68,1.23-3.32-0.72-5.53-1.46c-0.32,0.49-5.98,1.13-6.6,0.53
                      c-1.98-1.91,1.16-3.63,1.48-5.22c-3.55-0.29-3.68,1.13-4.85-1.05c-0.89-1.66,0.89-2.91-0.84-3.93c-0.58-0.34-2.9-0.24-3.64-0.29
                      c-1.89-0.13-5.76,0.67-7.5-0.04c-0.59-0.24-1.7-2.22-3.1-2.81c-4.29-1.8-0.55,1.62-1.25,4.78c-0.17,0.78-1.62,0.52-1.73,0.96
                      c-0.14,0.57,0.58,0.53,0.52,0.8c-1.19,5.82,1.38,9.6-7.01,10.45c1.61,0.77,3.17,2.93,2.39,4.15c-0.8,1.26-5.11,1.7-5.92,1.25
                      c-2.26-1.25-1.47-6.43-4.1-1.32c-0.68,1.32-0.4,2.52-0.93,3.75c-0.71,1.66-2.68,1.8-3.28,3.24c1.32,1.21,3.25,6.57,5.07,4.1
                      c0.43,3.68-1.28,3.45-3.42,5.67c-1.52,1.58-3.04,7.37-4.2,8.11c-2.18,1.39-5.04-0.85-5.48,3.08
                      C395.88,688.87,397.42,690.14,395.39,693.44z" />
                                        <path class="st0 st-11 state_29" d="M295.21,892.2c0.5-0.15-0.02-0.37-0.26-0.45c0.92-0.46,2.11-0.37,2.61-0.12c1.08,0.55,1.33,4.35,1.89,4.77
                      c1.06-3.39,5.85,0,4.37,1.86c1.13,0.01,1.64-0.26,1.7,0.82c0.83-0.74,1.47-0.57,2.24-0.99c-0.28,2.47,0.89,3.1,1.84,5.1
                      c0.54-1.1,2.32-1.34,2.96-0.28c0.55,0.9-0.86,1.69-0.87,2.26c-0.02,0.98-0.68,1.8,0.07,3.26c1.09,2.12,0.67,0.44,2.38,1.72
                      c2.09,1.57,2.91,3.71,4.46,5.45c0.45,0.51,2.61,2.23,3.19,2.52c0.82,0.42,2.25,0.2,2.81,0.58c1.47,0.98,1.31,1.12,2.35,2.41
                      c1.26,1.55,0.37,1.71,2.77,2.65c4.7,1.85,7.51-3.74,7.56,2.63c3.42-0.44,5.38,3.55,8.26,4.83c1.28,0.57,2.64,1.07,3.82,1.66
                      c0.08,0.36,0.15,0.72,0.23,1.08c0.72-0.05,1.43-0.09,2.15-0.14c1.84,1.31,2.25,0.59,2.44,3.53c2.11-0.77,3.77-0.49,5.93-0.64
                      c2.98-0.19,1.93,0.24,3.1-1.45c1.53-2.21,1.1-4.35,4.33-5.38c3.14-1,3.6,0.07,5.68,1.81c1.22-4.58,8.68-0.55,11.87-0.12
                      c0.62-8.75,9.42-4.11,10.76-10.99c1.35-6.94-7.55-2.5-10.44-6.43c1.75-1.13,4.47-2.7,5.45-4.39c0.95-1.65,1.42-4.45-0.98-4.07
                      c0.82-2.23-0.3-5.99,1.1-7.22c1.57-1.38,4.42,0.73,6.15-1.58c1-1.33,0.04-4.29,1.26-5.43c2.53-2.38,6.13,1.52,7.67,1.53
                      c0.6,0,0.75-1.6,1.32-1.65c1.42-0.11,1.54,0.79,2.58,1.24c1.36,0.58,2.87,1.44,4.37,2.02c-0.32-2.21,0.08-3.98,2.51-4.35
                      c-2.42-1.1-1.27-3.26,0.94-3.26c1.94,0,2.56,3.16,3.87,3.21c0.9-0.24-0.72-5.08-0.07-6.03c0.57-0.84,1.82-0.69,2.25-1.18
                      c0.56-0.64,0.44-1.01,0.99-2.19c0.37-0.81,1.81-4.38,0.86-5.39c-1.28-1.35-4.6,0.66-5.97-0.19c-1.91-1.2-0.88-5.06-1.19-7.39
                      c-0.55-4.1-1.56-1.78-4.86-1.79c-0.13,0-0.77,1.02-1.62,0.48c-0.92-0.58,0.33-1.58-0.28-2.19c-0.39-0.39-0.14-0.95-0.8-1.55
                      c-0.53-0.48-1.69,0.53-2.16,0.15c-1.28-1.05-0.38-1.22-0.33-2.34c0,0.03,2.18-3.95,1.13-5.12c-1.23-1.36-2.86,0.46-3.09,0.5
                      c-1.73,0.3-3.78,1.1-2.12-2.49c-2.06,0.43-1.85-1.21-4.18-1.03c0.57,2.33-1.55,3.4-3.31,4.58c-2.84,1.91-3.83,0.14-7.44,1.39
                      c-1.97,0.68-2.05,3.04-3.93,0.24c-1.64-2.45,0.29-2.58-2.2-3.69c-1.17-0.52-2.75-0.12-4-0.61c-0.9-0.35-2.28-2.05-3.15-2.07
                      c-0.16,2.67,1.21,4.25-1.52,5.35c-0.77,0.31-4.22,0.23-4.76-0.53c-1.91-2.69,1.77-4.06,2-4.95c0.56-2.09-1.28-4.07-2.66-5.65
                      c0.03-0.47,0.09-0.94,0.2-1.4c-0.48-0.28-0.99-0.5-1.53-0.66c-0.35-0.68-1.23-0.03-1.49-0.45c-0.67-1.09-0.09-2.37,0.47-2.76
                      c2.57-1.79,5.19,3.1,6.19,4.09c1.16,1.15,3.57,1.5,3.76,3.76c1.16-0.53,1.29-1.75,3.87-1.03c2.4,0.67,3.24,3.23,4.94,3.79
                      c2.53,0.83-2.61-3.29-2.01-2.32c-0.76-1.24-0.71-2.81-0.22-4.14c1.01-2.71,1.55-0.97,3.1-2.39c0.27-0.25,1.92,0.38,2.01-0.25
                      c-1.88-0.64-2.05-4.28-3.19-4.55c-0.25,3.22,1.56,4.69-1.9,2.93c-1.88-0.95-1.98-0.62-2.21-2.89c-1.57,0.97-3.58-0.72-5.01,0.47
                      c-0.52,0.44,0.25,2.37-0.25,2.75c-1.34,1.02-3.25-0.4-4.22-0.62c-3.08-0.7-1.99-0.17-3.45-2.46c-0.34-0.54-1.54-2.26-1.49-3.04
                      c0.05-0.77,1.01-2.14,2.02-2.72c-2.86,0.63-3.35-1.52-4.28-2.77c-2.63-3.53-1.19-4.62-0.89-8.57c-0.01,0.1,1.69-4.55,1.71-6.58
                      c-5.32,0.38-1.44-5.06-0.95-6.58c2.93,3.28,2.6,2.87,6.34,3.1c1.42,0.09,3.1,1.32,4.38,0.56c1.79-1.06,2.07-5.31,1.8-6.95
                      c-0.53-3.25-1.6-2.22-3.15-4.49c-1.77-2.59-1.92-10.17,2.07-10.35c-0.31-2.47-2.73-3.06-1.93-6.24c0.22-0.89,0.54-1.8,1.37-2.67
                      c3.69-3.84,10.99-0.74,15.5-0.68c0.09-3.5-0.77-7.35,0.02-10.79c0.24-1.06,0.36-2.14,1.11-2.89c0.68-0.68,2.74,0.73,2.92-1.02
                      c-1.69-0.03-12.67-1.99-13.29-3.42c-1.49-3.4,5.01-3.24,6.21-4.15c1.18-0.89,3.91-3.93,0.79-3.8c0.9-2.74-1.58-5.26,1.91-5.33
                      c-0.27-2.28-0.46-2.82-0.13-5.09c0.18-1.27,1.05-3,0.9-4.42c-0.22-2.16,0.44-1.12-0.34-2.35c-0.55-0.87-2.95-0.03-3.19-2.07
                      c-0.11-0.95,4.46-5.7,5.33-6.73c1.47-1.75,4.47-4.73,7.02-4.57c-1.34-1.68-9.53-0.08-10.29-2.24c-1.18-3.37,6.32-4.56,4.86-9.11
                      c4.22,1,3.89-4.4,3.86-6.51c-0.04-2.6,0.79-2.54,1.14-4.85c0.14-0.95-0.86-2.82-0.61-4.26c-1.28,0.01-2.56,0.02-3.84-0.05
                      c0.39-2.25-1.82-1.16-2.26-3.07c-0.1-0.43,0.6-1.24,0.76-0.76c-0.18-0.54,0.89-3.1-2.41-2.09c-0.24,0.07-1.92,2.53-2.44,3.02
                      c-1.1,1.04-2.35,1.79-3.59,2.63c-0.83,0.56-0.47,1.48-1.81,1.94c-2.07,0.71-5.19-2.2-6.63,0.69c1.99,0.93,2.03,4.46-0.35,4.56
                      c0.19,1.79,0.39,1.51-0.65,1.69c-0.38,0.89,0.34,0.82-0.89,0.74c0.4,1.85-4,1.84-5.44,1.17c-0.04,0.85,1.95,1.73,1.67,2.31
                      c-0.74,1.52-1.6,1.54-2.84,2.69c0.22-0.21-1.1,1.99-0.64,1.84c-2.8,0.89-0.71-0.19-3.16-1.08c-3.43-1.25-4.49-0.04-6.16,2.49
                      c-1.1,1.65,0.97,1.22-1.74,2.48c-0.42,0.19-2-0.57-2.6-0.69c0.49,1.71-0.25,2.89-0.02,4.26c0.17,1.01,1.53,3,1.57,3.46
                      c0.08,0.85-0.48,2.52-0.7,3.9c-2.81-1.61-4.93-2.87-8.13-3.25c-2.57-0.31-2.41,0.46-5.75,0.28c-3.93-0.21-2.47-2.16-5.28-3.62
                      c-1.08-0.56-2.6,0.31-4.01-0.23c-1.37-0.52-2.05-2.65-3.69-2.59c0,2.38-0.42,4.17-0.09,6.42c0.21,1.48,1.03,1.74,0.87,3.47
                      c-0.08,0.84-1.18,1.42-1.31,2.69c-0.13,1.32,1.96,4.14,1.17,5.73c-1.88,3.82-2.92-0.26-4.57-0.14c-0.08,4.81-7.1,0.97-10.78,1.96
                      c0.9,2.91-2.12,3.87-4.46,2.97c-3.03-1.17-3.56-3.17-7.51-2.97c0.24,1.06,0.06,2.28-0.06,3.36c-2.23-0.24-0.7,1.23-2.15,2.67
                      c-1.34,1.33-4.26,1.84-6.03,2.56c-2.8,1.14-3.71,1.59-0.76,3.88c-1.85-0.14-5.29,1.5-6.79,0.62c-1.63-0.95,0.22-4.35-3.89-2.08
                      c0.35-0.19-1.03,1.93-1.09,1.99c0.51-0.51-3.3,1.58-2.12,1.19c-0.93,0.31-0.64,1.67-3.23-0.01c0.22,1.58,2.16,1.66,2.58,3.02
                      c0.74,2.4-0.35,1.55-0.41,3.19c-0.02,0.49-1.64,1.35,0.13,2.78c1.84-2.81,5.32,2.42,5.67,4.36c0.84,4.7-1.56,2.28-4.81,3.61
                      c-0.22,1.35,2.83,0.83,3.5,2c1.47,2.53-1.9,3.54-2.78,5.07c-1.31,2.27,1.73,3.98-2.91,2.47c0.32,0.62,0.14,1.15,0.39,1.73
                      c-1.81-0.52-7.42-0.14-7.31,2.72c2.46-0.13,2.79,0.31,4.36,1.78c3.81,3.58-0.21,4.37,0.98,8.16c0.44,1.39,3.54,2.48,2.24,5.02
                      c-0.07,0.14-3.03,1.4-3.04,1.4c2.98,1.61,0.91,5.38,0.09,7.73c-0.73,2.08-0.27,4.05-3.54,1.84c0.01,0.33,0.13,0.75,0.25,1.05
                      c-1.55,0.08-3.09,0.11-4.64,0.18c0.84,0.49,1.57,1.11,2.19,1.85c-7.06,0.51-1.52,2.85,1.63,4.41c2.66,1.31,1.92,0.66,3.02,3.64
                      c0.7,1.88,1.32,5.14,3.85,4.89c-0.16,0.71-0.51,1.32-1.05,1.81c0.06,0.81,0.3,1.56,0.7,2.26c0.35,1.15,1.3,1.82,1.72,2.81
                      c0.46,1.09,0.25,3.08,0.55,4.8c0.42,2.35-1.05,1.1,0.07,3.26c0.69,1.33,2.43,2.31,3.24,3.68c1.7,2.87,1.82,5.54,2.02,8.79
                      c3.6-0.31,1.04,1.36,1.12,1.96c0.08,0.62,0.37,1.91,0.41,2.57c0.12,1.62,1.17,3.24,0.72,4.97c0.48,1.32,0.16,2.02-0.94,2.1
                      c-0.67,0.16-1.25,0.46-1.74,0.92c-0.12,0.79,2.29,1.47,2.76,2.1c0.66,0.89,1.33,3.24,1.6,4.35c0.98,3.99-0.73,6.93,2.73,9.59
                      C288.48,883.98,291.36,893.28,295.21,892.2z" />
                                        <path class="st0 st-12  state_32" d="M372.26,1059.16c0.34-1.65,2.25-4.68,1.8-6.95c0.43,0.28,1.73,0.81,2.13,0.58c1.25-1.1-3.11-7.34-2.14-9.4
                      c1.2-2.54,3.32-2.26,2.01-5.39c-1.11-2.65-3.45-2.73-2.13-5.77c0.48-1.1,2.43-1.83,2.9-3.71c0.3-1.18-0.19-2.84,0.32-3.99
                      c0.49-1.08,1.65-1.57,2.02-2.25c0.36-0.67,2.45-5.59,2.47-5.94c0.05-1.05-1.26-1.99-1.37-3.19c-1.62,0.23-0.21,1.9-2.3,1.41
                      c-1.77-0.42-3.52-1.36-3.87-3.01c-0.21-0.97,1.05-3.94,1.26-5.19c0.14-0.81,0.32-2.1,0.43-2.76c0.46-2.78,2.2-4.76,1.63-6.78
                      c-0.08-0.29-1.54-0.54-1.72-0.85c-0.44-0.76-0.34-2.39-0.38-3.3c3.48,0.66,2.42-6.25,0.27-6.97c-4.27-1.43-5.97,5.44-9.2,4.65
                      c-0.97-0.24-3.38-2.96-3.94-4.11c-1.45-2.93-0.71-6.33-0.06-9.3c0.56-2.55,2.41-7.5,0.33-10.01c-1.03-1.24-5.31-3.02-6.89-2.77
                      c0.59-1.73,0.65-4.05,1.2-5.48c0.11-0.29,0.98,0.14,1.26-0.69c0.83-2.55-0.53-3.94-2.62-4.6c-1.92-0.61-6.97,1.52-7.44-0.53
                      c-0.14-0.63,2.61-4.83,3.37-5.28c-2.01-2.67-6.68-2.45-9.14-3.98c-0.87-0.54-1.04,0.23-1.6-0.48c-0.83-1.06,0.08-5.3,0.37-6.6
                      c2.34,0.8,6.82,1.74,6.84-2.27c0.01-1.27-0.37-0.88-1.49-1.67c-0.37-0.26-1.29,0.12-1.71-0.1c-1.22-0.62-1.66-1.63-2.76-2.28
                      c-1.1,0.63-2.97-3.22-6.06-2.19c-0.06-1.19-0.04-2.38-0.07-3.56c-1.9,0.44-3.4,1.16-5.42,0.84c-3.46-0.55-2.98-2.15-4.9-4.09
                      c-1.25-1.27-2.62-0.9-4.57-1.97c-1.7-0.93-2.43-2.92-4.65-2.6c0.75-4.9-4.03-4.24-5.94-6.76c-0.24-0.32-0.07-2.11-0.09-2.51
                      c-0.13-2.68,0.18-1.48,0.98-3.83c-0.7-0.18-1.22,1.21-2.67,0.81c-0.91-0.26-0.97-2.27-2.57-2.5c0.27-0.69,0.44-1.05,0.42-1.92
                      c-0.84,0.72-1.08,1.36-2.28,0.85c2.19,0.93-2.89-3.33-1.54-1.23c-0.12-0.18-0.67-2.69,0.04-2.25c-2.2-1.37-1.65,0.42-2.29,0.32
                      c-1.58-0.25-3.35-0.89-2.12-2.29c0.06-0.86-1.34-0.14-1.58-0.05c0.13-0.64,0.03-1.83-0.01-2.47c-1.19,0.76-2.46,0.88-3.92,0.76
                      c1.12,3.11,3.26,5.49,4.23,8.72c1.08,3.59,1.9,7.27,3.28,10.79c0.66,1.68,1.09,5.22,1.92,6.5c1.02,1.58,2.42,0.01,3.6,1.26
                      c0.22,0.45,0.08,0.72-0.42,0.81c-0.06,0.62,3.07,1.87,3.57,2.25c-3.48,0.32-0.11,2.91,1.52,4.26c2.37,1.97,4,0.67,6.32,1.77
                      c3.55,1.69-0.09,1.98-0.39,3.75c-0.38,2.26,2.94,4.3,0.65,4.44c0.53,2.43,1.81,2.85,2.82,4.36c0.02,0.02,4.14,5.17,4.35,3.58
                      c-2.91,0.23-0.58,2.75-0.19,5.76c0.55-0.56,1.26-0.69,2.14-0.39c0.06,0.46-0.98,1.92-1,2.77c-0.04,1.5,1.09,4.24,1.5,5.92
                      c0.71,2.98,1.04,7.22,2.24,9.92c0.12-1.31,0.5-1.66,0.8-2.84c0.72,1.09,0.53,2.5,1.13,3.28c-3.23-1.62,0.15,4.13,0.79,4.79
                      c1.59,1.63,1.92,1.2,3.6,3.47c-1.74,0.15-1.27-1.67-2.26-1.38c0.4,3.96,3.73,7.49,3.68,11.61c1.63-2.45,1.06,2.93,1.44-2.14
                      c0.67,0.54,1.21,3.96,2.23,3.8c-0.46,0.07-1.8-0.48-1.74-1.07c-1.25-0.35-0.6,4.14-0.38,4.76c0.9,2.59,4.01,4.04,5.14,6.42
                      c0.98,2.09,1.3,5.8,1.58,8.18c0.2,1.68,0.32,2.94,0.88,3.83c0.11,0.17,2.92-1.09,2.47,1.86c-6.67,0.38-4.25-3.83-5.07-7.4
                      c-0.29-1.25-1.32-4.01-1.86-5.6c-0.38-1.11-2.63-4.01-2.62-4.95c-0.01,3.06,1.68,6.08,2.18,9.1c0.51,3.09,0.3,6.25,1.01,9.3
                      c1.27,5.47,2.94,12.01,5.58,17.03c0.22-0.45,1.72-2.56,1.78,0.11c-1.75,0.77-1.35,1.5-0.3,3.16c0.77-1.62,3.16-2.35,4.27-0.34
                      c-0.74,0.74-3.72,0.88-1.64,2.12c-0.45,0.03-0.9,0.03-1.36,0.01c-0.08,1.92,6.87,3.01,2.66,3.12c-0.32,3.46,7.22,9.48,9.09,11.78
                      C365.1,1055.78,366.73,1060.72,372.26,1059.16z" />
                                        <path class="st0 st-13 state_33"
                                            d="M455.35,1025.97c-1.31-0.73-0.98-2.37-1.06-3.61c-0.65-0.16-2.75,0.48-3.67,0.65
                      c-2.07,0.4-4.39-0.19-5.93-0.86c-4.43-1.93-7.02-2.89-5.67-8.09c1-3.87,4.12-6.76,6.16-10.01c0.54-0.87,7-8.19,6.96-8.28
                      c-0.33-0.93-1.44,0.05-1.48-0.94c-0.04-0.91,0.08-1.79,0.23-2.68c0.22-1.32,1.54-3.93,2.73-4.94c4.02-3.42,13.54,0.61,18.37,0.27
                      c-1.53-2.86-9.55-3.03-12.07-1.9c-0.46-1.18,6.78-1.62,7.84-1.48c2.7,0.35,4.06,1.7,5.24,3.7c2.34-3.9,1.13-17.4-1.27-20.26
                      c-1.61-1.91-5.23-2.32-4.76-5.64c1.97-0.1,2.24-3.42,5.45-1.57c-0.1-5.18,0.45-11.03-1.05-15.93c-1.26-4.11-0.64-6.71-0.46-11.14
                      c-0.6,0.21-0.27-0.04-0.6-0.16c-1.06,0.33-3.81-1.29-6.03-1.91c0.87-1.75-0.89-2.37-2.71-2.44c0.24-1.5,1.16-1.97,2.64-2.06
                      c-0.08-0.47-0.36-4.01-0.23-4.13c0.75-0.69,3.17-0.68,3.38,0.63c0.89-3.9,2.86,1.68,2.42,1.48c1.37,0.63,2.39-0.02,3.05-1.25
                      c1.35-2.53-1.23-3.05-1.21-3.4c0.11-3.25,1.92-0.37,2.27-0.38c1.46-0.06,0.87-1.76,1.44-2.63c1.09-1.67,2.44-2.67,3.85-4.22
                      c1.75-1.94,5.96-7.65,0.71-8.19c2.66-0.01,2.88,0.89,4.62-1.52c1.18-1.63,2.08-4.79,2.54-6.72c0.74-3.07,0.18-6.22,1.15-9.23
                      c1.1-3.39,2.28-5.52,2-9.27c-0.22-2.86-1.2-6.33-3.27-8.44c-0.47-0.48-0.41-0.55-1.22-1.01c-2.34-1.32-2.07,0.49-3.26,0.41
                      c-2.93-0.2-1.45-2.19-3.48-2.25c-0.14,4.63-0.82,2.28-3,5.67c-1.62,2.52,0.01,3.4-2.1,4.6c-0.73,0.41-1.87-0.28-2.64,0.26
                      c-0.38,0.27-0.69,1.43-0.79,1.49c-0.54,0.33,0.1,0.84-0.9,1.31c-4.06,1.89-3.47-4.02-4.97-3.52c0.19,0-1.75,2.3-2.97,2.35
                      c0.21-2.87-2.09-5.5-5.34-3.58c0.35,0.4,2.17,0.8,2.68,0.91c-1.87,0.64-0.97,1.71-1.81,2.81c-0.14,0.19-1.31,1.74-1.43,1.93
                      c-1.53,2.41-2.56,3.71-5.08,2.12c-0.26,0.58-0.35,1.45-0.3,2.1c-2.13-0.24-2.44,1.91-4.83,1.84c-2.64-0.07-3.95-2.6-6.65-3.03
                      c-2.12-0.34-8.87,0.2-10.11,2.24c-0.69,1.14,0.96,4.85,0.26,6.67c-0.28,0.73-2.52,2.93-3.44,4.12c-2.16,2.8-4.63,4.74-8.03,3.43
                      c-2.39-0.93-2.63-3.2-4.03-4.26c-1-0.75-4.8-3.11-5.9-3.41c-2.02,5.38-5.33-2.44-8.56-0.05c-1.03,0.77-0.34,4.26-1.3,5.45
                      c-1.5,1.87-4.26,1.71-6.42,1.76c0,1.53,0.25,3.09-0.04,4.61c1.12,0.14,0.87,0.64,0.93,1.85c0.25,4.61-2.04,5.4-5.09,8.11
                      c2.47,1.56,7.06-0.63,9.16,1.93c0.85,1.04,0.82,3.7,0.45,4.94c-0.17,0.56-1.94,3.72-2.19,3.93c-0.35,0.29-0.15,0.63-0.62,0.97
                      c-1.64,1.2-4.59-0.51-6.51,1.3c-3.75,3.53,1.32,5.82-4.38,4.92c-1.5-0.24-3.06-0.9-4.61-1.07c-1.22-0.13-2.28-0.51-3.54-0.13
                      c-0.55,0.17-0.69,1.17-0.8,1.19c-1.2,0.21-0.72,0.13-2.81-0.52c-1.71-0.53-3.09-1.61-5.14-0.11c-4.25,3.11,0.13,6.34-6.48,6.32
                      c-2.35-0.01-4.32,0.19-6.53,0.76c0-0.44,0.11-0.87,0.08-1.3c-1.43,0.02-0.12-1.37-1.5-2.3c-1.89-1.26-3.25,1.11-4.1,1.89
                      c-2.07,1.89-2.26,3.03-5.68,1.16c-0.59,4.15,0.08,3.9,3.52,4.97c1.88,0.59,2.83,1.28,4.41,2.47c1.43,1.09,2.74,0.25,2.85,2.7
                      c0,0.05-2.88,3.66-3.07,3.9c7.38-0.5,9.79,0.15,9.6,7.73c-0.28-0.09-1.8-0.18-1.86-0.01c-0.78,2.53,0.16,2.54,1.76,3.74
                      c3.54,2.65,5.99,2.76,5.39,8.25c-0.29,2.68-1.64,5.36-1.9,8.32c-0.13,1.46-0.04,4.75,0.88,5.98c0.96,1.29,3.26,1.33,3.75,3.1
                      c-0.76,0.12,2.73-2.87,2.64-2.8c1.09-0.87,1.98-1.72,3.37-2.1c3.11-0.85,4.65,1.09,5.17,4c0.25,1.41-0.03,2.93-0.44,4.22
                      c-0.25,0.78-1.52,1.01-1.56,1.44c-0.09,0.89,0.91,0.96,1.01,1.42c0.21,0.98,1.84,1.46,1.59,3.12c-0.05,0.34-0.88,0.51-0.96,0.82
                      c-0.33,1.22-1.01,2.52-1.06,3.32c-0.04,0.68,0.47,2.08,0.34,2.91c-0.11,0.77-1.03,0.61-1.28,1.55c-0.46,1.74-1.1,4.11,0.13,5.16
                      c2.21,1.89,1.36-0.44,2.83-0.24c1.77,0.24,3.44,0.13,3.54,3.19c0.08,2.64-2.79,5.09-2.35,8.36c-1.46-0.42-1.58-0.04-2.19,1.24
                      c-0.57,1.19-0.07,3.14-0.48,4.45c-0.4,1.25-1.18,2.09-1.75,3.22c-0.83,1.65-1.99-0.01-0.67,2.61c0.46,0.91,2.09,1.61,2.34,2.18
                      c2.01,4.64-3.16,5.23-2.21,9.28c0.32,1.34,4.67,8.45-0.3,7.27c-0.04,3.88-0.58,5.83-5.03,6.98c2.32,3.96,11.68,8.94,16.43,7.41
                      c1.74-0.56,1.11-1.34,2.3-1.94c1.89-0.95,4.31-0.5,6.27-1.72c1.78-1.11,2.39-2.93,4.15-4.08c1.75-1.16,4.23-0.98,5.98-2.57
                      c1.38-1.25,3.73-4.58,4.01-6.43c0.56-3.72-1.08-2.26-4.07-2.49c0.1-1.71,2.27-0.45,2.97-0.91c1.48-0.98,0.7-0.42,1.81-2.45
                      c1.62-2.97,0.3-5.45,1.31-8.47c0.73-2.18,1.85-2.64,3.75-3.77c3.09-1.83,4.3-3.23,8.05-3.99c2.79-0.56,5.96-1.57,7.85-2.49
                      c2.15-1.05,4.15-1.96,6.61-2.36c5.02-0.82,14.53-0.98,18.53,2.69C456.57,1026.58,456.4,1026.09,455.35,1025.97z" />
                                        <path class="st0 st-14 state_6" d="M399.74,346.65c-2.11-1.91-1.01-3.66,0.23-5.42c1.69-2.4,1.82,0.2,1.78-2.89c-0.05-3.91-4.42-7.61-5.88-10.9
                      c-2.35-5.31-0.05-1.57-2.73-0.47c-2.55,1.04-3.33-2.65-5.29-3.38c-1.31-0.49-5.57,1.14-5.32-2.17c0.22-0.01,0.44-0.02,0.66-0.04
                      c-0.22-0.01-0.44-0.03-0.65-0.04c0-1.21,1.99-2.1,2.5-3.23c0.43-0.96-0.14-1.96,0.26-3.19c0.81-2.47,2.99-3.35,5.38-2.97
                      c-1.46-3.87-0.41-8.44-1.4-12.46c-1.29-5.21-1.44-10.1,0.41-15.35c0.21-0.6,1.11-2.17,1.6-2.96c1.56-2.55,0.87-3.96,1.95-6.51
                      c1.16-2.73,5.08-4.93,6.68-6.7c1.45-1.6,3.23-4.71,4.49-6.58c1.88-2.8,1.58-3.12,0.83-4.32c-0.68-1.1-1.62-1.46-2.57-2.01
                      c-1.02-0.58-2.54-0.9-3.66-1.54c-0.83-0.48-1.52-1.25-2.48-1.67c-0.97-0.43-2.38,0.05-2.91-0.6c-1.1-1.33,0.66-4.9-0.19-6.54
                      c-0.85-1.64-4.71-3.88-6.1-5.33c-1.3-1.36-3.54-5.84-5.35-6.28c-0.17,0.8,1.24,1.47,1.33,2.25c0.16,1.37,0.15,3.29,0.4,4.64
                      c0.11,0.59-0.57,1.4-0.32,1.84c0.32,0.58,1.86,0.43,2.15,0.92c1.24,2.09,1.06,3.02,1.05,5.75c-0.01,1.45,1.09,7.03-1.4,7.33
                      c1.22-0.15-6.66-5.63-5.3-3c1.67,0,1.65,2.83,0.94,3.93c-0.65,1.01-3.34,0.28-3.99,2.15c-0.08,0.24,1.44,2.8,1,4.09
                      c-0.3,0.86-1.3,1.01-1.96,1.44c-4.93,3.25-1.95-2.87-5.09-3.01c-1.13,3.64-2.2,2.32-5.38,1.4c-0.01,1.8-2.97,9.45,0.24,9.16
                      c-0.32,3.39-1.49,2.22-3.34,3.59c-0.61,0.45-1.96,2.86-2.66,3.09c-1.62,0.53-4.86-0.31-5.94-0.86c-2.08-1.07-1.68-3.14-5.11-2.03
                      c-0.83,0.27,0.11,1.39-0.79,1.65c-3.62,1.07-5.83-2.47-8.58-0.22c-0.77,0.63-1.57,2.32-2.13,3.15c-0.38,0.57-1.3,0.8-1.65,1.46
                      c-0.55,1.04,0.39,2.28-0.57,3.24c-2.66,2.62-3.02-0.87-3.76-2.33c-0.81-1.6-1.94-1.25-1.84-3.16c0.09-1.77,2.37-2.37,2.02-4.44
                      c-2.5,5.03-4.02-4.89-3.23-4.38c-1.37,3.76-6.69-3.49-10.51-2.79c-1.6,0.29-1.51,1.14-2.6,1.48c-3.25,1-3.85-0.8-6.97-1.29
                      c0.16,1.71,1.74,3.84,3.16,2.18c0.73,1.78,0.04,3.33-0.23,4.27c-0.25,0.87-2.53,1.21-1.28,3.3c0.18,0.3,2.69-0.28,2.86,0.09
                      c1.05,2.28-0.7,5.8-0.8,8.11c-0.14,3.48,0.95,3.18-2.87,3.29c-0.04-0.05,2.55,1.44,2.38,1.36c0.05,0.26,0.12,0.51,0.21,0.76
                      c0.15,0.65,0.71,0.63,1.68-0.03c1.16-0.06,2.3,0.04,3.43,0.3c0.26-0.5,0.52-0.99,0.78-1.49c1.53-0.15,5.27,0.74,6.49,1.9
                      c0.55,0.52,0.28,1.89,0.76,2.46c2.73,3.18,7.26-0.4,10.46,0.61c0.24,0.08,2.51,2.45,2.74,2.92c0.71,1.44-0.42,3.29-0.02,4.75
                      c0.43,1.55,1.4,1.36,1.3,2.1c2.87-0.37,0.83,4.52,0.8,6.3c-0.07,4.26,1.21,6,2.81,9.76c0.36,0.85,0.06,2.34,0.85,3.02
                      c1.09,0.95,3.21-0.41,4.08,0.3c0.94,0.76,0.24,2,1.14,3.31c1.44,2.1,4.5,2.65,6.11,5.18c2.5,3.94,1.36,5.02,0.11,8.71
                      c-0.61,1.8-1.6,4.93,0.2,6.4c1.32,1.08,3.48-0.01,5.08,0.69c-0.74-4.77-1.1-6.7,4.33-6.41c-1.79-4.29-2.5-7.9,3.82-4.63
                      c1.53,0.79,3.83,4.75,5.29,4.92c3.58,0.42,0.22-1.2,1.71-2.24c1.76-1.23,1.47-1.51,4.26-1.33c0.2-5.77,6.69-1.52,6.85,1.66
                      c0.01,0.16-1.06,0.73-1.11,0.89c-0.58,1.95-0.87,3.64-1.07,5.68c-0.14,1.37-1.55,8.9,0.57,8.6c0.2-1.74,1.57-2.5,3.23-2.46
                      c-0.02-0.51-0.14-2.39-0.42-3.08C392.61,353.88,395.94,348.6,399.74,346.65z" />
                                        <path class="st0 st-15 state_3" d="M292.11,261.65c1.91,4.02-1.95,3.51,4.13,3.87c3.69,0.22,8.38,0.72,11.96,1.43c2.56,0.51,3.72,1.69,6.07,1.12
                      c0.68-0.16,0.92-1.16,1.92-1.41c1.75-0.44,4.8,0.17,6.38,0.97c1.09,0.55,2.83,3.47,3.71,3.62c1.28-0.12,0.84-3.41,3.07-1.13
                      c0.79,0.81-0.96,4.12,0.35,4.59c1.17,0.42,1-3.35,2.81-0.28c1.45,2.45-2.19,3.75-2.03,5.6c0.08,0.94,3.18,4.26,3.45,4.18
                      c-1.32,0.41,3.21-6.19,3.42-6.43c1.96-2.28,1.84-2.74,4.96-2.58c2.11,0.11,3.35,0.6,5.04,0.25c1.82-0.38,2.61-2.24,5.24-0.91
                      c1.57,0.79,3.52,4.03,5.89,2.97c1-0.44,1.37-2.35,1.61-3.62c0.14,0.36,0.6,1.09,0.88,1.41c0.44-1.82,2.51-0.55,2.95-1.87
                      c-0.01,0.04-1.09-2.82-1.14-3.32c-0.28-2.59,0.96-6.42,1.69-8.98c1.65,0.62,3.32,0.95,4.8,1.79c1.37-1.4,0.57-4.58,3.48-1.47
                      c2.13,2.28-0.47,3.62,2.28,1.97c4.15-2.5-0.71-2.58-0.38-4.87c0.01-0.05,2-1.61,2.21-1.77c1.29-0.93,2.08-0.26,2.69-1.81
                      c0.5-1.29-1.41-1.02-1.01-2.32c1.01-3.29,5.64-1.84,6.73,0.86c0.17-1.92,0.91-6.81,0.1-8.53c-0.72-1.53-2.22-1.58-3.56-2.19
                      c-0.79-0.36-1.51-1.11-1.24-0.6c-0.53-1.01-0.62-0.76-0.41-1.58c-0.2,0.1-0.39,0.19-0.59,0.29c-0.63-2.56-1.27-4.79,2.83-4.26
                      c-0.37-3.16-2.6-3.72-4.77-5.15c-3.64-2.39-2.1-4.03-2.23-7.34c-0.04-0.98-0.65-3.17-1.3-3.67c-1.38-1.05-2.36-0.34-3.82-2.01
                      c-0.88-1.01-1.17-2.46-2.32-3.37c-0.62,2.27-3.01,5.23-6,3.27c-1.38-0.9-0.26-3.22-0.76-5.07c-0.69-2.54-10.12-11.5-4.9-12.98
                      c-1.6-2.67-3.66-5.41-6.6-6.54c-1.93-0.74-4.22-0.45-5.92-1.7c0.65-0.98,2.49-1.16,2.86-1.92c0.51-1.03-0.83-2.5-0.38-3.48
                      c0.92-2,3.02-0.86,4.21-1.89c2.2-1.91,0.25-3.57,4.3-4.14c-0.57-1.29-1.73-2.36-2.48-3.56c-0.34,0.7-0.37,2.12-1.24,2.41
                      c-0.95,0.31-2.3-0.06-3.12,0.31c-0.75,0.35-1.43,1.24-2.09,1.54c-0.76,0.34,0.12,0.88-0.72,1.18c-1.76,0.63-3.84-1.17-5.62-1.09
                      c0.17,2.22-0.41,5.67-1.49,7.47c-1.55,2.58-4.35,2.44-7.03,2.46c-2.12,0.02-4.69-0.52-6.41,0.73c-1.22,0.89-1.24,2.93-2.44,3.65
                      c-1.46,0.88-3.19,0.2-4.71,1.4c-1.04,0.82-2.55,3.44-3.02,4.33c-0.23,0.42-1.21-0.01-1.38,1.06c-0.11,0.7,0.85,1.68,1.08,2.29
                      c0.92,2.46,2.87,4.32,0.48,6.19c5.13-0.12-0.41,4.22-1.12,5.67c-0.91,1.86-1.75,6.17-0.08,7.57c1.09,0.91,3.32-2.14,4.23-0.63
                      c1.22,2.02-1.38,1.5-1.94,1.94c-2.52,1.97-4.21,4.33-6.66,6.57c-1.59,1.45-3.62,2.21-4.93,3.68c-1.1,1.24-1.72,2.93-3.21,4.31
                      c-0.31,0.29-1.58,0.92-1.72,1.08c-0.54,0.65-0.46,1.63-1.12,2.48c-1.22,1.56-2.11,1.4-3.27,2.16c-0.54,0.35-1.71-0.14-2.19,0.56
                      c-0.59,0.86,0.56,1.72,0.78,1.34c0.13-0.21-0.36,1.54-0.31,1.18c-0.03,0.24-1.62,0.19-1.71,0.54c-0.6,2.09,1.2,3.21,1.18,5.79
                      c-0.01,1.65-0.12,4.18-1.75,5C291.38,260.56,291.83,261.02,292.11,261.65z" />
                                        <path class="st0 st-16 state_5" d="M452.55,225.72c0.77,0.78,2.75,2.86,2.45,4.04c-0.39,1.54-4.96,1.84-6.35,1.19c-0.89-0.42-1.34-2.52-3.08-3.3
                      c-2.02-0.91-3.99-0.32-6.09-0.53c-4.79-0.48-8.41-2.32-12.98-0.21c-0.72,0.13-1.45,0.26-2.17,0.39c-0.08,0.66-0.28,1.29-0.58,1.87
                      c-0.98,0.46-1.09,1-2.35,1.21c-1.37,0.24-1.3-1.52-3.22-0.84c-1.21,0.43-2.65,2.53-2.92,3.66c0.31,0.05,0.55-0.1,0.86-0.1
                      c0.6,2.15-1.1,2.63-2.88,2.52c0.1,2,1.13,2,1.14,3.97c-2.09-0.43-2.68,2.83-3.04,4.62c2.07,0.86,0.43,3.17,0.57,5.09
                      c0.14,1.92,2.4,1.62,0.38,4.09c-1.05,1.28-3.83,1.68-5.21,2.74c0.54,1.41,3.26,3.31,4.5,4.06c0.88,0.53,6.84,1.9,6.98,2.71
                      c0.29,1.72-2.16,1.16-2.77,2.01c-1.13,1.59-1.02,4.4-2.07,6.17c-2.2,3.7-3.67,3.39-1.92,7.91c0.99,2.57-0.11,2.59,3.04,2.58
                      c1.33-0.01,2.8-0.7,4.13-0.97c-0.14,1.36-0.74,6.08,1.86,5.74c-0.02,0,2.55-3.04,2.85-3.39c0.29-0.34,1.36-0.32,1.77-0.59
                      c0.64-0.42,0.37-1.64,1.5-2.35c1.82-1.15,5.46-1.21,7.11,0.01c2.8,2.06,3.92,5.5,6.84,7.77c1.41,1.1,6.83,3.86,7.89,5.28
                      c2.89,3.85-2.59,2.04-3.67,3.78c-1.39,2.25,2.43,3.68,3.73,4.73c1.51,1.21-0.3,1.23,2.32,1.96c1.6,0.44,3.59-1.1,5.16,0.35
                      c1,0.92,0.36,2.3,1,3.16c1.55,2.09,5.72,2.48,8.19,3.86c0.55,0.31,1.48,2.38,1.42,2.36c1.07,0.47,3.66,0.1,4.85,0.15
                      c2.03,0.08,6.42-0.95,8.14-0.26c0.36,0.14,0.07,0.42,0.28,0.55c0.02,0.67,0.04,1.35,0.04,2.02c-0.13,0.71,0.32,0.86,1.36,0.43
                      c0.33,0.32,0.65,0.74,1.14,0.95c0.32,0.14,2.19,1.87,1.91,1.84c3,0.24,1.63-1.62,3.61-2.99c-3.76-1.71,2.4-7.35,3.52-9.34
                      c0.95-1.7,1.42-3.94,2.52-5.52c0.6-0.54,0.95-1.21,1.04-2.01c0.7-0.02,1.41-0.05,2.11-0.07c0.93-2.3-3.25-5.9-1.08-9.41
                      c0.88-1.43,2.22-1.39,3.03-2.55c1.08-1.56,0.03-2.77,0.18-4.33c0.27-2.84-0.35-2.38,1.66-4.29c0.84-0.8,2.12-0.83,2.95-1.92
                      c0.97-1.29,0.43-3.33,1.76-4.42c1.01-0.82,2.57,0.02,3.51-0.57c1.7-1.07,2.22-4.82,3.98-5.92c0.85-0.53,2.62,0.24,3.11-0.43
                      c1.56-2.16-3.76-4.55-4.5-5c-1.41-0.86-1.84-0.52-3.22-1.87c-1.39-1.36-1.26-2.45-3.01-3.57c-1.14-0.73-3.35-1.75-4.67-2.32
                      c-2.19-0.95-4.85-0.13-6.89-0.99c-2.45-1.04-1.91-1.43-3.05-3.73c-0.16-1.04-0.13-2.07,0.09-3.1c-0.9-0.11-1.55-0.54-1.95-1.29
                      c-2.09-2.91-3.02-1.84-6.05-3.35c-2.96-1.48-2.74-5.32-6.52-5.41c-4.54-0.1-3.52,3.25-7.74,0.08c-2.42-1.82-4.32-4.33-5.77-6.78
                      c-0.7-1.19-1.44-2.19-2.16-3.4c-1-1.66,0.66-3.78-2.76-2.94c1.46-0.37-2.54-4.65-3.34-4.78c0.1,0.78,0.06,1.56-0.12,2.33
                      c-0.56,0.28-1.15,0.41-1.77,0.41c-0.6,1.22-0.58,3.86-2.4,4.12C451.17,224.41,451.8,225.12,452.55,225.72z" />
                                        <path class="st0 st-17  state_2" d="M437.03,181.07c-1.61-2.06-3.75-0.83-5.09,1.04c0.49-3.34,4.45-6.65,3.14-10.22
                      c-1.33-3.62-3.54,0.5-5.62,1.14c-1.07,0.33-5.75,0.77-6.81,0.01c-0.86-0.62,0.01-0.25-0.61-1.28c-0.62-1.03-0.09-2.85-0.85-4.13
                      c-0.9-1.52-0.9-1.04-1.9-1.96c-2.1-1.91-3.13-1.8-3.02-5.05c-3.43,0.41-6.48,3.24-10.21,3.61c-3.17,0.32-3.96-0.64-6.52-2
                      c-1.68-0.9-1.25-0.74-3.35-1.38c-1.89-0.58-1.51,0.3-2.39-0.2c-1-0.57-1.64-3.07-2.66-3.74c-1.17-0.78-2.24-0.36-3.52-0.99
                      c-2.14-1.05-1.32-2.75-2.45-3.64c-1.59-1.25-11.43-0.94-13.15,0.38c-0.26,0.2-1.66,2.97-1.7,3.03c-2.09,2.85-2.18,1.6-5.2,2.87
                      c-1.51,0.64-2.04,2.78-3.79,3.5c-2.62,1.06-5.09-3.23-5.4,0.71c3.5,0.17,2.39,4.47,2.06,6.82c-0.3,2.12-0.26,3.31-1.62,5.08
                      c-0.43,0.57-1.87,0.91-2.03,1.64c-0.35,1.54,2.69,3.64,1.83,5.37c-0.76,1.54-4.34,0.44-4.6,4.01c0.05-0.68-0.71,0.63-0.93,0.76
                      c-1.33,0.77-2.22-0.49-3.01,0.85c-0.8,1.37,1.89,3.5-0.99,4.43c4.51,0.31,10.95,4.68,10.97,9.57c0,0.91-1.77-0.38-1.47,2.03
                      c0.21,1.64,3.02,3.88,3.97,5.26c1.33,1.94,2.15,2.98,2.53,5.35c-0.05-0.32-0.14,2.98,0.04,3.16c2.68,2.64,3.8-3.12,4.85-3.39
                      c1.7-0.44,2.72,2.46,3.55,3.35c0.42,0.45,0.42,1.66,1,2.03c0.99,0.63,2.14-0.28,3.17,0.37c2.65,1.67,0.41,5.3,0.76,7.81
                      c0.55,3.98,4.52,3.12,6.93,4.77c2.6,1.79,4.46,5.74,6.82,7.99c2.48,2.36,4.5,2.78,5.1,6.14c0.18,1-0.43,2.41,0,3.29
                      c0.56,1.14,2.33,1.19,3.83,2c1.13,0.61,1.47,1.66,2.67,2.11c0.9,0.34,2.01-0.12,2.83,0.21c1.5,0.61,0.16,0.18,1.09,1.95
                      c1.18-0.35,2.83-1.64,3.87-2.34c0.65-0.44,1.96-0.42,2.37-1.13c0.66-1.11-0.42-1.14-0.37-1.43c-0.03,0.19-0.53-4.96-0.53-5.49
                      c0,0.08-0.51-0.94-0.45-1.87c0.1-1.42,1.4-3.17,1.68-4.56c0.47-2.33-1.2-4.68,2.1-4.59c-0.2-1.92,0.92-3.57,2.27-4.83
                      c0.7-0.66,1.74-1.69,2.76-1.78c1.21-0.11,2.5,1.71,3.25,1.54c0.89-0.58,0.24-2.41,1.09-2.9c1.57-0.89,3.54-0.86,5.27-1.19
                      c2.42-0.47-0.79-0.56,3.08-0.8c1.25-0.08,3.28,0.34,4.5,0.57c2.43,0.48,4.38,0.51,6.94,0.81c2.37,0.28,3.63,1.09,5.62,2.26
                      c0.21,1.57,1.02,2.13,2.43,1.66c0.83-0.06,1.66-0.13,2.49-0.2c-2.05-4.27-4.68-5.67-5.16-10.87c-1.83,1.57-2.49-1.63-2.33-3.06
                      c0.21-1.96,1.59-3.3,1.84-5.41c0.31-2.64-0.8-5.02-1.88-7.32c-0.99-2.12-1.21-5.01-2.25-6.92c-0.26-0.48-1.53-0.44-1.7-0.8
                      c-0.73-1.56-0.16-2.59-0.66-3.93c-0.37-0.98-0.57-1.43-1.04-2.36c-0.29-0.57-1.54-0.48-1.75-1.38c-0.39-1.72,2.47-2.46,1.54-4.8
                      C439.93,181.79,437.95,182.24,437.03,181.07z" />
                                        <path class="st0"
                                            d="M382.43,237.96c-0.47-0.07-2.31-0.4-2.51,0.12C379.49,239.6,382.72,244.25,382.43,237.96z" />
                                        <path class="st0" d="M247.46,620.55c-0.74-0.04-1.39,2.31-3.62,1.03c-3.42-1.95,0.12-2.99,1.16-3.95
                      c0.55-0.51,3.24,0.48,1.28-1.51c-1.94-1.97-4.6,0.24-5.28,2.1c-0.87,2.36,0.01,4.4,2.16,5.52c0.58,0.3,2.11,0.54,2.75,0.39
                      C248.13,623.59,247.59,623.14,247.46,620.55z" />
                                        <g>
                                            <path class="st0 st-18 state_9" d="M488.12,318.19c-2.13,5.87-6.2-1.48-9.17-0.51c-0.08-1.14-0.07-2.27-0.1-3.41
                        c-4.11-0.22-9.86,1.43-13.25-0.38c0.41,0.22-0.8-1.9-0.8-1.9c-0.26-0.23-4.89-1.92-4.92-1.93c-1.4-0.57-3.36-0.94-3.88-1.85
                        c-2.2-3.87,0.96-2.97-4.62-3.45c-3.07-0.26-3.89-1.46-5.95-3.93c-3.7-4.43-1.04-4.16,2.97-6.4c-0.3-0.87-3.52-1.98-4.48-2.64
                        c-2.11-1.47-5.02-3.31-6.75-5.16c-1.54-1.64-2.05-4.5-4.02-5.66c-2.35-1.39-1.42-0.5-3.65,0.17c-1.89,0.57-1.78,0.72-2.91,1.36
                        c-0.16,0.09-2.39,1.43-2.64,1.68c-0.77,0.8-1.44,3.14-2.62,3.54c-1.42,0.48-3.43-2.14-4.6-2.69c0.86-0.92,0.85-1.57,0.71-2.79
                        c-1.92,0.53-5.06,1.67-6.6-0.23c-0.76-0.93-0.14-2.48-0.41-3.52c-0.34-1.3-1.56-1.79-1.39-3.32c0.25-2.19,3.71-5.16,4.52-7.21
                        c0.9-2.28,0.28-3.64,2.49-4.71c-3.45-1.17-5.87-2.53-8.71-4.8c-0.88,3.18-4.33,7.67-6.32,10.2c-0.35,0.44-0.03,1.07-0.34,1.36
                        c-0.47,0.46-1.82-0.31-2.36,0.25c-0.71,0.74-1.11,2.3-1.77,3.27c-0.05,0.08-0.43-0.08-0.49,0c-0.74,1.02-0.81-0.2-1.62,1.48
                        c-0.44,0.91,0.19,2.47-0.08,3.45c-1.6,5.7-5.29,8.66-5.12,15.35c0.1,4.04,1.92,7.94,2.08,12.11c0.11,2.85,0.51,4.57,1.54,7.01
                        c1.11,2.61,3.37,4.06,3.56,7.4c0.04,0.65-1.08,0.69-1.05,0.99c0.04,0.3,0.76,0.47,0.77,0.73c0.1,2.91,1.06,5.51,2.65,7.9
                        c1.55,2.33,2.99,4.45,3.86,7.18c1.4,4.4-0.24,2.37-2.06,5.2c-1.55,2.42,0.86,3.07,0.74,5.28c0.05-0.96-1.56,1.56-1.21,1.06
                        c-0.02,0.03-1.17,2.01-1.22,2.19c-0.52,1.76-0.86,2.94-0.63,4.95c0.32,2.81,1.49,8.07,3.64,9.68c0.48,0.36,9.57,2.64,4.2,4.23
                        c4.79,1.75,0.81,2.93,1.77,5.8c-0.25-0.09-2.06-0.45-2.17-0.14c-0.75,2.13-0.1,1.26,1.02,1.94c2.16,1.32,4.71-0.15,5.04,3.57
                        c-1.03-0.1-15.24,3.57-11.31,6.73c0.27-5.92,9.8-0.31,8.23-5.62c3.08-0.43,4.87,1.03,7.29,0.87c0.99-0.07,2.78-0.45,3.45-0.39
                        c0.29,0.03-0.01,2.01,0.72,2.08c0.14-1.26,2.23-4.95,4.01-4.62c0.75,0.14,0.37,1.34,1.1,1.77c1.44,0.85,2.09,1.43,3.93,1.51
                        c-0.79,0.16-3.06,1-3.12,2.08c4.28-0.98,5.35,0.07,9.57,0.97c1.83,0.39,4.93-0.72,5.27-0.75c2.88-0.26,4.21,0.72,6.46,2.24
                        c1.68,1.14,3.42,2.53,4.55,4.48c-0.01,0.97,0.07,1.93,0.26,2.88c0.56,0.89,1.13,1.77,1.73,2.64c0.55,2.12,1.23,4.28,0.5,6.55
                        c-0.89,2.78-0.22,0.71-2.07,3.36c-0.93,1.33-1.49,2.88-1.91,4.45c-0.99,3.71-4.32,6.97-4.45,11.01c-0.3-0.32-0.88-0.87-1.29-1.07
                        c-0.62,1.25,0.31,2.08-0.53,2.78c1.21,2.5,2,3-0.71,4.82c-0.37,0.25-3.67,1.4-4.34,1.54c-1.48,0.32-5.27-0.89-6.48,0.26
                        c-1.03,0.97,0.25,3.06-0.64,4.03c-1.51,1.66-1.79-1.15-2.86,1.63c-0.43,1.11-0.12,3.55,0.34,4.58c0.46,1.04,1.38,0.28,1.78,1.04
                        c0.67,1.26,1,2.64,0.82,4.04c-1.46-0.09-2.54,0.92-3.12,2.21c-1.39,3.12-0.72,6.01-5.35,7.08c0.93,2.68,2.78,5.16,3.11,8.1
                        c-0.05-0.43-0.55,5.63-1.25,4.2c0.63,1.29,1.62,0.32,2.13,1.17c0.89,1.49,2,0.88,2.43,3.46c0.16,0.94-1.13,3.57,0.07,3.69
                        c0.87,0.09,2.2-3.79,3.82-4.71c0.41,2.49,1.69,0.93,3.18,2.2c1.63,1.39,1.3,3.7,3,4.96c0.29-1.98,3.5-2.12,4.42,0.04
                        c0.92-0.77,3.42-1.68,4.07-2.47c2.24-2.71,0.02-3.18-0.59-5.07c-0.24-0.75-0.9-0.09-1.08-0.85c-0.28-1.2,1.27-1.66,1.28-2.08
                        c0.03-1.19,0.16-2.04-0.87-2.87c-3.82-3.12-6.17,4.16-5.29-4.22c0.17-1.65,0.97-3.53,0.25-5.13c-0.48-1.06-2.73-0.7-3.4-3.18
                        c-0.51-1.89-0.56-4.32-1.01-5.58c0.08,0.22-0.78-0.68-0.91-1c-0.69-1.67,0.2-3.61-1.32-4.99c-1.14-1.04-3.31,0.6-3.66-1.58
                        c-0.16-0.96,0.63-0.76,0.76-1.08c-0.53,1.24,2.49-2.39,1.98-1.98c1.87-1.52,5.83-3.62,5.81,0.63c2.47,0.13,0.73-0.88,1.79-2.09
                        c0.16-0.18,1.33-0.22,1.39-0.31c0.16-0.27,0.1-1.82,0.33-2.06c0.33-0.33,1.21-0.01,1.57-0.37c0.63-0.62,2.42-3.14,3.54-2.29
                        c1.81,1.36-0.7,2.78-0.58,4.03c0.13,1.36,1.12,2.68,1.33,4.09c-1.53-0.06-4.12,0.18-3.94,2.25c0.13,0.08,0.26,0.16,0.39,0.23
                        c0.57-3.42,5.5-2.19,2.76,1.73c2.88-1.01,4.2,0.9,4.47,2.94c1.96-0.69,4.8,0.64,6.13-0.17c0.82-0.5-0.37-1.1,0.92-1.7
                        c-0.15-1.7-1.59-3.57-1.81-5.46c1.61,0.17,3.27,1.33,4.84,1.02c-0.72,3.42,2.49,0.94,3.38,2.26c1.93,2.86-5.47,5.05-3.74,8.02
                        c0.47-2.44,5.08-2.52,5.08-2.52s0.11-2.23,1.12-2.04c1.78,0.34,0.95,1.25,1.9,1.59c0.8,0.29,5.8,0.36,6.4-0.19
                        c0.79-0.73-0.13-2.1,0.57-3.3c1.09-1.84,1.58-0.67,2.71-1.24c1.66-0.84,4.51-1.02,2.71-3.57c1.5-0.38,3.18,0.14,4.49-0.13
                        c1.26-0.26,3.06-2.61,4.66-1.82c0.83,0.42,1.57,3.15,2.76,4.33c0.47,0.47,2.37,1.66,2.55,2.15c0.92,2.49-1.39,2.6-1.87,4.11
                        c-0.44,1.36,0.13,0.71-0.3,1.99c2.51-1.28,3.27,1.34,3.2,3.14c1.45-0.09-2.03-7.06,2.84-4.72c0.05-2.24,3.84,1.16,4.88,1.14
                        c-0.58-2.78,3.11-1.46,3.11-1.46s2.57-1.15,3.19-1.09c-0.83,2.5-0.62,5.87-1.73,8.36c2.8-1.37,2.92-0.93,4.8-0.8
                        c2.28,0.17,4.98,0.31,6.21-1.02c0.19-0.21,1.16-2.62,1.24-3.02c0.03-0.16-0.11-2.45-0.21-2.28c0.71-1.14,2.99-0.61,2.99-0.61
                        s1.15-1.04,2.72-0.58c0.74,0.21,1.13,1.78,2.35,2.06c0.01-0.16,1.35-4.25,3.48-3.89c1.73,0.29,2.7,1.86,2.1,5.2
                        c1.37-0.13,2.32-0.19,3.65,0.24c0.6,0.19,0.54,1.6,1.32,1.92c0.74,0.3,4.61-0.24,5.15,0.44c0.93,1.2-0.8,3.74,0.34,5.12
                        c1.29,1.56,4.48,0.01,6.23,0.48c0.1,0.03-0.06,1.21,0.03,1.24c-0.17-0.06,2.94,0.47,3.29,0.68c1.27,0.78-0.11,2.15,0.65,3.66
                        c0.1,0.21,1.8-0.02,2.12,0.37c0.17,0.21-0.13,1.7,0.06,1.76c0.67,0.23,1.05,0.46,1.48,1.04c-0.32-3.1-0.5-2.12,1.04-2.92
                        c1.21-0.62,3.91,0.31,5.28,0.1c0.67-0.1,2.24-1.11,2.53-1.11c2.94,0,2.61,0.73,4.2,2.5c0.72,0.81,1.74,0.28,2.2,1.67
                        c0.83,2.5-0.98,3.68-3.23,2.99c-0.05,1.87-0.18,1.2,1.02,1.34c-0.2,0.77-0.21,2.46,0.08,3.14c1.43,0.19,2.06,1.01,1.89,2.45
                        c-0.16,0.8-0.37,1.58-0.63,2.35c-0.47,2.05-1.5,2.86-1.55,5.37c-0.54-0.09-0.94-0.15-1.49-0.08c-0.02-1.18,2.77,4.26,2.69,4.14
                        c0.37,0.04,0.74-0.04,1.11-0.05c-0.24,1.42,5.99,4.17,7.12,4.4c4.06,0.81,4.77,0.05,6.06-2.84c0.76-1.71,1.45-5.17,4.11-5.24
                        c-2.18-3.46,0.78-2.59,1.59-5.09c0.2-0.62-0.88-1.1-0.74-1.69c0.2-0.8,0.64-2.68,0.74-3.41c0.18-1.3-1.22-3.66-0.34-5.12
                        c0.7-1.17,3.13-0.57,3.89-2.69c1.34-3.77-3.57-5.43-4.97-7.95c-1.68-3.01-2.43-8.05-1.6-11.39c1.81-7.28,10.02-6.97,14.95-11.39
                        c1.29-1.16,1.54-2.95,2.72-4.22c1.16-1.25,2.98-1.53,4.16-2.59c1.97-1.77,1.93-5,5.54-4.52c1.82,0.24,1.16,1.7,2.58,1.81
                        c0.38,0.03,1.5-1.7,2.17-1.89c1.73-0.49,7.46,2.37,8.53,0.14c1.25-2.6-2.7-3.43-4.06-3.95c-2.23-0.86-3.79-1.72-5.85-2.99
                        c-3.65-2.24-9.09-6.77-10.52-11.35c2.39,0.3,6.89-0.44,5.77-3.53c-1.02-2.82-4.95-1.05-7.02-2.82c-0.81-0.69-1.6-2.71-0.81-3.94
                        c1.15-1.78,2.62-0.54,3.89-1.21c1.15-0.61,1.57-2.05,3.67-2.43c1.11-0.2,7.05,1,7.58-0.51c0.13-0.37-3.42-1.4-3.57-1.5
                        c-1.79-1.23-0.38-3.72-1.77-5.23c-0.65-0.7-3.48,0.08-4.67-0.52c-2.89-1.46-1.45-3.34-2.25-5.76c-0.82-2.47-1.33-1.24-2.34-2.59
                        c-0.98-1.31-0.79-3.23-1.48-4.91c-1.48-3.57-4.71-6.28-8.37-7.77c-1.79-0.73-6.39-1.74-8.19-0.67c-1.33,0.8-1.28,3.12-3.34,3.78
                        c-3.32,1.05-3.69-4.02-8.08-4.34c-3.94-0.29-6.66-0.77-10.85-1.04c-0.12-1.86,0.42-6.35-1.6-7.56c-2.18-1.31-5.67,1.78-8.03,1.05
                        c-1.84-0.57-2.8-2.53-4.42-3.56c-2.06-1.31-5.78-3.04-8.14-3.69c-2.25-0.63-2.09,0.31-3.95,0.41c-0.66,0.04-1.04,1.01-1.99,0.92
                        c-0.2-0.02-2.15-2.01-2.58-2.27c-1.12-0.68-2.67-0.67-3.78-1.36c-0.72-0.32-1.43-0.63-2.15-0.95c-0.02-0.41-0.05-0.82-0.07-1.23
                        c-1.63-1.17-4.49-3.3-6.24-4.08c-3.86-1.7-2.9,0.32-4.27-4.22c-1.22-4.04-4.89-4.77-8.39-6.49c-3.92-1.93-6.25-2.06-10.03-4.9
                        c-3.24-2.44-6.18-7.21-6.61-0.46c-1.51,0.18-1.33-1.6-2.28-1.9c-1.07-0.33-3.05-0.77-4-1.41
                        C491.14,318.99,489.55,314.27,488.12,318.19z" />
                                            <path class="st0 st-7 state_7" d="M392.53,316.12c-0.99-0.62-0.36-1.37-0.78-2.44c-1.97,0.69-1.54-0.58-3.48,0.39c-2.56,1.27-0.15,3.85-2.14,5
                        c1.05,0.7-1.7,2.22-2.21,2.34c1.87,2.09,4.04-0.25,6.34,1.45c0.78,0.58,0.79,2.85,1.76,2.95c2.11,0.21-0.39-0.96,0.6-1.61
                        c0.77-0.5,2.1-0.62,2.6-0.94c0.05-0.74-0.88-1.41-0.99-2.4c-0.08-0.73,0.79-1.05,0.42-2.29
                        C394.44,317.92,393.05,317.12,392.53,316.12z" />
                                        </g>
                                        <path class="st0" d="M386.52,314.46" />
                                        <path class="st0" d="M386.13,319.1" />
                                        <path class="st0 st-28 state_28" d="M561.27,749.23c1.11,0-0.64-5.27-0.5-5.72c3.92,0.77,1.68,4.49,1.04,6.47
                      C561.4,749.81,561.22,749.57,561.27,749.23z M642.12,665.99c0.03-0.3,0.07-0.6,0.1-0.9c-0.9-0.01-1.7,0.27-2.41,0.82
                      c0.21,0.86,3.26,0.3,0.5,2.73c-0.86,0.76-2.58-0.11-3.59,0.32c-1.46,0.62-2,2.72-3.8,2.44c0.62,1.04,1.29,2.02,2.07,2.93
                      c-2.18-0.2-5.42,2.23-5.15,4.38c-4.75,0.49-7.53-1.08-11.94-1.64c-1.97-0.25-3.23,0.66-4.74-1.06c-0.64-0.73-2.4-5.19-2.85-6.13
                      c-2.19,0.59-3.68,0.67-4.79-3.26c-0.25,3.8-3.12,1.73-3.6,4.98c-0.28-0.89-0.82-1.77-1.17-2.64c-0.4,1.53-0.55,3.09-0.38,4.66
                      c-1.74-0.77-3.4-4.03-5.26-2c0.47,0.39,3.88,2.19,3.04,3.02c-1.6,1.09-2.21,2.92-4.06,3.85c-1.98,0.99-3.94,0.82-6.02,0.73
                      c-0.02,0.86,0.24,2.4-0.34,3.12c-0.62,0.76-2.21,0.21-2.5,1.31c-0.69,2.61,2.77,2.81,2.61,5.57c-0.06,1.02-1.45,0.1-1.52,0.55
                      c-0.15,1.08,0.11,2.07,0.61,3.26c-2.07-0.12-3.02,1.89-4.88,1.8c-2.35-0.11-2.43-3.01-4.83-2.94c-0.02,0.8,0.22,2.2-0.25,2.62
                      c-0.29,0.26-1.52-0.17-1.89,0.2c-0.86,0.88-1.46,2.22-2.57,2.78c-1.85,0.94-3.21,1.37-3.81-1.28c-0.14-0.6,1.45-1.11,1.73-1.71
                      c-1.8-1-1.73-4.7-4.38-5.83c-0.98,1.55-3.47,2.66-3.65,3.89c-0.09,0.61,0.71,2.53,0.71,2.45c0-0.11,0.34,0.3,0.32,0.48
                      c-0.1,1.44-1.45,1.51-1.52,2.25c-0.28,2.65,1.56,2.31,0.64,5.02c-0.22,0.65-0.08,1.83-0.5,2.35c-0.26,0.32-1.45-0.24-1.66,0.04
                      c-0.3,0.38-0.44,1.93-0.78,2.11c-3.62,1.88-2.53-0.97-5.23-1.92c-2.44-0.86-4.72,1.45-6.3,2.9c-0.59,0.26-1.2,0.37-1.85,0.34
                      c0.15,0.98-0.1,1.82-0.73,2.52c-0.68,0.61-1.76,0.51-2.37,0.93c-1.07,0.74-2.31,1.47-3.43,2.28c-4,2.87-2.63,7.44-4.5,11.18
                      c-2.06,4.12-6.71,1.83-9.83,4.75c-0.59,0.02-1.16,0.15-1.71,0.41c0.07,0.63,0.16,1.26,0.29,1.88c-1,0.93-1.22,0.65-2.42,1.2
                      c-1.74,0.8-5.24,1.44-6.93,0.52c-0.25,1.44-1.85,1.53-2.16,2.44c-0.46,1.34,2.06,2.63-0.54,3.6c-0.93,0.35-4.62-1.04-5.65-1.5
                      c-0.19-0.09-0.8,0.42-1.09,0.27c-0.63-0.3-0.68-1.64-1.1-1.76c-0.78-0.23-1.79-0.98-2.6-0.64c-0.86,0.36-0.66,2.22-1.48,2.82
                      c-2.39,1.77-2.15,0.08-4.26-0.83c0.83,2.55-1.02,2.01,1.75,3.27c1.52,0.69,3.96,0.2,5.18,1.77c2.05,2.64,0,5.79-2.86,5.84
                      c-2.44,0.04-5.4-2.34-6.79-4.1c-0.72-0.92-1.12-2.37-1.73-3.07c-0.77-0.89-2.19-0.68-2.92-2.23c-1.11,0.91-2.86,1.17-3.86,2.09
                      c-0.53,0.49-0.93,1.67-1.63,2.6c3.01,0.45,1.66,0.3,2.15,2.3c0.52,2.13,0.68,3.14-1.19,5.27c-0.92,1.05-3.74,2.81-5.12,2.7
                      c-1.65-0.13-0.73-1.33-1.6-1.9c-0.85-0.55-3.02,0.73-3.29-1.59c-1.15,0.5-1.93,1.91-3.14,2.5c-0.89,0.44-1.39-0.35-2.04-0.13
                      c-0.91,0.31-2.58,1.57-3.52,2.01c-0.61-0.1-1.22-0.19-1.84-0.26c-0.49,0.47-0.97,0.96-1.44,1.45c-1.98,0.35-3.21-0.23-4.71,0.99
                      c-1.33,1.08-1.5,4.67-1.87,5.97c-0.43,1.53-0.74,3.58-2.64,4.45c-3.21,1.47-3.06-1.78-6.27-1.37c-5.67,0.71-0.14,11.59-6.14,5.98
                      c0,3.04-2.42,3.15-4.78,2.54c-2.61-0.67-4.5-1.75-7.19-1.49c-1.01,0.1-2.45,0.57-3.79,0.64c-0.33,0.02-4.19-0.16-4.42,0.21
                      c-0.88,1.44,1.58,3.27-0.6,5.42c0.75-0.74-4.5,1.49-3.54,1.43c-1.35,0.07-2.57-1.05-3.59-1.16c-1.4-0.14-4.62,2.17-4.92-0.93
                      c-1.65,0.67-2.22,1.59-4.08,1.62c-1.55,0.03-2.79-0.93-4.2-1.29c-0.42-0.11-0.73-0.87-1.18-0.96c-1.63-0.31-3.82,0.94-5.83,0.41
                      c0.08,5.84-13.87-2.95-16.72,3.9c-0.26,0.62-0.54,1.81-0.41,2.4c0.25,1.09,1.63,1.4,1.8,1.93c0.73,2.18-0.13,2.62-0.57,3.44
                      c-0.09,0.18-1.23,0.32-1.52,0.74c-0.51,0.73-0.53,2.5-0.54,3.36c-0.02,1.44,0.03,3.29,0.89,4.56c1.09,1.61,2.36,1.21,3.1,3.74
                      c0.6,2.06,0.24,5.48-0.84,7.35c-1.59,2.76-2.51,1.74-4.72,1.77c-2.95,0.04-5.65,0.78-7.74-2.14c-1.91,3.73,1.15,1.51,1.88,3.11
                      c0.87,1.88-0.65,5.95-0.71,8.01c-2.34-0.44-2.32,4.61-1.8,6.06c0.35,0.97,2.42,2.93,3.32,3.45c1.15,0.65,2.29-0.95,3.18,0.6
                      c0.92,1.61-4.55,4.24-1.1,4.13c-0.04,1.04-0.36,2.8,0.34,3.61c-0.31-0.36,4.46,0.31,3.81,0.58c0.95-0.4,0.51-0.56,1.05-0.87
                      c0.97-0.56,0.09-1.66,1.99-2.4c0.83-0.32,2.88,0.19,3.64,0.1c-0.03,0,1.95-1.32,2.04-1.39c-0.07,2.63,0.23,2.59,1.68,4.21
                      c-0.35-0.97-0.05-2.84,0.08-3.96c1.61,1.13,2.02,2.16,3.08,3.46c0.94,1.15,3.37,2.39,2.22,4.3c-1.57,2.6-4.22-1.27-4.94,2.72
                      c-0.6,3.34,2.54,1.61,2.91,4.55c0.19,1.51-1.51,2.7-3,2.42c-1.29-0.25-0.85-1.65-1.67-2.16c-2-1.22-1.88-1.87-4.56-1.87
                      c-0.84,0-0.66,1.7-2.21,0.99c-0.66-0.3-1.5-2.07-1.93-2.58c-0.16-0.19-1.86-1.71-2.3-2.13c-1.49-1.41-1.65-2.86-4.1-3.04
                      c-0.01,1.06,2.45,0.85,2.96,1.59c0.49,0.72-0.55,2.09-0.19,2.83c0.66,1.38,2.91,1.38,3.23,3.36c0.48,2.92-2.61,2.8-2.6,5.78
                      c1.09,0.1,3.02,0.52,4.16,0.12c0.94-5.63-1.96-5.71,4.49-3.1c1.6,0.65,5.46-0.17,6.39,1.01c1.02,1.3-0.89,3.29,1.21,3.74
                      c0.02-1.52,5.28-1.21,6.05-1.39c1.99-0.46,8.25-2.82,4.06-5.14c1.66-0.16,5.29-0.99,6.24,0.68c0.01-0.87,0.31-2.99,2.2-1.45
                      c1.17,0.96-0.37,2.97-0.65,4.32c0.54-1.36,3.31-1.71,4.44-0.99c2.37,1.52,0.37,3.93,1.07,6.09c0.81,2.48,2.97,1.04,2.3,4.48
                      c2.93-1.94,6.23-0.44,6.83,2.32c0.32,1.46-0.84,4.08-0.17,5.52c1.13,2.42,1.6,0.96,4.34,1.49c6.45,1.24,0.65,7.1,1.77,10.33
                      c-6.18-0.47-0.45,4.28-3,6.68c-2.45,2.31-3.55-3.36-6.11-2.23c0.61,1.8,3.31-0.55,2.48,2.31c-0.32,1.08-2.87,0.54-3.72,1.88
                      c-1.57,2.49,1.25,6.48,3.9,6.75c2.93,0.3,4.85-3.14,6.42-5.05c2.24-2.72,1.71-3.65,1.87-6.68c0.19-3.72,1.52-3.94,5.42-4.8
                      c3.41-0.75,6.63-0.85,9.77,0.47c1.38,0.58,5.44,4.13,4.95-0.06c2.68,0.93,1.84-3.49,4.89-0.78c0.83-1.82,2.69-2.15,3.36-3.28
                      c0.65-1.1-0.41-2.95-0.37-3.33c0.24-2.02,0.39-2.53,3.18-2.42c2.38,0.09,4.16,0.71,4.28,3.34c0.29-0.14,0.59-1.92,1.19-1.81
                      c1.83,0.34,1.9,1.82,3.12,2.44c2.62,1.33,0.55,0.24,2.42-0.78c1.59-0.87,2.35-1.26,4.38-1.31c-1.02-2.18-0.16-1.69,0.61-3.33
                      c0.42-0.9,0.87-1.74,1.39-2.56c0.38-0.58,0.96-0.88,1.72-0.9c0-0.64,0.01-1.27,0.03-1.91c1.01-1.17-1.08-2.1,1.98-1.47
                      c1.36,0.28,1.78,1.11,1.95,2.37c2.55-0.29-0.45-2.58,2.43-1.5c-0.48-0.69-1.92-12.55-0.56-11.69c0.89,0.57,2.38,7.36,2.8,8.65
                      c0.79,2.42,0.63,4.44,3.04,5.44c0-0.01-0.84-5.68-0.92-6.36c-0.39-3.1-1.03-6.13-1.38-9.25c-0.31-2.74-0.83-5.49-1.39-8.19
                      c-0.19-0.91-1.99-7.59-3.01-3.93c-0.58-1.71,1.64-1.46,2.17-2.22c0.56-0.8,1.84-3.09,2.16-4.08c0.98-3.1,0.47-7.45-0.4-10.54
                      c-1.22-4.34-3.14-8.25-3.4-12.87c-0.23-4.05,1.16-7.08,2.39-10.76c1.26-3.75,3.29-6.21,5.06-9.65c0.89-1.72,1.18-3.92,2.73-5.29
                      c1.78-1.57,2.92-0.72,4.73-1.64c2.51-1.27,4.34-3.93,7.72-2.98c2.61,0.74,1.85,1.06,2.54,3.56c0.21,0.75-0.69,3.25,1.05,2.8
                      c-0.28-1.09,0.09-1.87,1.09-2.34c-0.05,0.85-0.1,1.71-0.15,2.56c1.83,0.15,1.44-3.26,1.54-4.31c0.44,0.65,3.77,5.22,2.77,1.57
                      c0.35,0.63,0.87,0.83,1.57,0.59c-3.27-0.93,2.12-4.94,2.57-5.39c1.81-1.81,2.4-4.31,3.69-6.43c0.95-1.58,1.3-3.12,2.13-4.63
                      c1.67-3.07,4.49-2.29,7.91-3.44c0.33-2.95-6.11,0.27-6.7,0.21c0.74-3.29,13.66-1.48,13.88,1.07c0.04-0.91,0.07-1.83,0.09-2.74
                      c1.24,0.18,0.81,2.27,0.86,2.99c4.38,0.78,8.5-3.33,11.99-5.11c1.6-0.82,3.92-0.83,5.2-2.23c1.11-1.21,0.84-3.36,1.97-4.32
                      c-0.04,1.25,0.26,4.34,1.03,1.73c0.33-1.11-0.41-2.46-0.21-3.6c-2.59,0.34-3.74-0.92-3.23-3.22c0.16-0.73,1.35-1.26,1.7-2.01
                      c0.46-0.99,0.31-3.1,0.66-4.21c1.83-5.67,8.67-7.15,12.78-11.14c2.21-2.15,3.32-3.62,6.18-5.02c3.55-1.74,8.18-2.46,11.22-4.86
                      c5.34-4.24,6.77-10.72,12.75-14.92c5.1-3.59,11.15-6.05,16.07-9.72c0.24-0.18,2.86-2.77,2.96-2.93c0.41-0.67,0.68-2.01,1.04-2.48
                      c0.48-0.63,0.57-1.73,1.22-2.56c0.31-0.39,3.09-2,3.6-2.38c4.01-3.01,5.98-7.03,9.02-11.09c1.56-2.08,3.82-3.38,5.43-5.37
                      C645.4,667.68,641.53,669.42,642.12,665.99z M560.53,750.5c-3.01-0.18-1.72,2.69,0.47,1.56
                      C561.14,751.48,560.99,750.96,560.53,750.5z" />
                                        <path class="st0" d="M978.65,353.95" />
                                        <path class="st0 st-20" d="M804.25,383.79c-0.95,2.34-1.87,7.31,2.13,6.47c-1.41,2.17-3.44,4.22-4.7,6.4c-0.05,0.08-1.07,3.04-1.03,2.99
                      c-0.93,1.18-2.51-0.11-2.72,1.61c3.34-2.85,3.48,2.76,4.02,4.53c0.26,0.86,1.45,2.51,1.55,3.1c0.19,1.11-1.16,8.35-0.12,5.48
                      c0.21,1.68-0.56,4.36,0.18,6.03c-0.61,1.62-0.06,2.22,1.64,1.78c0.96,0.14,1.89,0.08,2.81-0.18c0.87-1.17-0.22-4.92-2.11-4.33
                      c-0.21-3.43,0.24-2.44,1.37-4.2c2.46-3.84,3.49-2.57,7.63-3.36c1.98-0.38,2.39-1.56,3.34-1.94c0.45-0.18,1.76-0.19,2.55-0.43
                      c3.71-1.15,6.28,0.32,9.83,0.74c4.18,0.48,9.09-1.57,13.09,0.49c1.2,0.62,1.86,3.15,2.88,3.19c0.78,0.03,1.6-3.23,3.74-2.15
                      c2.16,1.09-1.15,5.08,2.39,4.23c0.87-0.21,2.19-2.94,2.92-3.37c1.65-0.97,2.81-0.71,4.6-1.19c-2.96-3.14,4.23-9.42,6.6-2.77
                      c1.89-4.61,0.62-5.11,6.08-5.01c2.54,0.05,3.6-0.25,6.44-0.5c1.07-0.09,5.62-1.34,5.99-0.26c0.73,2.14-2.77,2.44-3.5,3.95
                      c3.17,1.08,1.13,5.92,1.18,8.17c1.77-0.11,3.46-1.77,5.36-1.99c2.98-0.34,2.91,0.67,5.08,1.7c0.99,0.47,5.02,2.07,5.2,2.44
                      c0.97,1.97-1.97,3.76,0.18,6.31c1.62,1.91,7.46,2.92,4.59,7.14c-2.33,3.43-11.72,5.25-11.71,9.57c0.01,3.4,2.52,1.5,3.08,3.22
                      c0.27,0.84,1.01,2.21,0.25,3.03c-2.1,2.24-5.71-1.81-8-1.72c-0.79,2.4,1.8,3.75,1.41,6.04c-0.14,0.84-1.15,0.97-1.4,1.65
                      c-0.45,1.21-0.63,1.98-0.92,3.4c-0.27,1.33-0.61,2.97-0.68,4.32c-0.04,0.76,0.48,3.37,0.36,4.9c5.6-0.65,6.72-2.58,6.88,3.15
                      c3.11-0.07,2.04-2.59,3.09-4.1c0.43-0.61,1.51-0.12,1.87-0.61c0.29-0.41,0.9-2.35,1.15-2.86c0.29-0.6,1.18-0.88,1.52-1.69
                      c0.66-1.56,0.28-4.21,0.37-5.92c0.62,1.35,1.49,2.65,2.6,3.64c2.68,2.41,1.23,1.52,4.54,0.62c3.89-1.05,1.29,1.35,3.13-1.6
                      c1.28-2.05,1.25-4.79,1.35-7.09c0.05-1.05-0.41-5.5,0.27-6.19c0.58-0.59,1.48,0.37,2.29-0.35c1.45,0.41,2-0.24,1.63-1.95
                      c0.06-0.75,0.17-1.48,0.34-2.21c0.03-1.54,0.22-2.69-0.85-3.97c3.36,0.34,3.48-5.07,5.09-7.43c1.26-1.86,2.53-2.13,1.67-4.88
                      c-0.46-1.47-0.35-1.32-1.01-2.17c-0.7-0.91-2.65-0.96-3.08-2.6c-0.71-2.67,1.38-2.06,3.11-3.73c0.7-0.68,1.29-1.67,1.73-2.54
                      c1.14-2.23,1.18-2.39,3.14-4.41c0.47-0.49,1.71-0.61,1.98-1.35c0.17-0.46-1.4-1.8-0.79-2.8c0.43-0.7,3.58-1.69,4.17-1.41
                      c1.13,0.54,0.17,2.82,1.74,3.5c1.92,0.84,3.57-1.17,3.89-2.75c0.25-1.21-0.86-2.45-0.56-3.64c0.13-0.53,0.99-1.21,1.01-1.63
                      c0.01-0.27,0.63-1.05,0.69-1.31c0.03-0.15-0.85-2.37-0.95-1.39c0.03-0.31,0.65-1.77,0.06-1.14c1.38-1.47,1.85-3.74,3.03-5.37
                      c1.1-1.52,2.05-1.19,2.85-3.04c0.67-1.56-0.18-3.86,1.35-5.13c4.89-4.05,1.2,4.8,4.84,1.2c2.37-2.35,1.72-5.66,4.95-7.93
                      c2.52-1.77,5.58-2.44,7.75-4.72c1.08-1.13,1.4-3.49,2.34-4.36c1.6-1.48,4.43-1.44,6.26-2.72c1.38-0.96,2.15-2.41,3.53-3.28
                      c0.72-0.46,1.97-0.11,2.82-0.63c0.12-0.07-0.14-0.99,0.03-1.09c0.84-0.51,2.67-1.2,3.4-2.15c0.92-1.2,0.52-2.41,1.41-3.66
                      c2.03-2.89,5.06-0.71,8.2-1.57c3.1-0.85,9.21-2.21,7.62-6.8c-4.64,4.05-4.23-0.93-5.89-4.41c-1.05-2.21-3.07-5.3-2.04-8.22
                      c0.63-1.77,4.03-3.37,4.17-5.28c-2.09-4.18-25.34,8.49-29.1,10.08c-2.6,1.1-4.15,2.35-6.43,3.64c-2.93,1.66-5.77,3.57-8.81,4.74
                      c-0.63,0.24-2.78,1.1-3.33,1.13c-1.84,0.1-4.23-2.15-5.95-1.73c-0.28,1.54,2.22,3.58,1.05,5.88c-1.26,2.46-4.73,4.56-6.64,6.68
                      c-1.77,1.96-2.8,3.46-3.49,5.85c-0.4,1.38-0.01,1.94-0.37,2.65c0.03-0.06-4.19,3.7-4.09,3.65c-1.73,1.05-4.05,0.65-5.95,0.96
                      c-2.1,0.34-5.23,0.5-7.35,1.12c-2.6,0.76-4.34,2.39-7.31,2.08c-5.87-0.62-9.26-3.56-14.94-0.66c-3.86,1.97-7.68,2.96-11.86,4.04
                      c-1.45,0.37-3.47,1.64-4.68,1.9c-0.81,0.18-3.32-0.22-3.11-0.25c-4.34,0.65,0.23,1.49-3.22,3.67c-0.69-4.3-1.96-1.24-3.98-0.64
                      c-1.33,0.39-2.51,0-3.91,0.2c-1.42,0.2-2.31,1.6-3.91,1.29c-0.13-3.14-1.73-2.38-3.87-1.41c-1.29,0.58-1.03,1.58-2.71,2.23
                      c-1.11,0.44-2.82,0.08-3.98,0.03c-5.48-0.27-11.92,1.63-17.42-0.43c-2.42-0.9-4.09-3-6.71-3.51c-0.88-0.17-2.77-0.19-3.61,0.11
                      c-2.16,0.79-0.58,0.81-1.97,1.93C813.09,379.53,806.17,379.13,804.25,383.79z" />
                                        <path class="st0" d="M978.3,353.9" />
                                        <path class="st0 st-19 state_19" d="M796.74,398.57c1.64-1.37,1.89-1.57,3.27-3.58c0.42-0.62,1.98-1.64,2.23-2.44c0.44-1.38-0.41-0.42-0.43-1.53
                      c-0.05-3.13-0.89-5.56,0.52-8.75c-3.83,1.12-7.76-0.25-11.48,1.5c0.01-1.05,0.43-1.89,1.25-2.54c-2.06-0.44-3.37-1.55-5.08-2.07
                      c-2.49-0.75-2.59-0.12-4.94,0.36c-4.68,0.96-3.92-0.36-7.22-2.52c-1.03-0.67-2.47-0.37-3.63-1.09c-1.96-1.22-2.25-2.75-3.08-4.73
                      c-0.78-1.85-2.46-5.37-3.78-1.49c-0.04-0.23-0.88-2.11-1.08-2.15c-1.54,1.56-2.27-0.56-3.55-0.39c-2.95,0.39-0.15,0.06-1.77,1.77
                      c-2.05,2.16-3.77,2.34-6.79,1.85c-1.63-0.26-4.51-0.31-6.18-0.82c-2-0.61-2.47-3.1-3.72-3.33c0.33,2.52-0.31,4.08,0.94,5.86
                      c0.3,0.42,1.6,0.81,2.1,1.38c0.51,0.59,0.81,1.17,1.01,1.94c0.3,1.16-0.04,2.23,0.4,3.41c0.47,1.26,1.76,2.06,2.17,3.3
                      c0.97,2.98-0.02,1.8-0.94,4.32c3.33,2.29,2.52,2.07,3.07,6.15c0.49,3.61,2.5,6.14-0.36,9.16c-1.39,1.47-2.93,2.61-4.3,4.19
                      c-0.25,0.29-1.85,1.23-2.33,1.62c-0.53,0.43-0.66,2.05-1.09,2.53c-0.87,0.05-1.75,0.03-2.62-0.06c0.03,0.67-0.07,1.31-0.3,1.93
                      c-0.51,0.79-1.41,2.29-1.19,3.28c0.23,1.06,2.53,2.85,3.35,3.39c1.86,1.2,3.35,1.02,4.57,3.58c1.08,2.27,1.13,4.71,1.47,7.22
                      c-3.02,0.42-3.15-1.61-5.8-0.07c-2.59,1.51,2.13,2.25-3.34,2.39c0.36,1.3,3.77,5.58,3.76,6.21c-0.03,1.8-3.08,2.54-2.73,4.32
                      c0.15,0.75,2.84,2.42,3.35,3.58c0.89,2,0.85,4.8,0.31,6.9c-0.54,2.1,0.26,2.02-1.53,2.85c-0.19,1.73,5,3.81,2.63,7.1
                      c-1.09,1.51-3.49-0.54-4.04,2.24c-0.06,0.33,1.26,1.29,1.45,2.35c0.63,3.5-2.29,6.64-5,8.16c1.1,0.46,1.72,1.74,1.9,2.86
                      c-1.92-0.09-3.95-0.02-3.02,2.42c-3.43-2.99-2.77,1.04-3.49,2.69c-0.47,1.08,0.43,1.29-0.63,1.68c-1.96,0.74-4.06-2.44-6.43-2.3
                      c1.82,2.04,1.38,7.8-2.37,6.59c1.2,4.61-4.55,0.9-6.45,0.95c-2.49,0.07-2.28-0.22-2.33,2.94c-1.97-2.75-1.54-0.65-2.58,0.43
                      c-1.44,1.5-0.48,1.94-2.85,2.91c-2.74,1.11-4.66,1.24-7.29,3.08c-1.87,1.31-2.67,2.37-3.87,3.94c-1.15,1.5-0.34,1.82-2.32,2.42
                      c-1.58,0.47-3.44-0.33-4.6-1.25c-2.17-1.71,0.1-3.53-4.01-2.76c1.07,4.23-0.34,3.08-4.39,3.14c1.94,4.13-1.72,4.91-1.8,8.47
                      c2.41-0.15,1.59,1.51,2.57,1.83c0.94,0.31,2.17-0.5,3.07-0.06c1.47,0.7,1.42,1.27,2.67,2.05c0.45,0.28,2.85,1.6,3.43,1.91
                      c2.5,1.34,0.42,0.8,3,1.54c-0.13-0.04,3.36,0.45,3.11,0.44c1.39,0.09,6.48-0.9,5.89,2.06c-0.35,1.8-3.11,0.5-2.77,3.77
                      c0.45,4.27,6.85,3.19,6.25,7.38c2.58-0.4,7.39,4.14,4.29,6.25c2.54,1.55,1.38,2.18,2.68,3.94c0.6,0.82,2,1.16,2.85,2.05
                      c-3.35,0.2-6.57,2.9-2.65,4.98c1.88,1,4.01-0.2,5.47,2.13c0.54,0.87-0.21,7.72,2.21,7.01c-1.46-0.51,1.72-1.67,1.39-1.38
                      c1.86-1.6,2.28-4.64,5.03-0.83c0.84,1.16,0.45,2.66,1.48,3.71c0.86,0.88,3.01,1.29,4.12,1.84c2.31,1.14,4.43,2.46,4.27,5.36
                      c1.61-1.4,3.39-1.21,5.03-2.21c1.61-0.98,1.5-1.53,2.49-2.94c1.51-2.14,3.19-4.53,5.26-6.5c1.2-1.14,2.3-2.57,3.56-3.39
                      c4.08-2.67,2.22-3.78,1.04-8.15c3.08-0.89,3.7,3.28,3.24,5.41c-0.76,3.49-1.44,2.63-0.24,6.1c0.06,0.17,1.02,3.37,0.87,3.26
                      c2.06,1.51,3.18-3.74,6.08-3.39c0.56,0.34,0.74,0.88,0.52,1.64c1.49,0.56,2.08,0.14,1.77-1.24c0.98-0.36,0.6-1.24,2.53-1.38
                      c-0.71-2.21-0.52-5.66,1.07-6.9c0.59-0.46,2.26,0.12,3.09-0.24c0.44-0.19,2.2-2.11,2.44-2.4c0.72-0.85,1.68-3.03,2.63-3.45
                      c2.85-1.27,5.51,3.05,7.27,4.33c-0.49-2.59-2.4-4.38-3.21-6.8c-0.62-1.83-0.33-3.68-0.71-5.53c-0.78-3.81-2.76-7.57-2.81-11.25
                      c-0.02-1.85,0.5-2.61-0.41-4.51c-0.56-1.17-1.79-1.5-2.1-2.54c-0.54-1.8,1.29-8.58,3.9-7.88c-2.81-1.68-4.47-0.39-6.94-0.3
                      c-2.74,0.09-2.59-0.19-2.33-3.7c0.1-1.36,1.96-4.97,1.39-6.07c-0.61-1.17-4.35-2.72-5.56-3.89c-1.93-1.87-0.8,2.68-2.11-2.19
                      c-0.35-1.29-0.44-3.93,0-5.08c0.99-2.55,2.63-2.15,4.14-4.26c1.77-2.47,2.91-6.84,1.38-9.69c-1.42-2.64-4.1-2.54-7-3.21
                      c1.94,0,3.82-0.14,5.63,0.65c-0.06,0.12,0.23,0.23,0.3,0.26c-1.46-2.2-5.57-2.17-7.95-2.64c-1.1-0.22-3.16-0.42-4.15-0.83
                      c-1.62-0.67-0.59-0.94-1.93-1.73c-1.35-0.79-3.68-1.48-4.85-2.7c-0.74-0.77-3.49-4.02-3.68-4.69c-0.57-1.99,1.56-6.75,2.54-9.12
                      c0.59-1.41,0.73-3.42,3.53-2.18c1.96,0.87,0.43,2.81,3.41,2.46c-1.01-0.45-1.43-1.23-1.26-2.33c3.32-0.2,1.34-0.18,2.89-1.96
                      c0.93-1.07,1.58-0.88,1.99-2.12c0.91-2.74-2.17-3.38,1.03-5.03c1.16-0.6,4.06-0.41,5.29-0.44c4.42-0.14,11.32,0.45,9.68-6.82
                      c-2.54-0.5-0.69,2.93-3.96,1.05c-1.59-0.92-2.92-4.84-3.48-6.51c-2.96,2.67-7.59,3.14-10.29-0.6c-2.09-2.88-1.01-4.73-5.15-6.65
                      c-3.59-1.67-6.98,0.56-6.31-4.78c0.16-1.28,0.88-2.37,1.1-3.49c1.17-0.16,1.42-0.76,0.74-1.82c-0.55-0.58-0.73-1.23-0.53-1.96
                      c0.37-2.43,2.1-2.46,3.71-3.74c1.37-1.1,1.54-2.23,2.6-3.2c1.25-1.14,3.87-2.49,3.49-3.82c-0.59-2.05-1.53-0.57-2.71-1.76
                      c-1.58-1.59-3.48-5.44,0.28-4.84c-0.73-0.12,2.97,2.75,2.63,2.46c1.71,1.44,1.14,1.69,4.15,1.9c-0.99,3.75,1.68,0.34,2.89,2.77
                      c1.02,2.05-1.46,3.59-1.3,5.44c0.86,0.08,1.71,0.03,2.55-0.15c-0.1,1.23-0.03,2.45,0.2,3.66c0.42-2.45,0.54-8,2.68-4.1
                      c1.85-3.82,1.86-0.6,6.1-0.95c-0.73-0.96-4.78-5.4-4.09-6.68c1.01-1.87,4.56,0.38,5.39,1.4c2.72,3.37,1,7.1,5.34,9.92
                      c2.08,1.35,4.17,2.46,6.66,2.77c3.19,0.4,2.99,0.19,4.3-2C795.19,404.63,794.85,400.19,796.74,398.57z" />
                                        <path class="st0 st-16" d="M883.27,465.95c0.23-1.67,0.65-6.48,0.2-7.2c-0.77,0.77-1.12,1.95-1.6,2.25c-0.71,0.44-1.57,0.62-2.24,1.18
                      c-2.15,1.78-2.58,4.56-4.6,6.3c-5.09-4.88-6.51,1.98-11.75,3.34c-3.32,0.86-5.63-0.08-7.33,3.72c-1.09,2.45-1.67,6.16-2.52,8.78
                      c-1.23,3.79-0.75,4.98,1.25,8.15c2.33,3.69,1.82,6.02,3.05,10.04c0.43,1.42,1.38,9.06,2.79,9.66c3.66,1.57,2.28-3.97,2.07-5.47
                      c-0.22-1.54-1.86-6.94,1.3-5c2.16,1.33,1.28,5.01,2.27,7.02c0.55,1.13,4.01,5.61,5.32,5.48c1.72-0.16,5.2-6.61,5.34-7.88
                      c0.34-2.93-3.46-6.6-1.61-9.42c0.58-0.89,2.6-0.21,2.95-0.87c0.71-1.34,0.01-1.97,0.24-3.63c0.16-1.13,0.32-4.28,0.9-4.82
                      c0.85-0.79,1.5,0.19,2.37-0.38c0.35,0.06,0.71,0.12,1.06,0.18c0.27-0.84,0.69-1.58,1.27-2.23c1.29-0.48,1.26-2.45,2.43,0.35
                      c0.3-2.04,2.14-1.46,2.72-2.52c0.78-1.42,0.94-4.75,0.86-6.28c-0.08-1.48-0.79-8.11-2.07-8.76c0.48,0.08,0.73-0.13,0.77-0.62
                      c-0.43,0.08-0.86,0.16-1.29,0.25c-0.09-0.7-0.11-1.41-0.08-2.12C885.99,465.64,884.63,465.79,883.27,465.95z" />
                                        <path class="st0" d="M907.61,458.24c-2.82,2.06-3.18,1.34-4.95-0.68c-0.41,1.86-1.35,2.23-2.74,3.34
                      c-0.18,0.09,0.38,2.7,0.24,2.97c-0.16,0.31-1.63-0.06-1.84,0.23c-0.46,0.66-0.78,1.97-1.51,2.72c-1.12,1.16-3.52,2.57-5.22,1.98
                      c-1.74-0.61-1.27-1.38-1.25-3.74c-3.2,0.42-0.53,3.35-0.08,5.77c0.63,3.36,1.09,6.13,0.64,9.66c-0.45,3.45,0.57,4.97,1.11,8.25
                      c0.27,1.61-0.55,2.71,0.1,4.33c1.02,2.55,1.94,1.52,2.25,4.73c0.39,4.05-0.56,7.35,0.68,11.35c1.13,3.65,3.26,6.6,4.65,10.18
                      c1.24,3.19,2.95,6.56,3.58,9.95c0.69,3.73-0.6,9.48,2.18,12.56c3.98,4.41,0.01-7.66,5.56-1.95c1.57,1.62,2.93,7.07,6.32,4.66
                      c1.48-1.05,2.01-5.63,3.09-6.84c1.72-1.93,2.8-0.56,4.32-2.11c0.75-0.76,1.02-5.02,0.92-5.77c-0.27-2.09-2.08-3.53-2.9-5.7
                      c-1.27-3.34-0.72-8.42-0.62-11.92c-1.83,0.91-3.61-2.7-2.62-3.95c0.5-0.63,4.04,0.25,5.01-0.02c4.05-1.13,4.83-7.76,5.11-11.76
                      c0.41-5.85-0.12-10.95-2.04-16.49c-0.48-1.4-6.12-11.66-4.62-12.52c-1.99-0.39-8.94-1.71-9.84-3.06c-1.13-1.7,0.8-3.66-1.24-5.46
                      C911.02,458.18,908.64,457.5,907.61,458.24z" />
                                        <path class="st0" d="M923.26,425.83c-2.37,1.69-2.13,5.04-3.06,7.58c-0.61,1.66-0.7,5.75-1.77,7.57c-1.1,1.87-1.87,0.53-2.97,1.63
                      c-0.99,0.99-0.66,3.12-0.78,5c-0.12,1.92-0.71,9.29-2.37,10.1c2.65,1.06,1.34,2.52,2.2,4.34c0.87,1.84,0.13,0.94,2.4,2.11
                      c2.86,1.47,6.04,1.67,8.6,3.36c0.97,0.64,1.25,1.93,2.77,2.52c1.68,0.65,7.34,0.85,7.43-2.35c1.5,0.49,2.38,2.83,3.88,3.08
                      c2.46,0.41,1.1-1.33,2.99-1.41c0.89-0.04,4.84,1.07,5.51,1.56c0.41,0.3,1.66,3.55,2.88,3.23c2.16-0.57,2.68-9.67,2.96-11.17
                      c0.77-4.1,2.26-8.45,3.92-12.25c1.41-3.22,3.02-6.51,4.82-9.62c2.37-4.1,5.48-7.34,5.16-12.37c-0.39-6.18-3.17-0.72-6.13-4.52
                      c-1.28-1.64-0.06-8.73,1.67-9.69c-3.54-1.49-3-4.97-2.94-8.08c-5.16-0.1-3.03,5.22-6.67,6.85c-3.8,1.71-9.15-0.22-13.24,0.13
                      c-3.08,0.26-2.36,0.07-3.63,2.6c-1.23,2.44-1.89,4.79-3.59,7.04c-1.37,1.81-1.9,2.57-4.14,2.82
                      C927.18,426.08,924.84,424.08,923.26,425.83z" />
                                        <path class="st0" d="M953.3,377.45c-0.55,2.2-5.48,7.01-6.97,3.13c-0.41,3.71-2.22,4.26-3.98,6.72c-1.83,2.57-1.7,5.13-1.91,7.82
                      c-0.04,0.5-0.93,0.75-1.03,1.2c-0.29,1.26,0.85,2.88,0.43,4.41c-0.9,3.29-5.95,5.87-8.48,2.55c-0.95,1.52-2.51,2.02-3.66,3.19
                      c-1.94,1.99-1.25,2.12-2.6,4.6c-1.02,1.87-2.01,2.1-4.07,3.14c1.26,2.28,2.91,0.97,4.02,3.99c0.6,1.63-0.55,3.84,0.71,5.35
                      c5.68,6.81,8.95-8.18,10.38-10.09c2.71-3.62,12.04-0.24,15.93-1.13c4.4-1,1.73-2.33,3.64-5.18c0.74-1.1,4.18-2.61,5.54-1.97
                      c1.44,0.67-0.16,3.9,0.46,5.43c1.57,3.86,4.78,3.89,6.91,0.76c2.01-2.97,0.22-5.12,0.84-8.57c0.58-3.21,2.92-5.3,4.36-7.84
                      c1.34-2.36,2.23-5.46,2.31-8.53c0.04-1.33-0.19-3.07-0.9-4.23c-0.47-0.08-0.93-0.1-1.4-0.03c-0.05-0.55-0.11-1.09-0.16-1.64
                      c-2.68-1.72-7.6-4.09-10.72-4.85c-1.97-0.48-4.41-0.74-6.43-0.51C953.45,375.5,954.04,374.57,953.3,377.45z" />
                                        <path class="st0" d="M893.1,432.88c2.2-0.8,8.98-4.8,8.1-7.13c-0.46-1.23-4-1.92-4.9-3.27c-1.12-1.68-0.08-3.15-0.67-4.7
                      c-0.53-1.38-4.3-4.16-6.4-4.3c-2.89-0.2-5.41,2.33-8.51,2.29c-0.15-3.76,2.48-8.52-2.15-9.31c0.54-0.83,0.81-1.84,1.31-2.7
                      c-1.28,0.07-2.58,0.72-3.59,0.79c-2.28,0.16-3.9-0.52-6.13-0.95c0.37,2.85-2.36,7.18-3.44,9.83c-1.18-3.21-1.31-8.83-5.11-5.61
                      c0.34-0.17,2.71,2.9,2.87,3.08c-3.47,1-6.25,0.98-8.27,3.39c-0.2,0.24-2.15,2.71-2.18,2.73c-2.46,0.97-5.41-0.64-5.58-3.32
                      c-2.51,2.86-3.67-1.34-5.03-2.06c-1.9-1-5.38-1.36-7.6-1.2c-5.26,0.38-10.58-1.94-15.6-0.33c-1.74,0.55-2.94,2.02-5.24,2.33
                      c-1.08,0.14-2.71-0.37-3.71,0.04c-1.23,0.5-2.41,2.48-2.39,3.52c0.04,2.66,3.27,5.17,0.59,7.85c-1.08,1.07-5.14,1.44-6.03,0.04
                      c-0.09,2.34-0.42,7.01,2.16,8.3c1.92,0.95,5.07-0.13,7.36,0.7c5.84,2.12,11.26,3.39,17.64,2.82c3.95-0.35,7.83-0.39,11.77-0.63
                      c3.25-0.2,6.24,0.54,9.35,0.27c2.84-0.24,4.05-0.09,7,0.28c1.43,0.18,6.18,1.26,6.65-0.63c-0.68,2.8,13.01-1.1,13.96-1.1
                      c1.34-0.01,2.7,0.03,3.94,0.58c1.14,0.5,2,2.18,2.9,2.5c3.28,1.21,4.02-0.98,6.03-2.47c-0.41-0.29-0.82-0.58-1.23-0.87
                      C891.64,433.41,892.41,433,893.1,432.88z" />
                                        <path class="st0 st-22" d="M1040.61,312.39c0-0.98-1.83-2.66-2.2-3.72c-0.84-2.42-0.14-2.2-1.86-4.13c-0.91-1.02-2.4-2.99-3.72-3.55
                      c-2.39-1.02-3.33,0.36-5.56,0.56c-3.12,0.28-6.85-0.17-10.07-1.38c-4.68-1.75-8.08-0.5-9.97,4.2c-1.42-0.46-2.88-0.68-4.37-0.67
                      c-0.42-1.96,1.47-1.41,1.84-2.77c0.28-1.03-0.65-1.2-0.41-1.94c0.82-2.55,1.63-2.54,3.02-4.85c0.42-0.7-0.49-1.61,0.21-2.65
                      c0.57-0.86,1.87-0.95,2.44-1.77c0.67-0.97,1.72-1.86,1.37-2.83c-0.26-0.73-1.92-1.19-2.42-1.72c-1.11-1.18-1.71-2.36-2.58-3.67
                      c-1.53-2.3,1.08-2.38-2.09-2.87c-1.22-0.19-3.26,1.01-3.96,1.86c-0.77,0.94-0.82,5.66-2.6,4.89c-3-1.3,2.45-4.63-3.15-5.05
                      c0.15-2.25,7.49-6.58,6.48-8.08c-0.99-1.48-2.1,0.1-3.5-0.41c-1.49-0.54-1.34-1.38-2.45-2.37c-0.92-0.82-3.54-4.55-4.4-4.75
                      c0.01,2.85-6.13,5.45-8.11,6.61c-1.82,1.07-5.24,2.38-6.32,4.24c-1.09,1.87,1.13,3.32-1.82,3.53c1.44,2.32-0.7,3.83-2.65,4.23
                      c-3.2,0.65-5.56-2.15-8.57-2.64c-2.87-0.46-5.69,0.98-8.5,0.04c-3.13-1.05-5.06-4.66-8.74-4.42c-0.24,4.47-3.05,2.92-6.22,4.71
                      c-2.35,1.33-4.76,4.21-6.08,6.52c-0.41,0.72-0.31,2.42-1.01,2.95c-0.56,0.43-1.74,0.14-2.02,0.43c-0.11,0.11-1.33,0.92-1.39,0.98
                      c0.19-0.17,0.69,1.74,0.53,2.07c-0.49,1.02-2.02,1.03-2.82,1.64c-0.89,0.68-1,1.37-1.92,2.11c-1.43,1.15-3.43,3.36-4.99,4.19
                      c-1.33,0.71-2.49,0.24-3.86,0.54c-2.24,0.49-4.21,2.13-6.42,2.73c-4.15,1.13-4.39-0.06-5.18,4.14c-0.91,4.81-2.93,7.82-6.81,10.71
                      c-2.08,1.55-8.94,4.63-8.38,8.09c0.26,1.64,3.35,0.8,2.07,3.58c-0.61,1.32-3.68,2.26-4.83,3.09c-2.06,1.49-1.37,1.85-4.68,2.13
                      c-0.91,0.08-1.51,1.22-2.26,1.23c-1.77,0.04,0.33-2.04-2.93-1.47c3.04,1.33-3.25,2.3-3.56,2.46c-1,0.52-1.62,1.65-2.38,2.07
                      c-3.18,1.75-6.12-0.62-9.99,0.13c-4.59,0.89-1.38-0.21-2.62,2.49c-1.18,2.56-0.98,1.24-0.06,4.05c1.08,3.33,3.6,3.46,5.19,6.4
                      c0.94-1.6,6.89-2.82,8.26-2.3c0.15,0.06,2.64,3.39,2.68,3.47c0.96,2.14,0.5,0.96,0.04,2.55c-0.5,1.73-2.5,2.93-2.36,5.01
                      c0.13,1.96,1.45,1.66,2.32,2.91c1.02,1.46,2.43,2.48,2.34,5.01c0.59-0.08-0.61-1.1,0.78-1.31c1.43-0.22,3.53-0.66,4.97-1.12
                      c2.86-0.9,5.48-1.84,8.19-3.2c4.6-2.31,8.06-2.25,13.2-0.77c5.61,1.62,6.85-0.72,12.23-1.27c2.7-0.28,5.33-0.38,7.96-1.11
                      c3.08-0.85,4.16-2.54,5.44-5.15c1.64-3.34,3.09-5.83,5.79-8.59c1.09-1.11,2.42-2.04,3.34-3.32c1.29-1.8,1.09-2.01,0.9-3.65
                      c-0.18-1.46-2.03-3.16,0.4-4.53c1.14-0.64,2.51,0.12,3.62,0.39c2.39,0.57,2.06,0.81,4.48,0.28c4.38-0.96,8.07-3.81,12.08-6.09
                      c6.81-3.87,13.8-6.13,20.7-9.55c3.02-1.5,17.73-7.34,15.81,0.61c-0.94,3.92-5.64,3.43-3.59,8.59c0.62,1.57,1.81,1.67,2.46,2.82
                      c0.49,0.88,0.36,2.92,0.83,3.99c0.78-1.13,2.14-2.01,3.18-2.9c2.85,8.3-1.71,12.42-9.99,13.82c-0.88,0.15-4.48-0.82-4.79-0.57
                      c-0.52,0.42-0.27,2.92-0.85,3.81c-0.66,1.01-3.97,3.86-5.06,4.46c-1.25,0.68-2.49,0.81-3.63,1.46c-1.38,0.78-2.15,2.48-3.56,3.21
                      c-1.12,0.58-3.06,0.34-4.06,1.06c-0.73,0.53-1.54,2.64-2.38,3.68c-2.89,3.54-8,4.27-10.68,7.81c3.31,0.01,6.69-0.14,9.89,0.84
                      c3.21,0.98,5.61,3.41,8.83,4.34c-0.91-2.56,1.43-5.73,3.07-7.57c1.1-1.23,2.14-1.77,3.48-2.59c0.64,0.02,1.26-0.02,1.88-0.14
                      c0.84,0.06,1.17-0.45,0.97-1.53c2.24-2.09,3.12-4.28,5.66-6.06c0.72-0.5,1.85-0.65,2.61-1.22c1.28-0.96,1.52-2.73,2.69-3.7
                      c1.62-1.34,3.37-1.48,4.79-2.95c2.29-2.38,2.4-5.92,5.62-7.98c2.19-1.4,4.72-1.42,7.07-2.11c3.39-0.99,4.85-2.32,6.99-4.73
                      c0.62,2.72,4.6-0.04,6.14,0.43c0.19,0.06,2.54,1.7,2.62,1.82c0.43,0.76,0.59,1.57,0.49,2.41c-0.29,1.12,0.29,1.5,1.75,1.15
                      c1.96,1.35,7.32,4.08,7.21,0.14c-0.07-2.28-4.29-5.39-5.95-6.96c-3.03-2.87-5.2-6.52-2.77-10.32c1.33-2.09,3.32-3.29,4.78-5.29
                      c0.52-0.71,1.24-3.09,1.66-3.49c1.88-1.79,3.9-1.06,6.17-1.2C1040.01,316.16,1039.24,312.51,1040.61,312.39z" />
                                        <path class="st0  st-23 state_18" d="M999.36,338.81c-0.19-0.55-0.38-1.1-0.57-1.65c-2.06,1.53-1.94,3.19-3.68,1.42c-0.83-0.85-1.22-3.5-1.58-4.37
                      c-0.98-2.35-3.23-5.34-1.77-8.42c0.56-1.17,4.84-2.9,3.86-4.89c-1.58-3.22-10.14,0.25-11.99,1.13c-2.02,0.96-10.83,2.64-9.02,5.1
                      c-2.22-2.9-21.61,10.04-24.57,11.17c-0.9,0.34-3.17,1.61-4.19,1.55c-1.44-0.08-3.44-2.56-5.01-1.91c-1.39,0.57-1.1,1.12-0.99,2.47
                      c0.07,0.94,1.62,2.13,0.86,3.99c-0.58,1.4-2.6,2.85-3.7,3.95c-3.16,3.17-6.64,5.93-6.18,10.69c-2.46,0.09-2.92,3.43-5.23,4.26
                      c-1.26,0.45-2.95-0.07-4.28,0.21c-2.09,0.44-4.6,0.57-6.74,1.07c-3.34,0.79-4.84,2.5-8.57,2.05c-3.55-0.43-6.89-2.89-10.64-2.26
                      c-1.04,0.18-3.4,1.59-4.45,2.09c-4.23,2.01-8.52,2.62-12.9,4.21c0.87,2.41-4.57,2.51-5.89,2.66c-0.32,0.04-1.29-0.92-2.18-0.26
                      c-0.89,0.66,0.62,2.57-1.06,3.63c-0.69-4.3-1.96-1.24-3.98-0.64c-1.33,0.39-2.51,0-3.91,0.2c-1.42,0.2-2.31,1.6-3.91,1.3
                      c-0.1-2.47-1.1-2.72-3.29-1.78c-1.68,0.73-0.92,1.69-2.39,2.35c-1.17,0.53-2.67,0.37-3.91,0.34c-5.26-0.12-10.59,1.02-16.01,0.16
                      c-3.85-0.61-9.52-6.79-13.61-3.98c-1.1,0.75-1.01,2.23-2.36,3.43c-1.99,1.75-6.43,1.6-8.84,2.49c-2.97,1.11-3.89,2.33-4.27,5.72
                      c-0.16,1.48,0.2,2.74,0.42,4.14c0.12,0.73,1.41,0.38,1.32,1.2c-0.09,0.82-1.15,1.61-1.53,2.27c-1.02,1.72-2.79,4.11-3.67,5.23
                      c-0.43,0.55-1.43,0.49-2.09,1.57c-0.48,0.8-0.37,2.52-0.46,3.43c1.64-1.05,1.46-5.51,4.52-2.69c1.07,0.98,1.19,4.9,1.58,6.36
                      c0.35,1.32,0.83,1.28,0.92,2.87c0.04,0.61-1.3,7.17-0.04,3.71c0.41,3.28-1.8,9.12,3.09,9.03c4.74-0.08,1.9-4.1,1.41-6.77
                      c-0.17-0.92-0.83-0.36-0.25-2.07c0.13-0.38,1.82-2.67,2.33-2.94c2.42-1.28,6.04-0.31,8.77-1.45c0.57-0.24,0.67-0.95,1.41-1.23
                      c0.71-0.27,2.2-0.27,2.98-0.32c1.58-0.1,2.27-0.12,3.77,0.13c3.07,0.5,5.36,0.73,8.57,0.57c2.23-0.11,4.22-0.06,6.39,0.77
                      c0.61,0.24,1.03-0.16,1.73,0.26c0.65,0.39,0.79,1.46,1.29,1.72c3.56,1.89,1.47-1.14,4.87-0.94c-0.21,5.78,2.92,5.44,5.48,2.24
                      c1.91-2.38,4.1-1.95,7.13-3.08c-1.59-1.47-2.45-4.4,0.4-5.03c2.86-0.64,3.27,2.92,4.02,4.91c0.43-1.15,1.14-2.27,1.51-3.42
                      c0.97-2.98,0.01-3.86,3.09-4.06c1.2-0.08,2.29,1.02,3.54,0.96c1.05-0.05,1.46-0.89,2.4-1.03c2.07-0.32,4.75-0.54,6.77-0.6
                      c-1.61,1.3-3.06,1.54-3.88,3.76c3.8,0.48,1.58,6.07,1.66,8.74c2.8,0.13,5-2.66,7.83-2.28c3.19,0.43,3.82,3.52,7.6,3.74
                      c-3.15,6.37,3.68,5.72,5.07,9.8c1.07,3.13-6.28,7.28-8.87,8.22c2.25,1.6-1.1,1.06-1.91,3.43c-1.28,3.74,2.32,2.86,3.41,4.67
                      c3.44,5.75-7.16,0.83-7.95,0.86c-0.83,2.51,1.79,3.98,1.23,6.52c-0.17,0.79-1.52,1.41-1.85,2.28c-0.45,1.18-0.12,2.47-0.33,3.68
                      c-0.68,3.9-1.15,5.05-1.55,9.17c2.33-0.27,4.64-0.62,6.96-0.88c0.07,2.09-0.69,3.5,1.23,3.87c3.05,0.59,3.57-3.16,4.4-4.58
                      c0.1-0.17,1.05,0.12,1.18-0.1c-0.28,0.47,0.88-1.64,0.53-1.28c1.36-1.38,2.84-4.28,2.9-6.62c1.31,1.34,2.09,3.11,3.68,3.09
                      c0.3,0,3.27-1.17,3.81-1.38c0.64-0.24,1.54,0.43,2.22-0.03c0.75-0.51,1.74-5.36,1.94-6.62c0.31-1.91-0.12-3.9,0.18-5.8
                      c0.03-0.95,0.08-1.89,0.14-2.84c0.39-0.01,0.78-0.01,1.17-0.01c1.83-2.55,1.4,2.66,2.81-3.06c0.06-0.23,0.28-1.54,0.31-2.03
                      c0.34-1.09,0.32-2.18-0.05-3.26c0.32-0.05,0.63-0.11,0.95-0.19c1.15-2.97,1.46-8.24,5.71-9.03c-0.8-1.95,0.15-5.39-1.18-6.96
                      c-1.71-2.04-5.05-0.76-2.76-3.83c0.46-0.61,2.06-1,2.58-1.57c1.11-1.2,0.85-2.76,1.62-3.93c0.99-1.5,4.03-2.26,4.72-3.87
                      c0.34-0.8-0.34-1.9-0.38-1.8c0.48-0.95-1.64-1.05,0.88-1.44c2.64-0.41,0.41,1.25,2.28,2.11c1.98,0.91,4.07,1.69,5.79-0.85
                      c1.38-2.03-0.34-3.7,0.05-5.62c0.2-1.01,1.57-1.52,1.76-2.57c0.5-2.7-0.81-4.34,1.69-7.44c0.74-0.91,2.01-1.19,2.68-2.24
                      c1.14-1.77,0.06-6.23,2.8-6.5c0.1,3.15,0.58,3.81,2.8,2.5c1.12-0.66,1.78-2.25,2.31-3.34c1.49-3.06,1.6-4.21,4.77-6.2
                      c3.32-2.09,6.07-3.58,8.56-6.54c0.99-1.18,0.36-1.61,2.06-2.69c1.61-1.02,3.29-1.01,4.97-2.37c1.38-1.12,2.19-1.81,3.56-2.58
                      c0.46-0.26,1.05,0.06,1.55-0.25c1.28-0.8,4.59-3.47,5.42-4.75c1.07-1.66-0.76-3.22,1.71-4.07c0.48-0.17,3.23,0.78,4.2,0.64
                      c1.12-0.16,1.92-0.75,2.95-1.09C995.62,345.46,1001.19,344.15,999.36,338.81z" />
                                        <path class="st0 st-24 " d="M495.71,70.69c-1.15-2.27-2.13-2.37-3.87-3.56c-1.59-1.08-2.19-1.86-3.54-3.43
                      c-3.37-3.93-6.67-1.59-11.27-2.94c-2.18-0.64-4.27-1.6-6.36-2.48c-0.74-0.32-2.29-0.25-2.89-0.66c-0.4-0.28,0.1-1.72-0.69-2.07
                      c-4.58-2-4.71,3.37-8.58,3.73c-4.87,0.45-8.27-1.7-13.09,0.32c-3.36,1.41-7.15,2.59-10.32,3.91c-1.12,0.47-2.57,1.28-3.67,1.92
                      c-1.23,0.72-0.23,1.1-1.82,1.52c-1.27,0.34-2.72-0.53-4.02-0.17c-2.86,0.78-3.33,2.22-3.33,4.93c6.79-4.89,8.16,3.32,3.93,1.87
                      c2.44,0.95,0.26,9.31,4.1,8.53c-0.84,4.65,0.21,10.66,3.06,14.89c0.96,1.43,4.17,3.19,5.7,3.89c-0.26,1.16,0.21,1.54,1.4,1.13
                      c0.92-0.02,1.83-0.04,2.75-0.06c1.45,0.23,3.4,0.61,4.53,1.7c0.18,0.18,0.33,0.54,0.48,0.67c0.13,0.72,0.29,1.44,0.48,2.15
                      c0.65,0.35,1.36,0.56,2.11,0.65c2.93,2.09,7.82,4.29,5.73,9.01c-0.45,1.02-2.16,2.1-3.31,2.82c-0.97,0.6-4.25,1.05-4.99,1.79
                      c3.36,1.21,0.47,3.14,0.2,5.14c-0.29,2.18,0.82,3.29,1.02,5.29c0.18,1.76-1.42,3.44-1.34,4.44c0.24,2.8,3.22,7.63,5.83,8.97
                      c-0.3-0.76-1.12-6.76-0.79-7.12c0.64-0.7,2.64,0.05,3.41-0.38c1.56-0.85,1.13,1.25,1.47-1.44c0.16-1.24-2.31-5.85-2.78-7.28
                      c-1.3-3.94-2.41-5.97,2.32-6.36c1.24-0.1,3.22,0.71,4.52,0.82c2.31,0.21,4.57,0.06,6.93,0.21c-0.45-3.75,2.75-3.38,3.48-7.34
                      c0.45-2.44,0.42-5.91-1.46-7.85c1.82-0.3,4.8,0.01,6.36-0.62c2.51-1.03,0.92-2.29,2.48-4.59c1.98-2.93,5.15-1.46,7.38-2.92
                      c1.1-0.72,1.83-4.68,2.82-6.69c1.73-3.51,0.95-6.94,2.49-10.31c0.49-1.07,1.37-1.03,1.79-2.39c0.31-1.01-0.18-2.22-0.1-3.24
                      C494.37,75.36,496.43,72.12,495.71,70.69z" />
                                        <path class="st0 st-25 " d="M311.24,161.93c-0.04-1.8-1.39-1.28-1.9-2.62c-1.04-2.71,0.1-2.49-1.69-4.29c-0.7-0.7-2.14-1.14-2.96-1.88
                      c-1.34-1.21-2.31-2.67-3.4-4.07c-3.43-4.38-1.44-2.87,1.38-6.71c1.23-1.67,1.58-2.61,0.74-4.72c-1.07-2.72-3.57-2.89-4.75-5.2
                      c-2.12-4.13,2.1-5.78,4.91-7.3c2.56-1.38,6.34-2.52,3.55-5.11c-3.11-2.9-10.74,2.06-10.05-4.23c0.23-2.08,2.62-2.96,2.9-4.31
                      c0.28-1.33-1.17-2.18-1.21-4.04c-1.3,1.3-4.57,0.77-5.29-1.18c-1.13-3.08,2.63-3.32,4.29-4.97c1.75-1.74,0.92-3.85,1.93-5.74
                      c1.75-3.27,3.88-1.21,6.57-1.71c2.48-0.46,3.8-3.34,6.55-3.64c0.82-0.09,4.04,0.34,5.01,0.52c2.69,0.51,3.42,2.03,5.26,3.06
                      c0.57,0.32,4.33,1.93,4.35,1.93c3.78,0,12.64-0.28,14.81,1.8c1.11,1.06,0.87,2.13,2.92,2.8c2.01,0.66,4.97,0.35,7.15,0.83
                      c1.05,0.23,2.01,0.94,3.14,0.79c3-0.39,4.96-4.61,7.5-5.55c3.03-1.11,1.72,0.27,3.93,0.3c0.46,1.41,1.34,1.34,2.65-0.21
                      c0.75-0.36,1.5-0.69,2.27-0.99c2.24-0.82,4.35-1.08,7.3-1.2c6.87-0.28,2.3-2.52,6.8-5.8c1.96-1.43,8.38,0.56,8.94-2.04
                      c0.4-1.86-4.06-7.71-4.98-9.35c-1.77-3.16-8.08-9.92-6.3-13.75c1.74-3.74,3.39,0.4,5.56,1.79c0.56,0.36,3.22,1.97,3.61,2.1
                      c0.57,0.18,1.74,0.07,2.33,0.29c0.75-0.26,1.47-0.19,2.16,0.2c0.44,0.42,0.72,0.93,0.83,1.52c2.53,1.3-2.68,2.16,3.06,1.36
                      c1.85-0.26,2.67-1.12,3.88-2.61c0.11,0.28,0.22,0.55,0.33,0.83c3.13-2.67,5.43-1.78,2.55-4.84c-2.38-2.53-4.42-1.51-7.3-3.11
                      c-1.85-1.03-1.24-1.93-3.72-2.49c-1.34-0.3-2.9,0.4-4.28,0.11c-4.93-1.02-4.17-4.32-5.2-8.28c-1.34-5.21-3.93-3.2-7.51-5.49
                      c-1.37-0.88-1.23-1.84-2.25-2.91c-1.96-2.06-1.83-1.52-4.32-2.4c-1.71-0.6-2.19-0.27-3.92-1.51c-1.16-0.84-3.11-2.56-4.08-3.69
                      c-2.49-2.88-2.53-6.95-5.36-9.66c-1.34-1.28-3.02-2.63-5.02-2.43c-0.98,0.1-2.74,1.97-3.25,1.93c-4.95-0.36-0.51-5.61-2.39-7.99
                      c-1.12-1.41-6.86-1.59-8.75-1.92c-2.24-0.4-5.13,1.09-7.05,0.75c-2.9-0.51-3.24-4.02-7.11-2.83c-1.57,0.48-1.45,1.81-3.21,2.05
                      c-2.21,0.3-3.86-0.11-6.38,0.77c-1.56,0.54-3.98,0.71-5.42,1.34c0.35,1.92-0.4,2.54-2.25,1.86c-1.13-0.15-2.24-0.41-3.33-0.78
                      c-2.62-0.64-6.97-2.6-9.54-1.12c2.3,1.23,9.53,2.86,5.18,5.82c-2.95,2.01-7.88-0.16-10.82-0.59c-4.47-0.66-8.57-0.44-11.75,2.44
                      c-1.01,0.92-1.74,3.31-2.68,4.32c0.23,1.83-0.49,2.49-2.16,1.97c-1.28-0.54-1.88-0.32-1.79,0.65c-0.3,0.18-1.93,2.39-2.49,2.88
                      c-0.54,0.48-2.77,3.31-2.95,3.41c-3.03,1.6-3.01-1.18-4.62,3.11c-0.83,2.21-0.46,1.76-0.58,3.61c-0.05,0.83-0.59,3.98-0.52,4.24
                      c0.4,1.34,4.82,1.65,4.71,4.11c0.91,0.05,2.48-1.23,3.42-1.47c0.18-0.05,3.38-0.3,4.19-0.28c-0.6-0.02,4.81,1.47,3.89,0.93
                      c1.76,1.04,1.06,4.34,1.99,5.64c1.05,1.46,3.58,2.88,5.13,3.78c0.78,0.02,1.54,0.13,2.29,0.35c0.59,0.55,1.16,1.12,1.69,1.72
                      c2.44,1.06,5.48-0.17,7.65,0.87c4.1,1.96-0.29,3.54-1.1,6.08c-1.18,3.7,2.48,4.45,4.68,5.92c1.45,0.96,3.7,1.63,4.73,2.38
                      c1.82,1.33,1.77-0.5,2.31,2.29c0.46,2.37-2.58,7.1-4.33,8.18c-1.58,0.97-6.33,0.71-7.92,2.31c-1.73,1.73-0.11,6.05-2.67,7.6
                      c-3.63,2.21-5.34-2.79-7,2.81c-1.02,3.44-0.2,6.51,0.47,10c1.29,6.73,2.46,14.1,2.1,21.24c-0.17,3.35,0.45,6.92,0.22,10.17
                      c-0.21,2.88,0.72,5.67,0.32,8.96c2.3,0.05,2.49,0.79,4.06,1.86c0.03,0.47,0.05,0.94,0.08,1.41c0.66,0.03,1.32,0.06,1.98,0.08
                      c2.8,1.06,4.87,0.44,7.39,2.52c2.18,1.79,4.4,2.52,6.19,4.32c0.56,0.57,0.21,1.99,0.97,2.56c1.66,1.24,1.95-0.62,3.56-0.43
                      C311.46,163.39,311.2,162.71,311.24,161.93z" />
                                        <path class="st0 st-26 state_26" d="M471.07,167.32c-1.64-2.32-5.17-5.44-5.74-8.25c-0.54-2.69,3.45-5.64,1.86-7.82
                      c-1.33-1.82-5.05-0.89-6.87-1.34c-2.49-0.62-5.36-1.68-7.33-3.1c0.17,0.12-1.07-2.18-1.33-2.55c-0.66-0.94-1.54-2.11-2.31-3.26
                      c-1.02-1.54-2.52-3.38-2.59-5.28c-0.04-1.08,1.56-1.49,1.64-2.62c0.12-1.82-0.99-2.96-1.23-4.61c-0.32-2.16,1.06-2.85,1.21-4.5
                      c0.18-2-1.98-2.32-0.83-4.25c0.4-0.68,3.91-0.63,4.43-0.9c0.76-0.39,2.04-1.68,2.56-2.49c2.35-3.7-0.1-5.73-3.31-7.55
                      c-0.97-0.55-2.67-0.77-3.46-1.56c-1.12-1.12-0.54-2.24-1.95-3.29c-2.03-1.5-4.59,0.15-6.57-0.77c-1.47-0.68-1.37-1.52-2.77-2.77
                      c-0.57-0.51-1.92-0.6-2.7-1.29c-1.57-1.38-0.75-1.04-1.72-3c-1.28-2.58-3.22-6.06-3.69-8.71c-0.28-1.58,0.83-2.4,0.56-4.02
                      c0.04,0.25-1.69-1.71-1.75-1.85c-1.3-3.17-2.18-7.1,0.77-9.16c0.18-2.85-5.97,1.2-6.83,0.99c-0.32-5.04-2.51-3.65-6.7-3.22
                      c-2.07,0.21-4.53,0.18-6.6,0.18c-1.99,0.01-3,0.7-4.42,0.96c-0.75,0.13-1.67,0.39-2.47,0.53c-2.28,0.4-2.43-0.23-3.67-1.11
                      c-1-0.7-0.24-1.53-1.41-2.05c-0.71-0.31-1.75,0.49-2.52,0.19c-1.01-0.4-8.33-5.99-8.32-5.99c-2.95,1.56,7.91,17.37,8.77,18.97
                      c1.31,2.47,3.87,5.42,0.06,6.94c-2.14,0.85-4.86-1.19-7.28,0.73c-1.86,1.48-0.9,3.7-2.36,5.14c-2.03,2-7.82,0.35-10.59,1.12
                      c-1.4,0.39-2.81,1.87-4.3,2.23c-0.3,0.17-0.6,0.34-0.9,0.5c-1.6,1.01-2.35,0.74-2.25-0.81c-0.76-0.08-0.96-0.55-1.84-0.52
                      c-1.6,0.05-4.69,3.71-6.08,4.53c-1.83,1.08-2.59,1.39-4.67,1.22c-2.25-0.19-6.86-0.71-9.1-1.39c-2.7-0.81-2.88-3.69-4.92-4.2
                      c-1.09-0.28-3.09,0.45-4.32,0.41c-1.62-0.05-3.16-0.55-4.76-0.73c-1.63-0.19-2.9-0.54-4.22-0.91c-4.57-1.3-6.84-4.55-11.93-4.31
                      c-2.23,0.1-2.97,0.46-4.97,1.59c-1.2,0.68-1.41,1.4-2.92,1.67c-1.01,0.18-2.67-0.7-3.38-0.5c-3.26,0.94-2.22,5.55-4.58,7.74
                      c-1.07,0.99-4.31,1.76-4.09,3.28c0.24,1.72,3.03,0.97,3.52,1.09c1.92,0.48-0.04-1.39,1.97,0.1c0.19,0.14,0.04,1.69,0.13,1.89
                      c1.55,3.47,0.86,2.25-1.15,5.5c-3.94,6.34,5.6,2.59,8.43,3.98c0.51,0.25,2.51,2.94,2.52,3.48c0.02,2.12-2.97,2.79-4.45,3.58
                      c-1.45,0.78-5.33,2.37-5.91,4.15c-1.05,3.23,3.35,4.23,4.68,6.42c3.96,6.54-4.36,7.3-3.68,11.24c0.06,0.37,3.68,4.25,4.33,4.9
                      c1.21,1.21,4.07,1.61,4.96,2.86c0.84,1.17-0.09,1.99,0.39,3.15c0.44,1.06,1.53,1.81,2.08,2.6c1.5,2.15,1.05,4.71,5.2,4.45
                      c0.15-1.87,0.09-3,2.4-2.77c0.24,2.64-0.35,5.66-0.67,8.22c-0.19,1.56-1.92,2.63,0.04,4.64c0.85-1.25,3.09-1.45,4.46-1.22
                      c2.39,0.4,1.78,1.79,3.58,2.32c2.28,0.66,2.62-1.42,5.15-0.15c0.52,0.26,0.59,1.72,0.79,1.82c0.55,0.28,1.54-0.36,2.12-0.02
                      c0.96,0.56,2.76,1.93,3.72,2.37c0.3,0.14,5.04,1.18,5.33,1.07c0.48-0.19,1.14-2.24,1.47-2.38c1.11-0.46,3.62-0.45,4.91-1.05
                      c0.1-0.05,1.69-1.89,1.9-2.09c0.39-0.36,1.16-0.66,1.69-1.09c2.27-1.83,2.81-4.63,2.66-7.53c-0.19-3.69-1.5-1.62-2.27-3.37
                      c-0.62-1.41,0.37-3.71,1.58-4.11c2.4-0.81,1.78,1.87,3.83,1.81c1.01-0.03,2.18-2.61,2.73-3.05c0.55-0.43,0.1-0.84,0.79-1.16
                      c1.87-0.86,3.38,0.64,5.13-0.92c0.84-0.75,0.99-2.81,1.87-3.8c1.33-1.5,2.03-1.66,4.09-1.92c2.31-0.29,9.79-0.89,11.44,0.45
                      c0.76,0.62,0.03,2.28,0.72,2.96c0.96,0.95,2.13,0.38,3.2,0.92c2.1,1.05,2.9,3.75,4.83,4.72c1.51,0.76,3.58,0.28,5.3,1.25
                      c1.68,0.95,2,1.93,4.11,2.16c4.38,0.46,7.09-3.07,10.84-3.47c4.06-0.43,1.2,0.38,2.55,3.02c2.04,3.99,5.71,3.44,5.66,9.15
                      c1.67,0,3.78,0.63,5.22,0.22c0.97-0.27,2.22-1.66,3.24-2.09c6.24-2.59,4.49,4.82,3.52,8.72c2.25-0.01,2.41,2.39,4.52,2.29
                      c-0.46-1.13-3-2.11-3.13-2.78c-0.07-0.4,2.59-2.64,3.04-2.9c1.34-0.77,3.08-0.8,4.33-1.51c0.92-0.52,2.28-2.58,3.35-2.39
                      c0.14,2.22-1.09,4.75-0.59,6.91c1.97-0.12,2.63,0.81,1.98,2.78c0.43,0.11,0.86,0.23,1.29,0.35c0.43,0.55,2.08,2.38,2.86,2.66
                      c2.22,0.78,0.48,0.56,1.76,0.11c0.83-0.29,2.28-2.75,3.04-3.23c0.55-0.35,2.44-0.99,2.79-1.28c1.23-1.03,1.49-3.24,3.44-4.39
                      c0.24,4.84,4.57-1.56,5.08-2.02C471.29,171.2,473.9,171.2,471.07,167.32z" />
                                        <g>
                                            <path class="st0" d="M635.44,1014.87c-0.06,0.92-0.06,1.84,0,2.77c1.53,0.2,1.5-1.29,1.71-1.93
                        C637.15,1015.62,636.33,1014.54,635.44,1014.87z" />
                                            <path class="st0" d="M776.2,1010.83" />
                                            <path class="st0" d="M893.76,999.61c-2.14,0.76-2.05,0.08-2.63-1.62c-1.69,1.46-1.48-1.47-3.13-1.06
                        c-0.03,0.18,2.38,4.18-0.89,4.43c0.65,0.27,3.48,3.49,3.76,3.34c0.02-0.3,0.1-0.77,0.04-1.04c4.67,2.43,2.14,0.65,4.31-4.44
                        C894.74,999.35,894.25,999.48,893.76,999.61z" />
                                            <path class="st0" d="M894.78,1034.82c-1.09-0.51-1.83-0.26-2.54,0.42c-1.56,1.48-0.06,1.54,0.79,2.6
                        c0.63,0.78,1.78,1.43,2.71,2.17C895.64,1038.92,896.04,1035.55,894.78,1034.82z" />
                                            <path class="st0" d="M739.26,1005.33c0.21-0.21,0.42-0.44,0.62-0.67c-0.91-0.28-2.08-0.33-2.99-0.18
                        C737.75,1005.48,738.11,1006.35,739.26,1005.33z" />
                                            <path class="st0" d="M615.09,1029.05c-2.31-0.44-1.39,2.32,0.21,2.55c0.16-0.65-0.04-1.15-0.62-1.5
                        C615.38,1030.59,615.2,1030.14,615.09,1029.05z" />
                                            <path class="st0"
                                                d="M615.79,1056.04c-0.32-0.54-1.35-0.54-1.46,0.21C614.84,1056.33,615.33,1056.26,615.79,1056.04z" />
                                            <path class="st0"
                                                d="M628.57,1042.54c-0.18,0.84-0.23,1.71-0.33,2.57C628.1,1046.28,633.54,1042.55,628.57,1042.54z" />
                                            <path class="st0" d="M636.19,998.23c-0.17,0.69,0.09,1.11,0.77,1.26c0.15-0.56,0.2-1.32,0.19-1.29
                        C636.83,998.21,636.51,998.22,636.19,998.23z" />
                                            <path class="st0"
                                                d="M602.24,992.48c-0.21,0.7,1.4,1.78,1.95,1.62C604.56,992.73,602.68,991.04,602.24,992.48z" />
                                            <path class="st0"
                                                d="M646.79,1007.98c0.6,0.1,1.15-0.03,1.65-0.37C648.89,1005.6,646.84,1007.91,646.79,1007.98z" />
                                            <path class="st0" d="M595.62,1001.66c0.17,0.54,0.52,0.93,1.04,1.16c-0.37-1.09-0.46-1.41-0.26-0.99
                        C596.15,1001.24,595.89,1001.19,595.62,1001.66z" />
                                            <path class="st0"
                                                d="M615.11,1000.02c-0.45,1.88-1.15,2.82,0.67,2.82C616.38,1001.83,616.18,1000.7,615.11,1000.02z" />
                                            <path class="st0"
                                                d="M613.56,1059.08c0.04-0.62-0.47-0.79-1.06-0.54C612.02,1058.75,613.52,1059.57,613.56,1059.08z" />
                                            <path class="st0"
                                                d="M619.23,1025.02c-0.75,0.54,0.27,1.28,0.88,1.13C620.45,1026.05,620.03,1024.46,619.23,1025.02z" />
                                            <path class="st0"
                                                d="M627.9,1029.9c-0.06,1.2,0.23,1.13,1.38,1.06C629.21,1030.96,628.73,1029.84,627.9,1029.9z" />
                                            <path class="st0" d="M607.27,975.91" />
                                            <path class="st0" d="M605.27,974.3c0.31-0.01,0.63-0.01,0.94-0.02c-0.51-0.1-0.73-0.36-0.64-0.78
                        C605.48,973.77,605.37,974.03,605.27,974.3z" />
                                            <path class="st0"
                                                d="M606.94,976.84c0.55-0.07,0.84-0.38,0.86-0.93C607.15,975.79,606.86,976.1,606.94,976.84z" />
                                            <path class="st0"
                                                d="M666.81,1061.79c0.34,0.43,0.44-5.26,0.44-3.99C666.65,1058.85,665.91,1060.66,666.81,1061.79z" />
                                            <path class="st0" d="M611.19,1016.27c-0.52,0.46,0.33,2.84,1.54,0.86c-0.11,0.15-0.22,0.29-0.33,0.44
                        C613.01,1016.82,612.02,1015.54,611.19,1016.27z" />
                                        </g>
                                    </g>
                                    <g>
                                        <g>
                                            <path class="st0 st-38 state_38"
                                                d="M929.15,688.96v-5.36v-2.14l1.07-2.14c0,0-0.21-4.71,0-5.36c0.21-0.64,0.86-7.5,0.86-7.5s2.14-4.29,2.36-5.57
                    c0.21-1.29,3-4.71,3-4.71s1.29,0.64,2.14,0c0.86-0.64,2.14-2.57,2.14-2.57s1.07-0.21,1.07,2.36c0,2.57-0.86,4.93-0.86,4.93
                    l0.86,2.14c0,0,1.93,1.71,0,1.71s-3.64,1.07-3.64,1.07s0.21,2.79,1.29,3.43c1.07,0.64,3.43,1.71,3.21,3.21
                    c-0.21,1.5,0.67,7.93,0.01,8.57c-0.66,0.64-4.73,2.79-5.37,1.71c-0.64-1.07-0.81-3.64-1.26-3.64s-1.95,1.29-1.95,1.29
                    s0,3.86-0.21,4.71c-0.21,0.86-2.57,4.93-2.57,4.93s-1.29-0.32-1.29,0c0,0.32,2.14,0.75,3.54,0.75s3,1.93,3.21,2.68
                    s0.75,4.71,0.86,5.46c0.11,0.75-0.43,4.82-0.43,5.79s0.86,6.86,0.11,8.04c-0.75,1.18-3.21,2.04-3.86,2.14
                    c-0.64,0.11-2.79,0-2.79,0s0.64,2.89,1.29,3.54c0.64,0.64,1.71,1.93,1.29,2.57c-0.43,0.64-2.36,0.96-2.57,1.39
                    c-0.21,0.43-0.43,1.18,0.96,1.61c1.39,0.43,2.36,0.32,1.93,1.93c-0.43,1.61-1.82,3.21-2.57,4.18s-2.68,3.43-3.32,4.39
                    c-0.64,0.96-1.18-2.04-1.5-2.36c-0.32-0.32-2.25,0.11-2.25,0.86s-0.54,3.21,0,4.07c0.54,0.86-0.24,4.29-0.24,4.29
                    s-0.13,2.36,0,3.43c0.13,1.07-0.25,3.11-0.06,3.43c0.19,0.32,0.08-3.54,1.37-3.64c1.29-0.11,1.93,3.47,2.04,3.66
                    c0.11,0.2-0.96,3.62-1.29,4.59c-0.32,0.96-1.34,3.11-2.17,3.86s-2.44,2.25-2.76,2.68s2.25,0.54,2.68,0c0.43-0.54,1.5-1.1,1.5,0.36
                    c0,1.46,0.54,4.67,0,4.99c-0.54,0.32-2.57,2.04-3.11,2.46s-1.93,1.71-1.93,1.71s2.79,5.14,1.07,6.32c-1.71,1.18-4.29,1.29-4.61,0
                    c-0.32-1.29,0.96-4.5,1.5-5.57c0.54-1.07,1.39,0,2.14-2.36c0.75-2.36-0.64-3.64-0.64-3.64s-1.18-3.43-0.54-3.54
                    c0.64-0.11,1.5,0.75,1.93,0.43c0.43-0.32-2.14-0.21-3.11-1.71c-0.96-1.5-3.11-4.18-2.79-5.79c0.32-1.61,0.21-2.36-0.75-3.43
                    c-0.96-1.07-0.64-5.89,1.61-4.82c2.25,1.07,2.04,1.39,2.04-1.5c0-2.89-0.64-8.89,0.86-11.36s2.79-3.21,3.21-2.68
                    c0.43,0.54,0.32,2.25,1.07,2.57c0.75,0.32,3.43,0.96,3.54-1.93c0.11-2.89,0.61-4.82,1.8-5.46c1.2-0.64,3.77-2.04,0.98-2.57
                    s-5.25,0.86-5.04-2.68s0.11-10.29,0.11-11.46c0-1.18,0.32-3,1.71-3.32s3.54-2.46,1.71-2.46s-2.14-0.96-2.04-3.11
                    c0.11-2.14,0.21-4.5,0.86-5.04c0.64-0.54,2.25-2.14,2.25-2.14s0.96-0.04,0.82-0.86C929.51,689.96,929.15,688.96,929.15,688.96z" />
                                            <path class="st0" d="M920.74,694.58c0,0,3.91-1.98,4.07-4.23c0.16-2.25,0.7-4.34,0.21-4.66c-0.48-0.32-1.3-1.88-2.04-0.86
                    c-0.74,1.02-1.54,4-1.54,4.7s0.32,0.71-0.21,2.42S920.74,694.58,920.74,694.58z" />
                                            <path class="st0" d="M943.3,726.67c0,0-1.29,0.86-1.71,2.86s-2.86,3.71-2,4.29c0.86,0.57,2.71,2.14,2.71,0.86s0.09-2.14,0.62-1.86
                    c0.53,0.29,0.67,2.14,1.1,0.57S943.3,726.67,943.3,726.67z" />
                                            <path class="st0" d="M938.44,736.96c0,0,4.95,4.29,4.47,6c-0.47,1.71-1.16,2.43-1.16,2.43s-4.17-5.86-4.46-6.57
                    S938.44,736.96,938.44,736.96z" />
                                            <path class="st0"
                                                d="M899.3,760.81c0,0-2,1-1.14,2.57c0.86,1.57,1.71,0.29,2.43,0s0-2.57,0-2.57H899.3z" />
                                            <path class="st0" d="M913.64,812.81c0,0,3.37-2,2.66-7.14c-0.71-5.14-4-9.14-6.86-5.43c-2.86,3.71-4,6.71-3.14,9.43
                    s0.43,3.14,0.43,4.86c0,1.71,0.29,3,2,3.57s3.29,0.86,4.29,0c1-0.86,2-1.43,1.71-2s-0.45-1.86-1.08-2.14
                    S913.64,812.81,913.64,812.81z" />
                                            <path class="st0" d="M928.3,887.24c0,0,1.43,2.43,1.43,3c0,0.57-3.29,2.57-3.29,2.57s-3.29-1-3-2.79
                    c0.29-1.79,2.55-3.21,3.13-3.21C927.15,886.81,928.3,887.24,928.3,887.24z" />
                                        </g>
                                    </g>
                                </g>




                            </svg>
                            <!-- <img src="media/pricing/client-map.svg" class="wow fadeInUp h100 op-4" alt="shape-bg"> -->
                        </div>
                    </div>
                    
                    <div class="col-lg-6">

                        <div class="section-title dark-title  d-none d-lg-block" style="margin-bottom: 10px;">
                            <h2 class="wow pixFadeUp mb-25 font-500  d-none d-lg-block" data-wow-delay="0.3s">
                                We are Present in 20+<br> States in India with<span
                                    style="color: #7052fb;font-size: 48px;"><br> 1000+ </span> Clients
                            </h2>
                        </div>
                        <div class="pixsass-isotope wow fadeIn" data-wow-delay="0.3s">
                            <div class="pixsass-portfolio-items portfolio-one column-3 port-gutters">
                                <div class="grid-sizer"></div>
                                
                <!-- <div class="pixsass-portfolio-item width-large grid-item jammu">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jammu%26kashmir/1.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                <!--------jammu<div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jammu&kashmir/2.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jammu&kashmir/3.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jammu&kashmir/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jammu&kashmir/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jammu&kashmir/6.png" alt="portfolio thumb" />
                  </div>
                </div>--------------->
                                <!--------jammu--------------->
                                <!--------himachal
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/himachal-pradesh/1.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/himachal-pradesh/2.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/himachal-pradesh/3.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/himachal-pradesh/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/himachal-pradesh/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/himachal-pradesh/6.png" alt="portfolio thumb" />
                  </div>
                </div>--------------->
                                <!--------himachal--------------->

                                <!--------punjab--------------->
                                 <div class="pixsass-portfolio-item width-large grid-item  Punjab">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Punjab_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                              <!--  <div class="pixsass-portfolio-item width-large grid-item  Punjab">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/punjab/2.png" alt="portfolio thumb" />
                                    </div>
                                </div> -->
                                <!-- <div class="pixsass-portfolio-item width-large grid-item  Punjab">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/punjab/3.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item  Punjab">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/punjab/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item  Punjab">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/punjab/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item  Punjab">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/punjab/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------punjab--------------->
                                <!--------Uttarakhand--------------->
                                <div class="pixsass-portfolio-item width-large grid-item  Uttarakhand">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Uttarakhand_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                
                                <div class="pixsass-portfolio-item width-large grid-item  Uttarakhand"> 
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Uttarakhand_02.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                 <div class="pixsass-portfolio-item width-large grid-item  Uttarakhand">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Uttarakhand_03.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-large grid-item  Uttarakhand">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Uttarakhand_04.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <!-- <div class="pixsass-portfolio-item width-large grid-item  Uttarakhand">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Uttarakhand_05.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                <!--<div class="pixsass-portfolio-item width-large grid-item  Uttarakhand">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/uttrakhand/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item  Uttarakhand">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/uttrakhand/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Uttarakhand--------------->
                                <!--------delhi--------------->
                                 <div class="pixsass-portfolio-item width-large grid-item Delhi ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Delhi_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Delhi ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Delhi_02.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <!-- <div class="pixsass-portfolio-item width2 grid-item  Delhi ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/delhi/3.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-large grid-item Delhi ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/delhi/4.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Delhi ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/delhi/5.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Delhi ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/delhi/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------delhi--------------->
                                <!--------Uttar--------------->
                                <div class="pixsass-portfolio-item width-large grid-item Uttar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/up_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Uttar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/up_02.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Uttar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/up_03.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-large grid-item Uttar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/up_04.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                 <div class="pixsass-portfolio-item width-sm-large grid-item up  Uttar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/up_05.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Uttar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/up_06.png" alt="portfolio thumb" />
                  </div>
                </div>  
                                <!--  <div class="pixsass-portfolio-item width-sm-large grid-item up  Uttar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/u.p/7.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Uttar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/u.p/8.png" alt="portfolio thumb" />
                  </div>
                </div>  
                <div class="pixsass-portfolio-item width2 grid-item  Uttar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/u.p/9.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Uttar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/u.p/10.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Uttar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/u.p/11.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Uttar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/u.p/12.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Uttar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/u.p/13.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Uttar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/u.p/14.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------END Uttar--------------->

                                <!--------Bihar--------------->
                                <div class="pixsass-portfolio-item width-large grid-item Bihar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Bihar_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Bihar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Bihar_02.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Bihar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Bihar_03.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item Bihar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Bihar_04.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Bihar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Bihar_05.png" alt="portfolio thumb" />
                  </div>
                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Bihar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Bihar_06.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                <!-- <div class="pixsass-portfolio-item width2 grid-item  Bihar ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/bihar/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Bihar--------------->
                                <!--------Rajasthan--------------->
                                <div class="pixsass-portfolio-item width-large grid-item Rajasthan ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/RAJASTHAN_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Rajasthan ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/RAJASTHAN_02.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Rajasthan ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/RAJASTHAN_03.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                 <div class="pixsass-portfolio-item width-large grid-item Rajasthan ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/RAJASTHAN_04.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Rajasthan ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/RAJASTHAN_05.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Rajasthan ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/RAJASTHAN_06.png" alt="portfolio thumb" />
                  </div>
                </div> 
                                <!--------Rajasthan--------------->
                                <!--------Madhya--------------->
                                <div class="pixsass-portfolio-item width-large grid-item Madhya ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Madhya Pradesh_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item  Madhya ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Madhya Pradesh_02.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Madhya ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Madhya Pradesh_03.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-large grid-item Madhya ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Madhya Pradesh_04.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item Madhya ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Madhya Pradesh_05.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Madhya ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Madhya Pradesh_06.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <!-- <div class="pixsass-portfolio-item width-large grid-item Madhya ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/RAJASTHAN_06.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item  Madhya ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/RAJASTHAN_06.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Madhya ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/RAJASTHAN_06.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Madhya ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/m.p/10.png" alt="portfolio thumb" />
                                    </div>
                                </div> -->
                                <!--------Madhya--------------->
                                <!--------Gujarat--------------->
                                <div class="pixsass-portfolio-item width-large grid-item Gujarat ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Gujarat_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                               <div class="pixsass-portfolio-item width-sm-large grid-item up  Gujarat ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Gujarat_02.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Gujarat ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Gujarat_03.png" alt="portfolio thumb" />
                  </div>
                </div>
                 <div class="pixsass-portfolio-item width-sm-large grid-item up  Gujarat ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Gujarat_04.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Gujarat ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Gujarat_05.png" alt="portfolio thumb" />
                  </div>
                </div>
                <!-- <div class="pixsass-portfolio-item width-large grid-item Gujarat ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/gujrat/6.png" alt="portfolio thumb" />
                  </div>
                </div>  -->
                                <!--------Gujarat--------------->
                                <!--------Haryana--------------->
                                <div class="pixsass-portfolio-item width-large grid-item Haryana ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Haryana_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                 <div class="pixsass-portfolio-item width-sm-large grid-item up  Haryana ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Haryana_02.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Haryana ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Haryana_03.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item Haryana ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Haryana_04.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Haryana ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Haryana_05.png" alt="portfolio thumb" />
                  </div>
                </div>
                <!--<div class="pixsass-portfolio-item width2 grid-item  Haryana ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/haryana/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Haryana--------------->
                                <!--------Tripura--------------->
                                <!-- <div class="pixsass-portfolio-item width-large grid-item Tripura ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/tripura/1.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Tripura ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/tripura/2.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Tripura ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/tripura/3.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item Tripura ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/tripura/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Tripura ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/tripura/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Tripura ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/tripura/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Tripura--------------->

                                <!--------Assam--------------->
                               <!-- <div class="pixsass-portfolio-item width-sm-large grid-item up  Assam ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/assam/1.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                 <div class="pixsass-portfolio-item width2 grid-item  Assam ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/assam/2.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item Assam ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/assam/3.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Assam ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/assam/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Assam ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/assam/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item Assam ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/assam/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Assam--------------->
                                <!--------Bengal--------------->
                                <div class="pixsass-portfolio-item width-large grid-item Bengal ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/West Bengal_01.png" alt="portfolio thumb" />
                  </div>
                </div>
                <!--<div class="pixsass-portfolio-item width-sm-large grid-item up  Bengal ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/west-bangal/2.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Bengal ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/west-bangal/3.png" alt="portfolio thumb" />
                  </div>
                </div>
                 <div class="pixsass-portfolio-item width-large grid-item Bengal ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/west-bangal/4.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                <!--<div class="pixsass-portfolio-item width-sm-large grid-item up  Bengal ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/west-bangal/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Bengal ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/west-bangal/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Bengal--------------->
                                <!--------Jharkhand--------------->
                                 <div class="pixsass-portfolio-item width-large grid-item Jharkhand ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Jharkhand_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                               <!--<div class="pixsass-portfolio-item width-sm-large grid-item up  Jharkhand ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jharkhand/2.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                 <!-- <div class="pixsass-portfolio-item width2 grid-item  Jharkhand ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jharkhand/3.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item Jharkhand ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jharkhand/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Jharkhand ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jharkhand/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Jharkhand ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/jharkhand/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Jharkhand--------------->
                                <!--------Odisha--------------->
                               <div class="pixsass-portfolio-item width-large grid-item Odisha ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Odisha_01.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Odisha ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Odisha_02.png" alt="portfolio thumb" />
                  </div>
                </div>
                  <div class="pixsass-portfolio-item width2 grid-item  Odisha ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="images/states/Odisha_03.png" alt="portfolio thumb" />
                  </div>
                </div>
                <!--<div class="pixsass-portfolio-item width-large grid-item Odisha ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/odisha/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Odisha ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/odisha/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Odisha ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/odisha/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Odisha--------------->
                                <!--------Chhattisgarh--------------->
                                 <div class="pixsass-portfolio-item width-large grid-item Chhattisgarh ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/cg_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <!--<div class="pixsass-portfolio-item width-sm-large grid-item up  Chhattisgarh ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/chhattisgarh/2.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Chhattisgarh ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/chhattisgarh/3.png" alt="portfolio thumb" />
                                    </div>
                                </div> -->
                                <!-- <div class="pixsass-portfolio-item width-large grid-item Chhattisgarh ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/chhattisgarh/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Chhattisgarh ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/chhattisgarh/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Chhattisgarh ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/chhattisgarh/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Chhattisgarh--------------->
                                <!--------Maharashtra--------------->
                                 <div class="pixsass-portfolio-item width-large grid-item Maharashtra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Maharashtra_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Maharashtra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Maharashtra_02.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Maharashtra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Maharashtra_03.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-large grid-item Maharashtra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Maharashtra_04.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                               <!-- <div class="pixsass-portfolio-item width-sm-large grid-item up  Maharashtra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/maharashtra/5.png" alt="portfolio thumb" />
                                    </div>
                                </div> 
                                <div class="pixsass-portfolio-item width2 grid-item  Maharashtra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/maharashtra/7.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Maharashtra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/maharashtra/8.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Maharashtra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/maharashtra/9.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Maharashtra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/maharashtra/10.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Maharashtra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/maharashtra/11.png" alt="portfolio thumb" />
                                    </div>
                                </div> -->
                                <!--------Maharashtra--------------->
                                <!--------Andhra--------------->
                               <!--  <div class="pixsass-portfolio-item width-large grid-item Andhra ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/andhra-pradesh/1.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Andhra ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/andhra-pradesh/2.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                <!-- <div class="pixsass-portfolio-item width2 grid-item  Andhra ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/andhra-pradesh/3.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item Andhra ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/andhra-pradesh/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Andhra ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/andhra-pradesh/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Andhra ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/andhra-pradesh/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Andhra--------------->
                                <!--------Karnataka--------------->
                               <!--  <div class="pixsass-portfolio-item width-large grid-item Karnataka ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/karnataka/1.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Karnataka ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/karnataka/2.png" alt="portfolio thumb" />
                                    </div>
                                </div> -->
                                <!--<div class="pixsass-portfolio-item width2 grid-item  Karnataka ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/karnataka/3.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-large grid-item Karnataka ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/karnataka/4.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Karnataka ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/karnataka/5.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                 <div class="pixsass-portfolio-item width2 grid-item  Karnataka ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/karnataka/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Karnataka--------------->
                                <!--------Sikkim
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/sikkim/1.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/sikkim/2.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/sikkim/3.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/sikkim/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/sikkim/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/sikkim/6.png" alt="portfolio thumb" />
                  </div>
                </div>--------------->
                                <!--------Sikkim--------------->
                                <!--------Kerala--------------->
                                <!-- <div class="pixsass-portfolio-item width-large grid-item Kerala ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/kerala/1.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Kerala ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/kerala/2.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Kerala ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/kerala/3.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-large grid-item Kerala ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/kerala/4.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width-sm-large grid-item up  Kerala ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/kerala/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Kerala ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/kerala/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Kerala--------------->
                                <!--------Tamil--------------->
                                <!-- <div class="pixsass-portfolio-item width-large grid-item Tamil ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/tamil-nadu/1.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Tamil ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/tamil-nadu/2.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Tamil ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/tamil-nadu/3.png" alt="portfolio thumb" />
                                    </div>
                                </div> -->
                                <!-- <div class="pixsass-portfolio-item width-large grid-item Tamil ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/tamil-nadu/4.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Tamil ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/tamil-nadu/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Tamil ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/tamil-nadu/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Tamil--------------->
                                <!--------Telangana--------------->
                                 <div class="pixsass-portfolio-item width-large grid-item Telangana ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="images/states/Telangana_01.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <!--<div class="pixsass-portfolio-item width-sm-large grid-item up  Telangana ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/telangana/2.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Telangana ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/telangana/3.png" alt="portfolio thumb" />
                                    </div>
                                </div> -->
                                <!-- <div class="pixsass-portfolio-item width-large grid-item Telangana ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/telangana/4.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                  <div class="pixsass-portfolio-item width-sm-large grid-item up  Telangana ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/telangana/5.png" alt="portfolio thumb" />
                  </div>
                </div>
                <div class="pixsass-portfolio-item width2 grid-item  Telangana ">
                  <div class="pixsass-isotope-grid__img">
                    <img src="media/client-up/telangana/6.png" alt="portfolio thumb" />
                  </div>
                </div> -->
                                <!--------Telangana--------------->
                                <!--------Andaman & Nikobar--------------->
                               <!--  <div class="pixsass-portfolio-item width-large grid-item Nicobar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/andaman-nicobar/1.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Nicobar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/andaman-nicobar/2.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Nicobar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/andaman-nicobar/3.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-large grid-item Nicobar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/andaman-nicobar/4.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width-sm-large grid-item up  Nicobar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/andaman-nicobar/5.png" alt="portfolio thumb" />
                                    </div>
                                </div>
                                <div class="pixsass-portfolio-item width2 grid-item  Nicobar ">
                                    <div class="pixsass-isotope-grid__img">
                                        <img src="media/client-up/andaman-nicobar/6.png" alt="portfolio thumb" />
                                    </div>
                                </div> -->
                                <!--------Andaman & Nikobar--------------->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.portfolio-inner -->
            </div>
            <!-- /.container -->
        </section>
        <!-- /.portfolios -->
        <!--========================-->
        <!--=         Client         =-->
        <!--========================-->
        

        <!--=============================-->
        <!--=         Blog Post         =-->
        <!--=============================-->
        <section class="blog-grid-two">
            <div class="container">
                <div class="section-title color-two text-center">

                    <h2 class="title wow pixFadeUp" data-wow-delay="0.3s">
                        Client Review Videos
                    </h2>
                </div>
                <div class="row text-center">
                    <div class="col-lg-4">
                        <article class="blog-post-two color-two wow pixFadeLeft" data-wow-delay="0.4s">
                            <div class="feature-image">
                                    <iframe width="100%" height="194" src="https://www.youtube.com/embed/TwNwLCbE8wM?si=2wQaCuh0Hg43zfCG" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                            </div>
                            <!-- /.feature-image -->
                            <div class="blog-content">
                                <div class="entry-meta">
                                    <i class="fa fa-user-circle i-color"></i>
                                    <a href="#">
                                        <strong style="font-size: 18px;color: #5334cc;">
                                            Rajshree School Pali
                                        </strong> <br> Director at Rajshree School

                                    </a>
                                </div>
                            </div>
                            <!-- /.blog-content -->
                        </article>
                        <!-- /.blog-post-two -->
                    </div>
                    <!-- /.col-lg-4 -->

                    <div class="col-lg-4">
                        <article class="blog-post-two color-two wow pixFadeRight" data-wow-delay="0.4s">
                            <div class="feature-image">
                                <iframe width="100%" height="194" src="https://www.youtube.com/embed/DOT5ncQ4stg?si=SJwfhfVZaHGbHNa1" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

                            </div>
                            <!-- /.feature-image -->
                            <div class="blog-content">
                                <div class="entry-meta">
                                    <i class="fa fa-user-circle i-color"></i>
                                    <a href="#">
                                        <strong style="font-size: 18px;color: #5334cc;">
                                            Shealing Public School
                                        </strong> <br> Director at Shealing Public School


                                    </a>
                                </div>

                            </div>
                            <!-- /.blog-content -->
                        </article>
                        <!-- /.blog-post-two -->
                    </div>
                    <!-- /.col-lg-4 -->

                    <div class="col-lg-4">
                        <article class="blog-post-two color-two wow pixFadeRight" data-wow-delay="0.4s">
                            <div class="feature-image">
                                    <iframe width="100%" height="194" src="https://www.youtube.com/embed/2y7vFp_9pdc?si=wm2UDvne-kCWuc89" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                            </div>
                            <!-- /.feature-image -->
                            <div class="blog-content">
                                <div class="entry-meta">
                                    <!--<i class="fa fa-user-circle i-color"></i>-->
                                    <a href="#">
                                        <strong style="font-size: 18px;color: #5334cc;">
                                            KIOSK PAYMENT FACILTIY
                                        </strong> <br> 
                                    </a>
                                </div>
                            </div>
                            <!-- /.blog-content -->
                        </article>
                        <!-- /.blog-post-two -->
                    </div>
                    <!-- /.col-lg-4 -->
                   <!--  <div class="col-lg-12 text-center">
                        <a href="client-reviews.html" class="pix-btn btn-outline-two">See All Client Review Videos</a>
                    </div> -->



                </div>
            </div>
            <!-- /.container -->
        </section>
        <!-- /#blog-grid -->

        <!--===========================-->

        <!--===============================-->
        <!--=         Globally Presence   =-->
        <!--===============================-->
        
        <!-- /.Globally Presence -->
        <!--===========================-->
        <!--=========================-->
        <!--=        Footer         =-->
        <!--=========================-->
        <style>
.info i {
    color: #91909a;
    margin-right: 10px;
}
#footer.footer-two {
    background: #f8f7fc url('media/background/footer1349.png');
    background-size: cover;
    background-repeat: no-repeat;
    position: relative;
}
.bt_stick{
    position: -webkit-sticky; /* Safari */
  position: sticky !important;
  top: 0;
}

#footer .footer-nner {
    padding-top: 25px;
}

#footer .widget.footer-widget .widget-title {
    color: #2b2350;
    font-size: 20px;
    font-weight: 500;
    margin-bottom: 10px;
    border-bottom: 0;
    padding-bottom: 0;
}

#footer .footer-menu li:not(:last-child) {
    margin-bottom: -1px;
}

#footer .site-info {
    padding: 10px 0;
}

.info.phone {
    margin-bottom: 3px;
}

.foot-nav-btn {
    display: block;
    color: #212529;
    border-radius: 30px;
    font-size: 14px;
    z-index: 99999;
    width: 49%;
}
@media (max-width:991px){
    #footer.footer-two {background: #f8f7fc;}
    .main-menu{
        display: none;
    }
    .mean-container a.meanmenu-reveal{
        display: block !important;
    }
}

</style>
<!-- footer start -->

<!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            call: "+919893070156", // Call phone number
            whatsapp: "+919893070156", // WhatsApp number
            call_to_action: "Message us", // Call to action
            button_color: "#FF6550", // Color of button
            position: "left", // Position may be 'right' or 'left'
            order: "whatsapp,call", // Order of buttons
        };
        var proto = 'https:', host = "getbutton.io", url = proto + '//static.' + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->


<!-- Footer Area Start -->
	<footer class="footer">
		<div class="footer-main-area" data-background="images/footer-bg.png">
			<div class="container">
				<div class="row">
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
						<!--	<img src="images/footer_logo.png" alt="" class="mrb-20">-->
							<address class="mrb-25">
								<p class="text-light-gray">D-326 New Minal,
Near Gate No.5, Bhopal <br/>Madhya Pradesh, INDIA.</p>
								<div class="mrb-10"><a href="#" class="text-light-gray"><i class="fas fa-phone-alt mrr-10"></i>+91 98930-70156 </a></div>
								<div class="mrb-10"><a href="#" class="text-light-gray"><i class="fas fa-envelope mrr-10"></i>info@schoolerpindia.com </a></div>
								<div class="mrb-0"><a href="#" class="text-light-gray"><i class="fas fa-globe mrr-10"></i>www.schoolerpindia.com</a></div>
							</address>
							<ul class="social-list">
								<li><a href= "https://www.facebook.com/schoolerps/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
								<!-- <li><a href="#"><i class="fa-brands fa-linkedin-in" target="_blank"></i></a></li> -->
								<li><a href="https://www.instagram.com/school_erp_india/" target="_blank"><i class="fab fa-instagram"></i></a></li>
								<li><a href="https://www.youtube.com/@schoolerpindia" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30"> School Solutions </h5>
							<ul class="footer-widget-list">
	 <li > <a   href="admission-management.php"> Online Admission / Enrollment</a> </li>
 <li ><a   href="student-management.php">Student Management</a> </li>
 <li ><a   href="fees-management.php">Fees Management</a> </li>
<li ><a   href="progress-card.php">Progress Card</a> </li>
<li ><a   href="alumni_management.php">Alumni Management  </a> </li>
							</ul>
						</div>
					</div>
					<!--<div class="col-xl-2 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Services</h5>
							<ul class="footer-widget-list">
								<li><a href="#">Home</a></li>
								<li><a href="#">About</a></li>
								<li><a href="#">Team</a></li>
								<li><a href="#">Service</a></li>
								<li><a href="#">News</a></li>
								<li><a href="#">Policy</a></li>
								<li><a href="#">Contact</a></li>
							</ul>
						</div>
					</div>
					<div class="col-xl-4 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Newsletter</h5>
							<p class="text-light-gray">Seamlessly visualize quality intellectual capital without superior collaboration and idea sharing listically</p>
							<input type="text" class="form-control" placeholder="Enter Your Email">
							<a href="#" class="cs-btn-one btn-gradient-color btn-sm has-icon mrt-20"><i class="webexflaticon flaticon-send"></i>Submit Now</a>
						</div>
					</div>-->
					
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Integrations</h5>
							<ul class="footer-widget-list">
								<li > <a   href="attendance-machine.php"> Attendance Machine  </a> </li>
<li ><a   href="payment-gateway.php">Payment Gateway </a> </li>
<li ><a   href="fee-via-dynamic-qr-code.php">Fee Via Dynamic QR Code   </a> </li>
<li ><a   href="sms-gateway.php">SMS/Whatsup Gateway  </a> </li>
<li ><a   href="googlemeet-zoom.php">Google Meet/Zoom/Webex</a> </li>
							</ul>
						</div>
					</div>
					
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30"> Our Services</h5>
							<ul class="footer-widget-list">
							<li><a href="dynamic_website.php">Dynamic Website</a></li>
								 
<li ><a   href="student-app.php">Student App</a> </li>
<li ><a   href="teacher-app.php">Teacher App</a></li>
<li ><a   href="admin-app.php">Admin App</a></li>
<li ><a   href="student-web-login.php">Student Web Login</a></li>
							</ul>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<div class="footer-bottom-area">
			<div class="container">
				<div class="row">
					<div class="col-xl-12">
						<div class="text-center">
							<span class="text-light-gray" style="float: left;" >Copyright � 2021 by <a class="text-primary-color" target="_blank" href="#"> School ERp India</a> | All rights reserved    </span>
			
			 <a class="text-primary-color" style="float: right;color: white;"    href="privace-policy.php"> 
      Privacy Policy | Terms of Service | Refund & Cancellation 
 </a>
			 
						</div>
						
						
						
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer Area End -->
<!-- footer end -->

<!-- <a class="whatsapp_chat" href="https://api.whatsapp.com/send?phone=+919131951448&amp;text=I%20feel%20good%20about%20ER4U.%20Please%20help%20me%20to%20know%20more?" target="_blank">
        <div class="sg"><img src="whatsapp.svg"  width="42" height="42" alt="whatsapp"></div> Chat with us
    </a> -->
 
<!--<div id="myModal0000" class="modal m15---sec--timing fade">-->
<!--    <div class="modal-dialog">-->
<!--        <div class="modal-content">-->
<!--            <div class="modal-header">-->
                 
<!--                <button type="button" class="close" data-dismiss="modal">&times;</button>-->
<!--            </div>-->
<!--            <div class="modal-body">         -->
<!--                <img src="images/get1buy1.jpg" class="hidden-xs" />-->
<!--                <img src="images/get1buy1-xs.jpg" class="visible-xs" />-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->
<style>.m15---sec--timing{z-index: 9999;background: rgb(41 41 41 / 72%);}
.whatsapp_chat {display: flex;
    background: #fff;
    color: #162918;
    font-weight: 100;
    padding: 2px 1rem 2px 3px;
    margin: 0;
    align-items: center;
    justify-content: center;
    border-radius: 25px;
    position: fixed;
    left: 1rem;
    bottom: 2.5rem;
    line-height: 25px;
    -webkit-box-shadow: 0 0 10px -4px #333;
    -moz-box-shadow: 0 0 10px -4px #333;
    box-shadow: 0 0 10px -4px #333;
    z-index: 99; 
    font-weight: 600;}.sg img {width: 42px;}
</style>        <!-- /#footer -->
    </div>
    <!-- /#site -->
    <!-- Dependency Scripts -->
    <script src="dependencies/popper.js/popper.min.html"></script>
    <script src="dependencies/jquery/jquery.min.js"></script>
    <script src="dependencies/bootstrap/js/bootstrap.min.js"></script>
    <script src="dependencies/swiper/js/swiper.min.js"></script>
    <script src="dependencies/jquery.appear/jquery.appear.js"></script>
    <script src="dependencies/wow/js/wow.min.js"></script>
    <script src="dependencies/countUp.js/countUp.min.js"></script>
    <script src="dependencies/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="dependencies/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="dependencies/jquery.parallax-scroll/js/jquery.parallax-scroll.js"></script>
    <script src="dependencies/magnific-popup/js/jquery.magnific-popup.min.js"></script>
    <script src="assets/js/classie.js"></script>
    <script src="assets/js/selectFx.js"></script><script  src='js/lottie.js'></script>
                

        <script>
             var logoSvgData3 = {"v":"5.9.0","fr":30,"ip":0,"op":450,"w":300,"h":120,"nm":"er4u logo animation","ddd":0,"assets":[{"id":"dots.png","w":116,"h":116,"u":"images/","p":"dots.png","e":0},{"id":"final-logo.png","w":170,"h":77,"u":"images/","p":"final-logo.png","e":0},{"id":"e-circle.png","w":450,"h":450,"u":"images/","p":"e-circle.png","e":0},{"id":"comp_0","nm":"dots","fr":30,"layers":[{"ddd":0,"ind":1,"ty":2,"nm":"Layer 1","refId":"dots.png","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[57.857,57.857,0],"ix":2,"l":2},"a":{"a":0,"k":[57.718,57.718,0],"ix":1,"l":2},"s":{"a":0,"k":[100,100,100],"ix":6,"l":2}},"ao":0,"ip":0,"op":300,"st":0,"bm":0}]},{"id":"comp_1","nm":"final logo","fr":30,"layers":[{"ddd":0,"ind":1,"ty":2,"nm":"Layer 1","refId":"final-logo.png","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[83.67,38.713,0],"ix":2,"l":2},"a":{"a":0,"k":[84.947,38.5,0],"ix":1,"l":2},"s":{"a":0,"k":[100,100,100],"ix":6,"l":2}},"ao":0,"ip":0,"op":300,"st":0,"bm":0}]},{"id":"comp_2","nm":"e circle","fr":30,"layers":[{"ddd":0,"ind":1,"ty":2,"nm":"Layer 1","refId":"e-circle.png","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":1,"k":[{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":0,"s":[0]},{"t":105,"s":[-721]}],"ix":10},"p":{"a":0,"k":[225,225,0],"ix":2,"l":2},"a":{"a":0,"k":[224.592,224.592,0],"ix":1,"l":2},"s":{"a":0,"k":[100,100,100],"ix":6,"l":2}},"ao":0,"ip":0,"op":300,"st":0,"bm":0}]}],"layers":[{"ddd":0,"ind":1,"ty":0,"nm":"dots","refId":"comp_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":287,"s":[47.305,135.706,0],"to":[20.833,-8.333,0],"ti":[-19.333,43.775,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":300,"s":[172.305,85.706,0],"to":[19.333,-43.775,0],"ti":[36.667,1.442,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":310,"s":[132.305,17.055,0],"to":[-36.667,-1.442,0],"ti":[-3.195,-15.445,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":321,"s":[97.305,65.055,0],"to":[6.195,15.445,0],"ti":[-10.017,-0.593,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":324.25,"s":[124.274,91.93,0],"to":[25.333,1.5,0],"ti":[0,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":329,"s":[156.305,77.055,0],"to":[0,0,0],"ti":[0,0,0]},{"t":337,"s":[58.925,12.055,0]}],"ix":2,"l":2},"a":{"a":0,"k":[58,58,0],"ix":1,"l":2},"s":{"a":1,"k":[{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":287,"s":[3.543,3.543,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":301,"s":[129.543,129.543,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":303,"s":[49.543,49.543,100]},{"t":337,"s":[3.543,3.543,100]}],"ix":6,"l":2}},"ao":0,"w":116,"h":116,"ip":150,"op":450,"st":150,"bm":0},{"ddd":0,"ind":2,"ty":0,"nm":"dots","refId":"comp_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":250,"s":[74.18,-9.555,0],"to":[-19.667,9.833,0],"ti":[2.315,-23.002,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":266,"s":[34.18,55.445,0],"to":[-5.333,53,0],"ti":[-19.562,-9.686,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":275,"s":[72.18,138.445,0],"to":[51.5,25.5,0],"ti":[17.833,51.667,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":288,"s":[163.18,100.445,0],"to":[-5.804,-16.816,0],"ti":[0,0,0]},{"t":300,"s":[71.18,14.445,0]}],"ix":2,"l":2},"a":{"a":0,"k":[58,58,0],"ix":1,"l":2},"s":{"a":1,"k":[{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":250,"s":[5.3,5.3,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":261,"s":[7.638,7.638,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":270,"s":[29.638,29.638,100]},{"t":306,"s":[5.3,5.3,100]}],"ix":6,"l":2}},"ao":0,"w":116,"h":116,"ip":150,"op":450,"st":150,"bm":0},{"ddd":0,"ind":3,"ty":0,"nm":"dots","refId":"comp_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":227,"s":[207.75,-11.875,0],"to":[3.833,10.833,0],"ti":[12.931,-27.491,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":234,"s":[230.75,53.125,0],"to":[-12.931,27.491,0],"ti":[52.75,35.57,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":243,"s":[129.75,68.07,0],"to":[-52.75,-35.57,0],"ti":[19.75,29.07,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":266,"s":[11.75,67.57,0],"to":[-19.75,-29.07,0],"ti":[0,0,0]},{"t":272,"s":[64.8,26.1,0]}],"ix":2,"l":2},"a":{"a":0,"k":[58,58,0],"ix":1,"l":2},"s":{"a":1,"k":[{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":227,"s":[7.638,7.638,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":236,"s":[66.638,66.638,100]},{"t":272,"s":[7.6,7.6,100]}],"ix":6,"l":2}},"ao":0,"w":116,"h":116,"ip":150,"op":450,"st":150,"bm":0},{"ddd":0,"ind":4,"ty":0,"nm":"final logo","refId":"comp_1","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":179,"s":[408.5,65.5,0],"to":[-36.5,0,0],"ti":[36.5,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":182,"s":[189.5,65.5,0],"to":[0,0,0],"ti":[0,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":185,"s":[189.5,65.5,0],"to":[4.167,0,0],"ti":[-4.167,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":190,"s":[214.5,65.5,0],"to":[0,0,0],"ti":[0,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":198,"s":[214.5,65.5,0],"to":[-16.5,0,0],"ti":[16.5,0,0]},{"t":203,"s":[115.5,65.5,0]}],"ix":2,"l":2},"a":{"a":0,"k":[85.5,38.5,0],"ix":1,"l":2},"s":{"a":0,"k":[130.596,130.596,100],"ix":6,"l":2}},"ao":0,"w":171,"h":77,"ip":179,"op":479,"st":179,"bm":0},{"ddd":0,"ind":5,"ty":0,"nm":"e circle 2","refId":"comp_2","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":181,"s":[48,60.25,0],"to":[-1,0,0],"ti":[1,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":182,"s":[42,60.25,0],"to":[0,0,0],"ti":[0,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":198,"s":[42,60.25,0],"to":[-15.167,0,0],"ti":[15.167,0,0]},{"t":203,"s":[-49,60.25,0]}],"ix":2,"l":2},"a":{"a":0,"k":[225,225,0],"ix":1,"l":2},"s":{"a":0,"k":[21,21,100],"ix":6,"l":2}},"ao":0,"w":450,"h":450,"ip":171,"op":310,"st":50,"bm":0},{"ddd":0,"ind":6,"ty":0,"nm":"e circle","refId":"comp_2","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":1,"k":[{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":0,"s":[0]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":5,"s":[0]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":9,"s":[15]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":11,"s":[-20]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":19,"s":[15.778]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":20,"s":[0]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":21,"s":[-21]},{"t":30,"s":[0]}],"ix":10},"p":{"s":true,"x":{"a":1,"k":[{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":0,"s":[317]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":35,"s":[176.628]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":43,"s":[147]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":105,"s":[48]},{"t":170,"s":[48]}],"ix":3},"y":{"a":1,"k":[{"i":{"x":[0],"y":[1]},"o":{"x":[0.167],"y":[0.167]},"t":0,"s":[107.189]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[1],"y":[0]},"t":5,"s":[44.189]},{"i":{"x":[0],"y":[1]},"o":{"x":[0.167],"y":[0.167]},"t":10,"s":[107.189]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[1],"y":[0]},"t":15,"s":[62.189]},{"i":{"x":[0],"y":[1]},"o":{"x":[0.167],"y":[0.167]},"t":20,"s":[107.189]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[1],"y":[0]},"t":25,"s":[74.189]},{"i":{"x":[0],"y":[1]},"o":{"x":[0.167],"y":[0.167]},"t":30,"s":[107.189]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[1],"y":[0]},"t":35,"s":[87.189]},{"t":40,"s":[107.189]}],"ix":4}},"a":{"a":0,"k":[225,447.304,0],"ix":1,"l":2},"s":{"a":1,"k":[{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":0,"s":[7.872,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":7,"s":[7.872,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":9,"s":[7.9,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":10,"s":[7.872,4.8,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":11,"s":[7.9,7.9,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":12,"s":[7.872,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":17,"s":[7.872,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":19,"s":[7.9,7.9,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":20,"s":[7.872,4.8,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":21,"s":[7.9,7.9,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":23,"s":[7.872,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":85,"s":[7.872,7.872,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.167,0.167,0.167],"y":[0,0,0]},"t":105,"s":[7.872,7.872,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":113,"s":[7.872,7.872,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":115,"s":[11,11,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":117,"s":[7.872,7.872,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":125,"s":[7.9,7.9,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":127,"s":[16,16,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":129,"s":[7.872,7.872,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":144,"s":[7.9,7.9,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":146,"s":[21.9,21.9,100]},{"t":149,"s":[21,21,100]}],"ix":6,"l":2}},"ao":0,"w":450,"h":450,"ip":0,"op":171,"st":0,"bm":0}],"markers":[]};


            const animation3 = bodymovin.loadAnimation({container: document.getElementById('logo-bm5'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    animationData: logoSvgData3
}) 
        </script> 

        <script>
             var logoSvgData4 = {"v":"5.9.0","fr":30,"ip":0,"op":450,"w":300,"h":120,"nm":"er4u logo animation","ddd":0,"assets":[{"id":"dots.png","w":116,"h":116,"u":"images/","p":"dots.png","e":0},{"id":"final-logo.png","w":170,"h":77,"u":"images/","p":"final-logo.png","e":0},{"id":"e-circle.png","w":450,"h":450,"u":"images/","p":"e-circle.png","e":0},{"id":"comp_0","nm":"dots","fr":30,"layers":[{"ddd":0,"ind":1,"ty":2,"nm":"Layer 1","refId":"dots.png","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[57.857,57.857,0],"ix":2,"l":2},"a":{"a":0,"k":[57.718,57.718,0],"ix":1,"l":2},"s":{"a":0,"k":[100,100,100],"ix":6,"l":2}},"ao":0,"ip":0,"op":300,"st":0,"bm":0}]},{"id":"comp_1","nm":"final logo","fr":30,"layers":[{"ddd":0,"ind":1,"ty":2,"nm":"Layer 1","refId":"final-logo.png","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":0,"k":[83.67,38.713,0],"ix":2,"l":2},"a":{"a":0,"k":[84.947,38.5,0],"ix":1,"l":2},"s":{"a":0,"k":[100,100,100],"ix":6,"l":2}},"ao":0,"ip":0,"op":300,"st":0,"bm":0}]},{"id":"comp_2","nm":"e circle","fr":30,"layers":[{"ddd":0,"ind":1,"ty":2,"nm":"Layer 1","refId":"e-circle.png","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":1,"k":[{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":0,"s":[0]},{"t":105,"s":[-721]}],"ix":10},"p":{"a":0,"k":[225,225,0],"ix":2,"l":2},"a":{"a":0,"k":[224.592,224.592,0],"ix":1,"l":2},"s":{"a":0,"k":[100,100,100],"ix":6,"l":2}},"ao":0,"ip":0,"op":300,"st":0,"bm":0}]}],"layers":[{"ddd":0,"ind":1,"ty":0,"nm":"dots","refId":"comp_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":287,"s":[47.305,135.706,0],"to":[20.833,-8.333,0],"ti":[-19.333,43.775,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":300,"s":[172.305,85.706,0],"to":[19.333,-43.775,0],"ti":[36.667,1.442,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":310,"s":[132.305,17.055,0],"to":[-36.667,-1.442,0],"ti":[-3.195,-15.445,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":321,"s":[97.305,65.055,0],"to":[6.195,15.445,0],"ti":[-10.017,-0.593,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":324.25,"s":[124.274,91.93,0],"to":[25.333,1.5,0],"ti":[0,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":329,"s":[156.305,77.055,0],"to":[0,0,0],"ti":[0,0,0]},{"t":337,"s":[58.925,12.055,0]}],"ix":2,"l":2},"a":{"a":0,"k":[58,58,0],"ix":1,"l":2},"s":{"a":1,"k":[{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":287,"s":[3.543,3.543,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":301,"s":[129.543,129.543,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":303,"s":[49.543,49.543,100]},{"t":337,"s":[3.543,3.543,100]}],"ix":6,"l":2}},"ao":0,"w":116,"h":116,"ip":150,"op":450,"st":150,"bm":0},{"ddd":0,"ind":2,"ty":0,"nm":"dots","refId":"comp_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":250,"s":[74.18,-9.555,0],"to":[-19.667,9.833,0],"ti":[2.315,-23.002,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":266,"s":[34.18,55.445,0],"to":[-5.333,53,0],"ti":[-19.562,-9.686,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":275,"s":[72.18,138.445,0],"to":[51.5,25.5,0],"ti":[17.833,51.667,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":288,"s":[163.18,100.445,0],"to":[-5.804,-16.816,0],"ti":[0,0,0]},{"t":300,"s":[71.18,14.445,0]}],"ix":2,"l":2},"a":{"a":0,"k":[58,58,0],"ix":1,"l":2},"s":{"a":1,"k":[{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":250,"s":[5.3,5.3,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":261,"s":[7.638,7.638,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":270,"s":[29.638,29.638,100]},{"t":306,"s":[5.3,5.3,100]}],"ix":6,"l":2}},"ao":0,"w":116,"h":116,"ip":150,"op":450,"st":150,"bm":0},{"ddd":0,"ind":3,"ty":0,"nm":"dots","refId":"comp_0","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":227,"s":[207.75,-11.875,0],"to":[3.833,10.833,0],"ti":[12.931,-27.491,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":234,"s":[230.75,53.125,0],"to":[-12.931,27.491,0],"ti":[52.75,35.57,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":243,"s":[129.75,68.07,0],"to":[-52.75,-35.57,0],"ti":[19.75,29.07,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":266,"s":[11.75,67.57,0],"to":[-19.75,-29.07,0],"ti":[0,0,0]},{"t":272,"s":[64.8,26.1,0]}],"ix":2,"l":2},"a":{"a":0,"k":[58,58,0],"ix":1,"l":2},"s":{"a":1,"k":[{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":227,"s":[7.638,7.638,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":236,"s":[66.638,66.638,100]},{"t":272,"s":[7.6,7.6,100]}],"ix":6,"l":2}},"ao":0,"w":116,"h":116,"ip":150,"op":450,"st":150,"bm":0},{"ddd":0,"ind":4,"ty":0,"nm":"final logo","refId":"comp_1","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":179,"s":[408.5,65.5,0],"to":[-36.5,0,0],"ti":[36.5,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":182,"s":[189.5,65.5,0],"to":[0,0,0],"ti":[0,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":185,"s":[189.5,65.5,0],"to":[4.167,0,0],"ti":[-4.167,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":190,"s":[214.5,65.5,0],"to":[0,0,0],"ti":[0,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":198,"s":[214.5,65.5,0],"to":[-16.5,0,0],"ti":[16.5,0,0]},{"t":203,"s":[115.5,65.5,0]}],"ix":2,"l":2},"a":{"a":0,"k":[85.5,38.5,0],"ix":1,"l":2},"s":{"a":0,"k":[130.596,130.596,100],"ix":6,"l":2}},"ao":0,"w":171,"h":77,"ip":179,"op":479,"st":179,"bm":0},{"ddd":0,"ind":5,"ty":0,"nm":"e circle 2","refId":"comp_2","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":0,"k":0,"ix":10},"p":{"a":1,"k":[{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":181,"s":[48,60.25,0],"to":[-1,0,0],"ti":[1,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":182,"s":[42,60.25,0],"to":[0,0,0],"ti":[0,0,0]},{"i":{"x":0.833,"y":0.833},"o":{"x":0.167,"y":0.167},"t":198,"s":[42,60.25,0],"to":[-15.167,0,0],"ti":[15.167,0,0]},{"t":203,"s":[-49,60.25,0]}],"ix":2,"l":2},"a":{"a":0,"k":[225,225,0],"ix":1,"l":2},"s":{"a":0,"k":[21,21,100],"ix":6,"l":2}},"ao":0,"w":450,"h":450,"ip":171,"op":310,"st":50,"bm":0},{"ddd":0,"ind":6,"ty":0,"nm":"e circle","refId":"comp_2","sr":1,"ks":{"o":{"a":0,"k":100,"ix":11},"r":{"a":1,"k":[{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":0,"s":[0]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":5,"s":[0]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":9,"s":[15]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":11,"s":[-20]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":19,"s":[15.778]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":20,"s":[0]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":21,"s":[-21]},{"t":30,"s":[0]}],"ix":10},"p":{"s":true,"x":{"a":1,"k":[{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":0,"s":[317]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":35,"s":[176.628]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":43,"s":[147]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[0.167],"y":[0.167]},"t":105,"s":[48]},{"t":170,"s":[48]}],"ix":3},"y":{"a":1,"k":[{"i":{"x":[0],"y":[1]},"o":{"x":[0.167],"y":[0.167]},"t":0,"s":[107.189]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[1],"y":[0]},"t":5,"s":[44.189]},{"i":{"x":[0],"y":[1]},"o":{"x":[0.167],"y":[0.167]},"t":10,"s":[107.189]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[1],"y":[0]},"t":15,"s":[62.189]},{"i":{"x":[0],"y":[1]},"o":{"x":[0.167],"y":[0.167]},"t":20,"s":[107.189]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[1],"y":[0]},"t":25,"s":[74.189]},{"i":{"x":[0],"y":[1]},"o":{"x":[0.167],"y":[0.167]},"t":30,"s":[107.189]},{"i":{"x":[0.833],"y":[0.833]},"o":{"x":[1],"y":[0]},"t":35,"s":[87.189]},{"t":40,"s":[107.189]}],"ix":4}},"a":{"a":0,"k":[225,447.304,0],"ix":1,"l":2},"s":{"a":1,"k":[{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":0,"s":[7.872,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":7,"s":[7.872,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":9,"s":[7.9,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":10,"s":[7.872,4.8,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":11,"s":[7.9,7.9,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":12,"s":[7.872,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":17,"s":[7.872,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":19,"s":[7.9,7.9,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":20,"s":[7.872,4.8,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":21,"s":[7.9,7.9,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":23,"s":[7.872,7.872,100]},{"i":{"x":[0.833,0.833,0.833],"y":[0.833,0.833,0.833]},"o":{"x":[0.167,0.167,0.167],"y":[0.167,0.167,0.167]},"t":85,"s":[7.872,7.872,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.167,0.167,0.167],"y":[0,0,0]},"t":105,"s":[7.872,7.872,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":113,"s":[7.872,7.872,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":115,"s":[11,11,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":117,"s":[7.872,7.872,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":125,"s":[7.9,7.9,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":127,"s":[16,16,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":129,"s":[7.872,7.872,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":144,"s":[7.9,7.9,100]},{"i":{"x":[0.667,0.667,0.667],"y":[1,1,1]},"o":{"x":[0.333,0.333,0.333],"y":[0,0,0]},"t":146,"s":[21.9,21.9,100]},{"t":149,"s":[21,21,100]}],"ix":6,"l":2}},"ao":0,"w":450,"h":450,"ip":0,"op":171,"st":0,"bm":0}],"markers":[]};


             
const animation4 = bodymovin.loadAnimation({container: document.getElementById('logo-bm6'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    animationData: logoSvgData4
})
        </script>     <script>
    (function() {
        [].slice.call(document.querySelectorAll('select.cs-select')).forEach(function(el) {
            new SelectFx(el);
        });
    })();
    </script>
    <!-- Site Scripts -->
    <script src="assets/js/header.js"></script>
    <script src="assets/js/app.js"></script>

    <script>
    $(function() {
        setTimeout(function() {
            $("ul.pixsass-isotope-filter li a[data-id='23']").trigger("click");
        }, 100);
        setInterval(function() {
            var n = $('ul.pixsass-isotope-filter li.current').index() + 1;
            var len = $('ul.pixsass-isotope-filter li').length;
            if (n >= len) {
                n = 0;
            }
            tswap(n);
        }, 2000);
    });

    function tswap(n) {
        if ($("ul.pixsass-isotope-filter li").eq(n).children("a").eq("0").attr("data-filter") != undefined) {
            $("ul.pixsass-isotope-filter li").removeClass("current");
            $("ul.pixsass-isotope-filter li").eq(n).addClass("current").children("a").trigger("click");
        } else {
            n++;
            var len = $('ul.pixsass-isotope-filter li').length;
            if (n >= len) {
                n = 0;
            }
            tswap(n);
        }
    }
    $(document).ready(function() {
        $('ul.pixsass-isotope-filter li a').on('click', function() {
            $("ul.pixsass-isotope-filter li a").children("div.place_name").addClass("hide");
            $(this).children("div.place_name").removeClass('hide');
            var statecode = $(this).attr("data-id");
            $("path.st0").css({
                "fill": "#E8E8E8"
            });
            $("path.state_" + statecode).css({
                "fill": "#fcb415"
            });
        });
    })
    //$grid.isotope({ filter: '.metal:not(*)' });




    $(document).on('click', '.cs-options ul li ', function(e) {
        var vdata = ($(this).attr('data-value'));
        $("div.itemrow").addClass("d-none").removeClass('d-block');
        $("div#" + vdata).removeClass("d-none").addClass("d-block");

    });

    $(function() {
        $(".cs-options ul li").eq(1).trigger("click");
        $(".cs-select").removeClass("cs-active");
    });
    </script>
        <script>
            $(document).ready(function(){
                setTimeout(function(){ $("#myModal").modal('show'); }, 15000);

            });
        </script>
</body>


<!-- Mirrored from www.er4u.in/client.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 01 Nov 2023 11:48:47 GMT -->
</html>