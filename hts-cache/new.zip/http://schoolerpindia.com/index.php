<!DOCTYPE html>
<html lang="en">
<head>
	 <title>School ERP India Software in India Is The Best ERP Software, School Management Software, ERP For Schools in India, India by School ERP, School Software!</title>
<meta name="description" content="School ERP India is an online educational solution for all educational organization including engineering college, medical college, technical college, management college. School ERP is the best software for Schools, Colleges, Engineering Colleges, Management Colleges, Medical Colleges, Degree College, best online educational software for college in india. School ERP College ERP provides modules like Student Management, admission module, fee module, Timetable Management, Director and Principal Module, Library Management, stock module, HR Module, Transport Module, Hostel Module" />
<meta name="keywords" content="School ERP, ERP Solutions Education, ERP for School, Kids School ERP Software, School Management, School ERP System, School Management Software, School ERP Software in India, ERP School" />
<meta name="author" content="School ERP, vaibhav@schoolerpindia.com">
<meta name="revisit-after" content="7 days">
<meta name="og:title" content="School ERP Software in India Is The Best ERP Software, School Management Software, ERP For Schools in India, India by School ERP, School Software!"/>
<meta name="og:type" content="School ERP India"/>
<meta name="og:url" content="http://schoolerpindia.com/index.php"/>
<meta name="og:image" content="https://schoolerpindia.com/images/bg/1.jpeg"/>
<meta name="og:site_name" content="SchoolERPIndia"/>
<meta name="og:description" content="School ERP India is an online educational solution for all educational organization including engineering college, medical college, technical college, management college"/>
<meta name="og:email" content="vaibhav@schoolerpindia.com"/>
<meta name="og:phone_number" content="+91 9893070156"/>


<meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">


<meta name="facebook-domain-verification" content="9izle3q4o4hajikcrolaty9ogahzq7" />
<script async src="https://cdn.ampproject.org/v0.js"></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-130825364-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-130825364-1');
</script>
	<link href="images/favicon.png" rel="shortcut icon" type="image/png">
	<!-- Main Stylesheet -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
		<link rel="stylesheet" href="css/slide.css">
    <link rel="stylesheet" href="css/animate.css">
	<!--<link rel="stylesheet" href="css/bootstrap.min.css">-->
	<link rel="stylesheet" href="css/custom-animation.css">
	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/meanmenu.min.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
<link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.2.1/owl.carousel.js"></script>
</head>

<body>
	<!-- Preloader Start -->
	<!--<div class="preloader"></div>-->
	<!-- Preloader End -->
	<!-- header Start -->
	 	<header class="header-style-two" style="height: 98px ;">
		<div class="header-wrapper">
			<div class="header-top-area bg-gradient-color d-none d-lg-block">
				<div class="container">
					<div class="row">
						<div class="col-lg-6 header-top-left-part">
						
							<marquee><span class="address"><i class="webexflaticon flaticon-phone"></i> +91-9893070156, +91-6269048888 </span><span class="phone"><i class="webexflaticon flaticon-send"></i> info@schoolerpindia.com </span></marquee>
							<!-- somu28/10/2023 -->
						</div>
						<div class="col-lg-6 header-top-right-part text-right">
							
						<ul class="social-links">
                                	<li><a href="https://www.facebook.com/schoolerps"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="https://www.youtube.com/channel/UCglZwT9PYeAPTKg6rUhQiFA"><i class="fab fa-youtube"></i></a></li>
							</ul>
							
						<div class="language">
								<a href="school-erp-demo.php"><i class="webexflaticon flaticon-man"></i> Free Demo</a>								
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="bt_blank_nav"></div>
			<div class="header-navigation-area two-layers-header header-middlee bt_stick bt_sticky ">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<a class="navbar-brand logo f-left mrt-0 mrt-md-0" href="index.php"><!-- somu28/10/2023 -->
								<img id="logo-image" class="img-center" src="images/logo.png" alt="">
							</a>
							<div class="mobile-menu-right"></div>
							<div class="header-searchbox-style-two d-none d-xl-block">
								<div class="side-panel side-panel-trigger text-right d-none d-lg-block">
									<span class="bar1"></span>
									<span class="bar2"></span>
									<span class="bar3"></span>
								</div>
								<div class="show-searchbox">
									<a href="#"><i class="webex-icon-Search"></i></a>
								</div>
								<div class="toggle-searchbox">
									<form action="#" id="searchform-all" method="get">
										<div>
											<input type="text" id="s" class="form-control" placeholder="Search...">
											<div class="input-box">
												<input type="submit" value="" id="searchsubmit"><i class="fas fa-search"></i>
											</div>
										</div>
									</form>
								</div>
							</div>
							<div class="side-panel-content">
								<div class="close-icon">
									<button><i class="webex-icon-cross"></i></button>
								</div>
								<div class="side-panel-logo mrb-30">
									<a href="index.php">
										<img src="images/logo.png" alt="" />
									</a>
								</div>
								<div class="side-info mrb-30">
									<div class="side-panel-element mrb-25">
										<h4 class="mrb-10">Office Address</h4>
										<ul class="list-items">
											<li><span class="fa fa-map-marker-alt mrr-10 text-primary-color"></span>D-218 Old Minal, J.K. Road Bhopal Madhya Pradesh, INDIA.</li>
											<li><span class="fas fa-envelope mrr-10 text-primary-color"></span>info@schoolerpindia.com</li>
											<li><span class="fas fa-phone-alt mrr-10 text-primary-color"></span>+91 7987535570 </li>
										</ul>
									</div>
									
									<body>
<header>
      <div id="carousel" class="carousel slide" data-ride="carousel" style="">
        <ol class="carousel-indicators" style="display: none;">
          <li data-target="#carousel" data-slide-to="0" class="active"></li>
          <li data-target="#carousel" data-slide-to="1"></li>
          <li data-target="#carousel" data-slide-to="2"></li>
        </ol>

        <div class="carousel-inner" role="listbox">
		
		 <!-- <div class="carousel-item active" data-background="images/bg/erp_banner.png" style="background-image: url('images/bg/erp_banner.jpg'); background-size: contain;">somu 28/10/2023-->
      <!-- <div class="carousel-item active" data-background="images/bg/erp_banner.png" style="background-image: url('images/bg/erp_banner.jpg'); background-size: contain;"> -->
        <div class="carousel-item active" data-background="images/bg/erp_banner2.gif" style="background-image: url('images/bg/erp_banner2.gif'); background-size: contain;">
            <div class="caption">
              <button class="book_demobtn" style=""><a href="https://api.whatsapp.com/send/?phone=916269028888&text=I feel good about SCHOOL ERP INDIA. Please help me to%C2%A0know%C2%A0more?" target="_blank"style="color:transparent;">Book Demo</a></button>
             <!-- <h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
            </div>
          </div>

           
          <div class="carousel-item" style="background-image: url('images/bg/erp_banner4.webp'); background-size: contain;">
            <div class="caption">
             <!--  <h1 style="color:black">Create and share your whatever</h1>
              <h2 style="color:black">Make it easy for you to do whatever this thing does.</h2> -->
              <!-- <button><a href="#">Book Demo</a></button>--> <!-- somu 28/10/2023 --> 
              <button class="book_demobtn"style="">
   
    
    <a href="https://api.whatsapp.com/send/?phone=916269028888&text=I feel good about SCHOOL ERP INDIA. Please help me to%C2%A0know%C2%A0more?" target="_blank"style="color:transparent;">Book Demo</a></button>
            </div>
          </div>
          <style>
            .book_demobtn{
              position:relative;
    left: -443px;
    bottom: -138px;
    font-size: 35px;
    font-weight: 800;
    pointer:cursor;
    color: white !important;
    background: none;
            }

      @media(max-width:600px){
        .book_demobtn{
          position:absolute !important;
          left: -73px !important;
          bottom: -25px !important;
        }
      }
    </style>
		      
<!-- somu 28/10/2023 -->
	     <!--  <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
           <!--  </div>
          </div>

          <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
          <!--   </div>
          </div>

          <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
            <!-- </div>
          </div> -->
 


        </div>
        
        <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
          <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
          <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
          <span class="sr-only">Next</span>
        </a>

      </div>
    </header>
    <style >
       @media (max-width: 740px){
   .carousel-inner {
    padding-top: 52.25%;
    display: block;
    content: "";
}
}
    </style>
</body>									
								</div>
								<h4 class="mrb-15">Social List</h4>
								<ul class="social-list">
									<li><a href="#"><i class="fab fa-facebook"></i></a></li>
									<li><a href="#"><i class="fab fa-twitter"></i></a></li>
									<li><a href="#"><i class="fab fa-instagram"></i></a></li>
									<li><a href="#"><i class="fab fa-google-plus"></i></a></li>
								</ul>
							</div>
							<div class="main-menu f-right fff">
								<nav id="mobile-menu-right">
									<ul>
									<li><a href="index.php">Home</a></li>
										   <li class="has-sub">
											<a href="#">Modules/Services</a>
											<ul class="sub-menu">
<li><a href="admission-management.php">Admission Management</a></li>
<li><a href="student-management.php">Student Management</a></li>
<li><a href="fees-management.php">Fee Management</a></li>
<li><a href="attendance-management.php">Attendance Management</a></li>
<li><a href="academics-management.php">Academic Management</a></li>
<li><a href="exam-management.php">Examination Management</a></li>
<li><a href="online_exam.php">Online Examination</a></li>
<li><a href="hr-management.php">HR  Management</a></li>
<li><a href="learning_management.php">Learning Management</a></li>
<li><a href="inventory_management.php">Inventory Management</a></li>
<li><a href="transport-management.php">Transport Management</a></li>
<li><a href="alumni_management.php"> Alumni management</a></li>
<li><a href="followup_management.php">Followup Management</a></li>
</ul>
										</li> 
										
<li class="has-sub">
<a href="#">Integrations</a>
	<ul class="sub-menu">
<li><a href="attendance-machine.php">Attendance Machine</a></li>
<!--<li><a href="bus-tracking.php">Bus Tracking</a></li>-->
<li><a href="payment-gateway.php">Payment Gateway</a></li>
<li><a href="sms-gateway.php">SMS/Whatsup Gateway</a></li>
<li><a href="rfid-card.php">RFID Card</a></li>
<li><a href="bulk-email.php">Bulk Email</a></li>
<li><a href="fee-via-dynamic-qr-code.php">Fee Via Dynamic QR Code</a></li>
<li><a href="googlemeet-zoom.php">Google Meet/Zoom/Webex </a></li>
</ul>									
										
										
										
										</li>
																			
										<li><a href="dynamic_website.php">Website</a></li>
										<li><a href="mobileapp.php">Mobile App</a></li>
											<li><a href="pricing.php"> Pricing  </a></li>
									
										<!-- <li><a href="demo-videos.php"> Demo Videos </a></li> -->
										<li><a href="partners.php"> Partners </a></li>
										
										<li><a href="school-erp-demo.php">  Demo  </a></li>
										<li><a href="client.php"> Clients  </a></li>
									
										 
										
										<!--<li><a href="page-pricing.php">Pricing</a></li>
										
										<li class="has-sub right-view">
											<a href="#">Clients</a>
											<ul class="sub-menu">
												<li><a href="page-news.php">News Classic</a></li>
												<li><a href="page-news-left-sidebar.php">News Left Sidebar</a></li>
												<li><a href="page-news-right-sidebar.php">News Right Sidebar</a></li>
												<li><a href="page-single-news.php">Single News</a></li>
											</ul>
										</li>-->
										<li><a href="contact-us.php">Contact Us</a></li>
									</ul>
								</nav>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>		
	<!-- header End -->
	
	<!-- Home Slider Start -->
		<body>
<header>
      <div id="carousel" class="carousel slide" data-ride="carousel" style="">
        <ol class="carousel-indicators" style="display: none;">
          <li data-target="#carousel" data-slide-to="0" class="active"></li>
          <li data-target="#carousel" data-slide-to="1"></li>
          <li data-target="#carousel" data-slide-to="2"></li>
        </ol>

        <div class="carousel-inner" role="listbox">
		
		 <!-- <div class="carousel-item active" data-background="images/bg/erp_banner.png" style="background-image: url('images/bg/erp_banner.jpg'); background-size: contain;">somu 28/10/2023-->
      <!-- <div class="carousel-item active" data-background="images/bg/erp_banner.png" style="background-image: url('images/bg/erp_banner.jpg'); background-size: contain;"> -->
        <div class="carousel-item active" data-background="images/bg/erp_banner2.gif" style="background-image: url('images/bg/erp_banner2.gif'); background-size: contain;">
            <div class="caption">
              <button class="book_demobtn" style=""><a href="https://api.whatsapp.com/send/?phone=916269028888&text=I feel good about SCHOOL ERP INDIA. Please help me to%C2%A0know%C2%A0more?" target="_blank"style="color:transparent;">Book Demo</a></button>
             <!-- <h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
            </div>
          </div>

           
          <div class="carousel-item" style="background-image: url('images/bg/erp_banner4.webp'); background-size: contain;">
            <div class="caption">
             <!--  <h1 style="color:black">Create and share your whatever</h1>
              <h2 style="color:black">Make it easy for you to do whatever this thing does.</h2> -->
              <!-- <button><a href="#">Book Demo</a></button>--> <!-- somu 28/10/2023 --> 
              <button class="book_demobtn"style="">
   
    
    <a href="https://api.whatsapp.com/send/?phone=916269028888&text=I feel good about SCHOOL ERP INDIA. Please help me to%C2%A0know%C2%A0more?" target="_blank"style="color:transparent;">Book Demo</a></button>
            </div>
          </div>
          <style>
            .book_demobtn{
              position:relative;
    left: -443px;
    bottom: -138px;
    font-size: 35px;
    font-weight: 800;
    pointer:cursor;
    color: white !important;
    background: none;
            }

      @media(max-width:600px){
        .book_demobtn{
          position:absolute !important;
          left: -73px !important;
          bottom: -25px !important;
        }
      }
    </style>
		      
<!-- somu 28/10/2023 -->
	     <!--  <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
           <!--  </div>
          </div>

          <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
          <!--   </div>
          </div>

          <div class="carousel-item" style="background-image: url('images/bg/1.jpeg'); background-size: contain;">
            <div class="caption"> -->
              <!--<h1>Create and share your whatever</h1>
              <h2>Make it easy for you to do whatever this thing does.</h2>-->
            <!-- </div>
          </div> -->
 


        </div>
        
        <a class="carousel-control-prev" href="#carousel" role="button" data-slide="prev">
          <!-- <span class="carousel-control-prev-icon" aria-hidden="true"></span> -->
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carousel" role="button" data-slide="next">
          <!-- <span class="carousel-control-next-icon" aria-hidden="true"></span> -->
          <span class="sr-only">Next</span>
        </a>

      </div>
    </header>
    <style >
       @media (max-width: 740px){
   .carousel-inner {
    padding-top: 52.25%;
    display: block;
    content: "";
}
}
    </style>
</body>	<!-- Home Slider End -->
	 
	 <!-- <section class="feature-section pdt-30   bg-silver-light bg-no-repeat" data-background="images/bg/abs-bg5.webp" style="background-image: url(&quot;images/bg/abs-bg5.webp&quot;);"> -->
		<!-- <div class="container"> -->


 <!-- somu 28/10/2023 -->
	<!-- 		<div class="row">

   <div class="col-md-12 col-xl-12 text-center">             
<h2> Latest Softwares Videos </h2> <br><br>
</div>

				<div class="col-md-6 col-xl-3 text-center">
				
					 <iframe height:"200px"="" allowfullscreen="" src="https://www.youtube.com/embed/XTKBrNtWhYA" width="100%" frameborder="0"></iframe>
                    <h4 class="title">How to Create Login Account in School Software </h4>
                              
							 
							 <a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>
							 
 				</div>


				<div class="col-md-6 col-xl-3 text-center">
				
					 <iframe height:"200px"="" allowfullscreen="" src="https://www.youtube.com/embed/fE9FSG7sUUA" width="100%" frameborder="0"></iframe>
                    <h4 class="title">FEE MASTER MODULE IN SCHOOL ERP INDIA </h4> 
							 <a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>
			  </div>


				<div class="col-md-6 col-xl-3 text-center">
				
					 <iframe height:"200px"="" allowfullscreen="" src="https://www.youtube.com/embed/Jummo6Oxte8" width="100%" frameborder="0"></iframe>
                    <h4 class="title">Transport Modules in School Software </h4> 
							 <a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>
			  </div>


				<div class="col-md-6 col-xl-3 text-center">
				
					 <iframe height:"200px"="" allowfullscreen="" src="https://www.youtube.com/embed/wX-NThlB2OM" width="100%" frameborder="0"></iframe>
                <h4 class="title">Enquiry Management in School ERP India </h4> 
							 <a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>
			  </div>


				<div class="col-md-6 col-xl-3 text-center">
				
					 <iframe height:"200px"="" allowfullscreen="" src="https://www.youtube.com/embed/mxKwMInw0vo" width="100%" frameborder="0"></iframe>
                  <h4 class="title">Student Master Module in SCHOOL ERP INDIA </h4> 
							 <a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>
			  </div>


				<div class="col-md-6 col-xl-3 text-center">
				
					 <iframe height:"200px"="" allowfullscreen="" src="https://www.youtube.com/embed/8ngNB8rGF7o" width="100%" frameborder="0"></iframe>
               <h4 class="title">STUDENT APP - Syllabus / Gallery / Video /Fees </h4> 
							 <a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>
			  </div>


				<div class="col-md-6 col-xl-3 text-center">
				
					 <iframe height:"200px"="" allowfullscreen="" src="https://www.youtube.com/embed/vjgs_AZXiFU" width="100%" frameborder="0"></iframe>
                 <h4 class="title">Leave Management Module in SCHOOL ERP INDIA </h4> 
							 <a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>
			  </div>


				<div class="col-md-6 col-xl-3 text-center">
				
					 <iframe height:"200px"="" allowfullscreen="" src="https://www.youtube.com/embed/hpy4n9w-FzE" width="100%" frameborder="0"></iframe>
                    <h4 class="title">Attendance Module in School ERP INDIA </h4> 
							 <a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>
			  </div>


  

			
			</div>
		</div>
	</section> -->

	<!-- intro section start --> <!-- somu 31/10/2023 -->
	 <section id="tw-service" class="tw-service bg-lightgray">
  <div class="container">
    <div class="row text-center">
      <div class="col section-heading wow fadeInDown">
        <h1 class="" style="padding:30px 0px;">Our </span> Features</h1>
        </div>
    </div>
    <div class="row">
      <div class="tab core_features" id="gallery">
        <div class="tab-nav j-tab-nav core_features_tab"> 
          <a href="javascript:void(0);" class="academics current"> <span><img src="images/academic.png" height="70px" width="70px"><br></span> <span class="txt">Academics Management</span></a> <a href="javascript:void(0);" class="student"> <span><img src="images/student.png" height="70px" width="70px"><br></span> <span class="txt">Student Management </span></a> <a href="javascript:void(0);" class="transportation"> <span ><img src="images/transprot.png" height="70px" width="69.8px"><br></span> <span class="txt">Transportation/Library/Hostel</span></a> <a href="javascript:void(0);" class="exam"> <span><img src="images/exam-management.png" height="70px" width="70px"><br></span> <span class="txt">Exam Management</span></a> <a href="javascript:void(0);" class="payroll"> <span><img src="images/finance.png" height="70px" width="70px"><br></span> <span class="txt">HR &amp; Finance Management</span></a>
          <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
        <div class="tab-con">
          <div class="j-tab-con">
            <div class="tab-con-item" style="display: block;">
              <div class="col-lg-4 col-md-12 view-clo"style="">
                <div class="view view-first"style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/CLASS_SECTION.png" alt="academic erp software India" title="Academic Management ERP Systems India" width="84" height="83" style="height:70px; width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Class and Section</div>
                  <div class="text-details">A dashboard showcasing various classes and sections enhances productivity while minimizing power consumption.</div>
                  <div class="mask non">
                    <h2>Class and Section</h2>
                    <div class="titel-line"></div>
                    <p>A dashboard showcasing various classes and sections enhances productivity while minimizing power consumption.</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/SYLLABUS.png" alt="school administration management system India" width="70" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Syllabus</div>
                  <div class="text-details">Effortlessly assign subjects to teachers based on class, with administrators easily managing class-specific subject lists.
</div>
                  <div class="mask non">
                    <h2>Syllabus</h2>
                    <div class="titel-line"></div>
                    <p>Effortlessly assign subjects to teachers based on class, with administrators easily managing class-specific subject lists.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/LESSON PLANNING.png" alt="educational erp modules India" width="70" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Lesson Planning</div>
                  <div class="text-details">Teachers use a mobile app for student attendance, and parents can access daily attendance reports.
</div>
                  <div class="mask non">
                    <h2>Lesson Planning</h2>
                    <div class="titel-line"></div>
                    <p>Teachers use a mobile app for student attendance, and parents can access daily attendance reports.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/ATTENDANCE.png" alt="school attendance system software India" width="70" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Attendance Management</div>
                  <div class="text-details">Teachers use a mobile app to record student attendance, and parents can view daily attendance reports.
</div>
                  <div class="mask non">
                    <h2>Attendance Management</h2>
                    <div class="titel-line"></div>
                    <p>Teachers use a mobile app to record student attendance, and parents can view daily attendance reports.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/ADMISSION.png" alt="school administration management system India" width="55" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Admission Management</div>
                  <div class="text-details">Efficiently handle student inquiries, streamline admission procedures, and register new students seamlessly.
</div>
                  <div class="mask non">
                    <h2>Admission Management</h2>
                    <div class="titel-line"></div>
                    <p>Efficiently handle student inquiries, streamline admission procedures, and register new students seamlessly.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/CIRCULAR.png" alt="school billing software India" width="65" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Circular</div>
                  <div class="text-details">We will update the future information display of Circular. Parents can see the mobile app Circular with notifications.
</div>
                  <div class="mask non">
                    <h2>Circular</h2>
                    <div class="titel-line"></div>
                    <p>We'll keep parents informed with future updates through the Circular display on the mobile app, accompanied by notifications.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/CERTIFICATE.png" alt="school management system access database India" width="70" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Certificate</div>
                  <div class="text-details">Our system facilitates the management and generation of TC and CC for seamless certification processes.
</div>
                  <div class="mask non">
                    <h2>Certificate</h2>
                    <div class="titel-line"></div>
                    <p>Our system facilitates the management and generation of TC and CC for seamless certification processes.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/DEPARTMENT.png" alt="school portal management system India" width="70" height="70" style="height:70px; width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Department</div>
                  <div class="text-details">Explore the Array of Departments Managed by Our School's ERP.
</div>
                  <div class="mask non">
                    <h2>Department</h2>
                    <div class="titel-line"></div>
                    <p>Explore the Array of Departments Managed by Our School's ERP.</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/DASHBOARD.png" alt="resource planning solution India" width="80" height="80"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Customizable Dashboard</div>
                  <div class="text-details">The Dashboard offers a quick overview of overall student and teaching staff performance, with detailed data accessible for deeper insights.
</div>
                  <div class="mask non">
                    <h2>Customizable Dashboard</h2>
                    <div class="titel-line"></div>
                    <p>The Dashboard offers a quick overview of overall student and teaching staff performance, with detailed data accessible for deeper insights.
</p>
                     </div>
                </div>
              </div>
            </div>
            <div class="tab-con-item" style="display: none;">
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/NOTES.png" alt="school management system access database" width="75" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Assignment and Notes</div>
                  <div class="text-details">Teachers can utilize a mobile application to share assignments and notes, as well as review and assess student work.
</div>
                  <div class="mask non">
                    <h2>Assignment and Notes</h2>
                    <div class="titel-line"></div>
                    <p>Teachers can utilize a mobile application to share assignments and notes, as well as review and assess student work.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/EVENT.png" alt="complete school management software India" width="70" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Event  Management</div>
                  <div class="text-details">We create and organize large-scale events, including festivals and sporting events.
</div>
                  <div class="mask non">
                    <h2>Event  Management</h2>
                    <div class="titel-line"></div>
                    <p>We create and organize large-scale events, including festivals and sporting events.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/TASK.png" alt="Task Management ERP System India" width="63" height="60"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Task Management</div>
                  <div class="text-details">Instructors and principals can assign tasks to specific topics, prioritizing them based on importance.
</div>
                  <div class="mask non">
                    <h2>Task Management</h2>
                    <div class="titel-line"></div>
                    <p>Instructors and principals can assign tasks to specific topics, prioritizing them based on importance.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/TIME TABLE.png" alt="Time Table ERP Software India" width="70" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Time Table</div>
                  <div class="text-details">Our module makes it simple to create, update, and monitor subject timetables, meal timetables, and exam timetables.
</div>
                  <div class="mask non">
                    <h2>Time Table</h2>
                    <div class="titel-line"></div>
                    <p>Our module makes it simple to create, update, and monitor subject timetables, meal timetables, and exam timetables.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/store.png" alt="Canteen ERP Management System India" width="70" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Store Management</div>
                  <div class="text-details">Our module is primarily utilized to track the tasks completed by both teachers and students.
</div>
                  <div class="mask non">
                    <h2>Store Management</h2>
                    <div class="titel-line"></div>
                    <p>Our module is primarily utilized to track the tasks completed by both teachers and students.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/SCHOLARSHIP.png" alt="Education Management ERP Software India" width="70" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Scholarship</div>
                  <div class="text-details">Our module depicts academic study or achievement; high-level learning, and a gift or payment offered to help a student further their education.
</div>
                  <div class="mask non">
                    <h2>Scholarship</h2>
                    <div class="titel-line"></div>
                    <p>Our module illustrates academic study, high-level learning, and the provision of gifts or payments to support a student in advancing their education.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/STUDENT TRACKING.png" alt="Scholarship ERP Software India" width="58" height="60"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Student Tracking</div>
                  <div class="text-details">Teachers, parents, and administrators can all check the status of a student's ID card.
</div>
                  <div class="mask non">
                    <h2>Student Tracking</h2>
                    <div class="titel-line"></div>
                    <p>Teachers, parents, and administrators can all check the status of a student's ID card.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/NOTIFICATION.png" alt="Student Tracking ERP System India" width="70" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Email &amp; Notification &amp; Chat</div>

                  <div class="text-details">Our module offers email and notification features for seamless communication.
</div>
                  <div class="mask non">
                    <h2>Email &amp; Notification &amp; Chat</h2>
                    <div class="titel-line"></div>
                    <p>Our module offers email and notification features for seamless communication.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/LEAVE MANAGEMENT.png" alt="" width="70" height="70"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Leave Management</div>
                  <div class="text-details">Our module efficiently handles half-time, sick, and casual leave, along with holiday management.
</div>
                  <div class="mask non">
                    <h2>Leave Management</h2>
                    <div class="titel-line"></div>
                    <p>Our module efficiently handles half-time, sick, and casual leave, along with holiday management.
</p>
                     </div>
                </div>
              </div>
            </div>
            <div class="tab-con-item" style="display: none;">
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/DRIVER DETAIL.png" alt="Leave Management ERP Software India" width="50" height="50"style="height: 80px;width:80px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Vehicle, Driver Details</div>
                  <div class="text-details">Our module showcases a comprehensive list featuring vehicle number, maximum seat allocation, insurance renewal date, contact number, and driver details.
</div>
                  <div class="mask non">
                    <h2>Vehicle, Driver Details</h2>
                    <div class="titel-line"></div>
                    <p>Our module showcases a comprehensive list featuring vehicle number, maximum seat allocation, insurance renewal date, contact number, and driver details.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/VEHICLE TRACKING.png" alt="Vehicle Driver Tracking ERP Software India" width="60" height="70" style="height: 80px;width:80px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Vehicle Tracking</div>
                  <div class="text-details">Our module employs RFID technology for vehicle tracking.
</div>
                  <div class="mask non">
                    <h2>Vehicle Tracking</h2>
                    <div class="titel-line"></div>
                    <p>Our module employs RFID technology for vehicle tracking.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first"style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/ROUTE DETAIL.png" alt="Cloud base Vehicle Tracking ERP Software India" width="70" height="70" style="height: 80px;width:80px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Route Details</div>
                  <div class="text-details">Our module provides route data along with the driver's name for each designated area.
</div>
                  <div class="mask non">
                    <h2>Route Details</h2>
                    <div class="titel-line"></div>
                    <p>Our module provides route data along with the driver's name for each designated area.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/FEE.png" alt="Route Details ERP System India" width="70" height="70" style="height: 80px;width:80px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Destination and Fees</div>
                  <div class="text-details">Our module efficiently manages the coordination of student and employee pick-up and drop-off, along with the structure of fees.
</div>
                  <div class="mask non">
                    <h2>Destination and Fees</h2>
                    <div class="titel-line"></div>
                    <p>Our module efficiently manages the coordination of student and employee pick-up and drop-off, along with the structure of fees.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/TRANSPORT ALLOCATION.png" alt="" width="70" height="70"style="height: 80px;width:80px"></div>
                  <div class="titel-line" ></div>
                  <div class="titel-text f_size">Transportation Allocation</div>
                  <div class="text-details">Efficiently allocate transportation with specified start and end dates using our module.
</div>
                  <div class="mask non">
                    <h2>Transportation Allocation</h2>
                    <div class="titel-line"></div>
                    <p>Efficiently allocate transportation with specified start and end dates using our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/BOOK CATEGORY.png" alt="" width="70" height="70" style="height: 80px;width:80px"></div>
                  <div class="titel-line" ></div>
                  <div class="titel-text f_size">Book Category</div>
                  <div class="text-details">Effortlessly organize your book category list with our module.
</div>
                  <div class="mask non">
                    <h2>Book Category</h2>
                    <div class="titel-line"></div>
                    <p>Effortlessly organize your book category list with our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/BOOK ISSUE AND RETURN.png" alt="" width="70" height="70"style="height: 80px;width:80px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Book issue and Return</div>
                  <div class="text-details">Simplify the book issue and return process for both teachers and students with our management module.
</div>
                  <div class="mask non">
                    <h2>Book issue and Return</h2>
                    <div class="titel-line"></div>
                    <p>Simplify the book issue and return process for both teachers and students with our management module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/HOSTEL.png" alt="" width="70" height="70"style="height: 70px;width:70px" ></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Hostel Details</div>
                  <div class="text-details">Explore the list of hostel types, student occupancy, residing students count, and cost structure with our module.
</div>
                  <div class="mask non">
                    <h2>Hostel Details</h2>
                    <div class="titel-line"></div>
                    <p>Explore the list of hostel types, student occupancy, residing students count, and cost structure with our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/CANTEEN.png" alt="" width="84" height="83" style="height: 80px;width:80px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Hostel Canteen</div>
                  <div class="text-details">Display the specifics of a typical meal with our module.
</div>
                  <div class="mask non">
                    <h2>Hostel Canteen</h2>
                    <div class="titel-line"></div>
                    <p>Display the specifics of a typical meal with our module.
</p>
                     </div>
                </div>
              </div>
            </div>
            <div class="tab-con-item" style="display: none;">
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/Mnual exam.png" alt="" width="84" height="83" style="height: 80px;width:80px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Manual Examination</div>
                  <div class="text-details">Empower teachers to create manual exam papers and schedule exams for their students using our module.
</div>
                  <div class="mask non">
                    <h2>Manual Examination</h2>
                    <div class="titel-line"></div>
                    <p>Empower teachers to create manual exam papers and schedule exams for their students using our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/Question bank.png" alt="" width="84" height="83" style="height: 80px;width:80px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Question Bank</div>
                  <div class="text-details">Access, upload, and download questions from the question bank effortlessly using our module.
</div>
                  <div class="mask non">
                    <h2>Question Bank</h2>
                    <div class="titel-line"></div>
                    <p>Access, upload, and download questions from the question bank effortlessly using our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/Online exam.png" alt="" width="84" height="83" style="height: 80px;width:80px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Online Examination</div>
                  <div class="text-details">Our module generates subject-specific online exams and provides students with fast results.
</div>
                  <div class="mask non">
                    <h2>Online Examination</h2>
                    <div class="titel-line"></div>
                    <p>Our module generates subject-specific online exams and provides students with fast results.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/Exam time table.png" alt="" width="84" height="83" style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Exam Timetable</div>
                  <div class="text-details">Efficiently display and manage start and end dates for weekly, monthly, and yearly exams with our module.
</div>
                  <div class="mask non">
                    <h2>Exam Timetable</h2>
                    <div class="titel-line"></div>
                    <p>Efficiently display and manage start and end dates for weekly, monthly, and yearly exams with our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/Ranking levels.png" alt="" width="84" height="83" style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Set Grading/ Ranking Levels</div>
                  <div class="text-details">Establish grades and ranking levels based on students' exam performance using our module.
</div>
                  <div class="mask non">
                    <h2>Set Grading/ Ranking Levels</h2>
                    <div class="titel-line"></div>
                    <p>Establish grades and ranking levels based on students' exam performance using our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/Exam reult.png" alt="" width="84" height="83" style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Exam Result</div>
                  <div class="text-details">Easily display and manage exam results with our module.
</div>
                  <div class="mask non">
                    <h2>Exam Result</h2>
                    <div class="titel-line"></div>
                    <p>Easily display and manage exam results with our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/Supervisor.png" alt="" width="84" height="83"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Supervisor and Examiner Management</div>
                  <div class="text-details">Supervisors oversee the list of exams they conduct, while examiners review subject-by-subject papers using our module.
</div>
                  <div class="mask non">
                    <h2>Supervisor and Examiner Management</h2>
                    <div class="titel-line"></div>
                    <p>Supervisors manage the list of exams they conduct, and examiners review the subject-by-subject papers.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/Exam report.png" alt="" width="84" height="83"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Exam Report</div>
                  <div class="text-details">Incorporate student performance in various reports, complete with signatures from teachers and the principal using our module.
</div>    
                  <div class="mask non">
                    <h2>Exam Report</h2>
                    <div class="titel-line"></div>
                    <p>Incorporate student performance in various reports, complete with signatures from teachers and the principal using our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/Class Designation.png" alt="" width="84" height="83"style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Class Designation</div>
                  <div class="text-details">Specify the ranking levels for each individual class using our module.
</div>
                  <div class="mask non">
                    <h2>Class Designation</h2>
                    <div class="titel-line"></div>
                    <p>Specify the ranking levels for each individual class using our module.
</p>
                     </div>
                </div>
              </div>
            </div>
            <div class="tab-con-item" style="display: none;">
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/salary setting.png" alt="" width="84" height="83" style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Salary Setting</div>
                  <div class="text-details">Access employee details, including their designation, pay head, amount type, and unit, all conveniently displayed in our module.
</div>
                  <div class="mask non">
                    <h2>Salary Setting</h2>
                    <div class="titel-line"></div>
                    <p>Access employee details, including their designation, pay head, amount type, and unit, all conveniently displayed in our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/pay head.png" alt="" width="84" height="83"style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Pay Head</div>
                  <div class="text-details">Easily display and manage master date types with our module.
</div>
                  <div class="mask non">
                    <h2>Pay Head</h2>
                    <div class="titel-line"></div>
                    <p>Easily display and manage master date types with our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/pay type.png" alt="" width="84" height="83" style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Pay Type</div>
                  <div class="text-details">Effortlessly view and manage payment type and name entries using our module.
</div>
                  <div class="mask non">
                    <h2>Pay Type</h2>
                    <div class="titel-line"></div>
                    <p>Effortlessly view and manage payment type and name entries using our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/pay sleep.png" alt="" width="84" height="83"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Generate Pay sleep</div>
                  <div class="text-details">Our module generates pay slips and efficiently manages employee reports on a monthly and annual basis.</div>
                  <div class="mask non">
                    <h2>Generate Pay sleep</h2>
                    <div class="titel-line"></div>
                    <p>Our module generates pay slips and efficiently manages employee reports on a monthly and annual basis.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/account managment.png" alt="" width="84" height="83"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Account management</div>
                  <div class="text-details">Efficiently track bank and cash transactions, along with expenses and general vouchers using our module.
</div>
                  <div class="mask non">
                    <h2>Account management</h2>
                    <div class="titel-line"></div>
                    <p>Efficiently track bank and cash transactions, along with expenses and general vouchers using our module.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/fees management.png" alt="Fees ERP Management System India" width="84" height="83" style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Fees Management</div>
                  <div class="text-details">Our module processes school payments, issues fee receipts, and updates the fee register, ensuring highly accurate data.
</div>
                  <div class="mask non">
                    <h2>Fees Management</h2>
                    <div class="titel-line"></div>
                    <p>Our module processes school payments, issues fee receipts, and updates the fee register, ensuring highly accurate data.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/reports.png" alt="" width="84" height="83" style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Reports</div>
                  <div class="text-details">Our module adeptly manages reports, including the Journal Book, Cash/Bank Book, General Ledger, Trial Balance, Balance Sheet, Profit & Loss, and more.
</div>
                  <div class="mask non">
                    <h2>Reports</h2>
                    <div class="titel-line"></div>
                    <p>Our module adeptly manages reports, including the Journal Book, Cash/Bank Book, General Ledger, Trial Balance, Balance Sheet, Profit & Loss, and more.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/master1.png" alt="" width="84" height="83" style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">HR Management</div>
                  <div class="text-details">Our module adeptly manages reports, including the Journal Book, Cash/Bank Book, General Ledger, Trial Balance, Balance Sheet, Profit & Loss, and more.
</div>
                  <div class="mask non">
                    <h2>HR Management </h2>
                    <div class="titel-line"></div>
                    <p>Our module adeptly manages reports, including the Journal Book, Cash/Bank Book, General Ledger, Trial Balance, Balance Sheet, Profit & Loss, and more.
</p>
                     </div>
                </div>
              </div>
              <div class="col-lg-4 col-md-12 view-clo">
                <div class="view view-first" style="margin-bottom: 15px;">
                  <div class="icon-div"><img src="images/intro_sec/3rd/master.png" alt="" width="84" height="83" style="height: 70px;width:70px"></div>
                  <div class="titel-line"></div>
                  <div class="titel-text f_size">Masters</div>
                  <div class="text-details">Our system efficiently manages Account Master, Expense Master, Bank/Cash Master, Tax Master, and other essential components.
</div>
                  <div class="mask non">
                    <h2>Masters</h2>
                    <div class="titel-line"></div>
                    <p >Our system efficiently manages Account Master, Expense Master, Bank/Cash Master, Tax Master, and other essential components.
</p>
                     </div>
                </div>
              </div>
            </div>
            
            <!--<div class="clearfix"></div>--> 
          </div>
        </div>
        <div class="clearfix"></div>
        <div class="prev_next_row pdt-30 pdb-30" style="text-align: center;"> 
          <a id="prev" class="prev_btn" style="width: 36px;height: 36px;background: #755fdb;color: #fff;display: inline-block;font-size: 22px;line-height: 34px;text-align: center;" href="javascript:void(0);"><i class="fa fa-angle-left" aria-hidden="true"></i></a>

          <a id="next" class="next_btn" style="width: 36px;height: 36px;background: #755fdb;color: #fff;display: inline-block;font-size: 22px;line-height: 34px;text-align: center;"href="javascript:void(0);"><i class="fa fa-angle-right" aria-hidden="true"></i></a> </div>
      </div>
    </div>
    <!-- Row End --> 
  </div>
  <!-- container --> 
</section>

<style>
  @media (max-width: 740px){
  .view-clo{
    width:33%;
  }
  .tab-con-item .view-clo .icon-div {
    width: 60px;
    height: 60px;   
}
.titel-text {
    font-size: 10px !important;
}

.tab-con-item .text-details,.non{
  display:none;
}
@media (max-width: 700px){
.titel-text {
  /*  font-size: 9px !important;
    line-height: 2 !important;*/
}
.tab-con-item .view {
   
    padding: 10px 2px 0px 2px;
    height: 150px;
    overflow: hidden;
    position: relative;
    text-align: center;
    background-color: #D5CFF4 !important;
    border-radius: 20px;
    background: #fff;
}
.f_size{
  font-size: 11px !important;
    line-height: 10px !important;
}
} 
</style>	<!-- intro section end -->

	<!-- fact and figure start-->
	
<section class="feature-section pdt-30 pdb-80  bg-silver-light bg-no-repeat" data-background="images/bg/abs-bg5.webp">
    <div class="container">
      <h1 class="" style="padding:30px 0px; text-align: center;">Fact and </span>Figures</h1>
    <div class="row" style="justify-content:space-between;">
        <div class="four col-md-3 mrb-15" >
            <div class="counter-box colored"> <i class="fa-solid fa-school"></i> <span class="counte">1000</span><span>+</span>
                <p style="text-align: center;font-size: 30px;font-weight: 600;">Schools</p>
            </div>
        </div>
        <div class="four col-md-3 mrb-15">
            <div class="counter-box colored"> <i class="fa-solid fa-chalkboard-user"></i> <span class="counte">4000</span><span>+</span>
                <p style="text-align: center;font-size: 30px;font-weight: 600;">Teachers</p>
            </div>
        </div>
        <div class="four col-md-3 mrb-15">
            <div class="counter-box colored"> <i class="fa-solid fa-child"></i> <span class="counte">100000</span><span>+</span>
                <p style="text-align: center;font-size: 30px;font-weight:600;">Students</p>
            </div>
        </div>
        <div class="four col-md-3 mrb-15">
            <div class="counter-box colored"> <i class="fa-solid fa-handshake-simple"></i> <span class="counte">25</span><span>+</span>
                <p style="text-align: center;font-size: 30px;font-weight: 600;">Distributor</p>
            </div>
        </div>
    </div>
</div>
<script>
    
    $('.counte').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 6000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});
</script>
<style >
  .container {
/*    margin-top: 100px*/
}


.counter-box {
    display: block;
    color:#7660db;
/*    box-shadow: 4px 4px 4px 0px rgba(0, 0, 0, 0.25) inset;*/
    background: crimson;
    padding: 40px 20px 37px;
    text-align: center;
    border-radius: 30px;
}

.counter-box p {
    margin: 5px 0 0;
    padding: 0;
    color: #909090;
    font-size: 18px;
    font-weight: 500
}

.counter-box i {
    font-size: 60px;
    margin: 0 0 15px;
    color: #d2d2d2;
}

.counte {
    display: block;
    font-size: 32px;
    font-weight: 700;
    color: #666;
    line-height: 28px;
}

.counter-box.colored {
    background: #D5CFF4;
}

.counter-box.colored p,
.counter-box.colored i,
.counter-box.colored .counte {
    color: #755fdb;
}
.counte-box i {
    font-size: 60px;
/*    margin: 0 0 15px;*/
/*    color: #d2d2d2;*/
}


@media (max-width: 767px){

     .row{
/*        justify-content: space-;*/
     }
     .four{
        width:195px;
     }
    .counter-box {
    display: block;
    color:#7660db;
/*    box-shadow: 4px 4px 4px 0px rgba(0, 0, 0, 0.25) inset;*/
    padding: 10px 0px 10px 0px;
    text-align: center;
    border-radius: 30px;
}

.counter-box p {
    margin: 5px 0 0;
    padding: 0;
    font-size: 5px;
    font-weight: 400
}

.counter-box i {
    font-size: 50px;
    margin: 0 0 15px;

}

.counte {
    display: block;
    font-size: 17px;
    font-weight: 700;
    line-height: 20px;
}


.counte-box i {
    font-size: 60px;

}
.counter-box.colored p{
    font-size: 17px !important;
}
}
@media (max-width: 740px){
    .four{
        width:180px;
     }
}
</style>


</section>


	<!-- fact and figure end-->

	<!--  about app start-->
	<section id="work-process" class="work-process bg-green">
  <div class="work-bg-pattern d-none d-lg-inline-block"></div>
  <!-- End Work BG Pattern -->
  <div class="container">
    <div class="row text-center pdb-20">
      <div class="col section-heading wow fadeInDown" style="visibility: visible; animation-name: fadeInDown;">
        <h1 class="" style="color: #000;">School ERP App Features</h1>
      </div>
    </div>
    <!-- End Row -->
    <div class="row">
      <div class="col-lg-4 col-md-12 text-right">
        <div class="mobile-app-features wow fadeInLeft " data-wow-duration="1s" style="visibility: visible; animation-duration: 1s; animation-name: fadeInLeft;">
          <div class="mobile-app-features-row">
            <div class="titel-text ">Dashboard Management<img class="img" src="images/app-features-icon-1.png" alt="Academic Management ERP System" title="Academic Management ERP System" width="50" height="50"></div>
            <div class="details-text">Customize and manage different dashboard on different modules.</div>
          </div>
          <div class="mobile-app-features-row">
            <div class="titel-text">Attendance Entry<img class="img" src="images/app-features-icon-2.png" alt="Attendance Management ERP System" title="School Attendance Management ERP System" width="50" height="50"></div>
            <div class="details-text">Manage and view user's attendance with a detailed report.</div>
          </div>
          <div class="mobile-app-features-row">
            <div class="titel-text">Homework Entry<img class="img" src="images/app-features-icon-3.png" alt="Assignment ERP Management System" title="Assignment ERP Management System" width="50" height="50"></div>
            <div class="details-text">Add, View and Check Homework by teachers and students/Parents.</div>
          </div>
          <div class="mobile-app-features-row">
            <div class="titel-text">Fee Management<img class="img" src="images/app-features-icon-4.png" alt="School ERP Finance Management System" title="School ERP Finance Management System" width="50" height="50"></div>
            <div class="details-text">View and Check Fee by students/parents.</div>
          </div>
          <div class="mobile-app-features-row">
            <div class="titel-text">Timetable Entry<img class="img" src="images/app-features-icon-5.png" alt="Timetable Management System" title="Timetable Management System" width="50" height="50"></div>
            <div class="details-text">Automated timetable for every  class and sections.</div>
          </div>
        </div>
      </div>
      <div class="col-lg-4 col-md-12  wow zoomIn mobile2" data-wow-duration="1s" data-wow-delay=".2s" style="visibility: visible; animation-duration: 1s; animation-delay: 0.2s; animation-name: zoomIn;">
        <div class="mobile-app-features-screen mobile1"><img src="images/mobile-app-features-img8.png" alt="android school management software" title="School ERP System India" width="370" height="746"></div>
      </div>
      <div class="col-lg-4 col-md-12 text-left ">
        <div class="mobile-app-features wow fadeInRight" data-wow-duration="1s" style="visibility: visible; animation-duration: 1s; animation-name: fadeInRight;">
          <div class="mobile-app-features-row">
            <div class="titel-text"><img class="img" src="images/app-features-icon-6.png" alt="Cloud ERP Management System" title="Cloud ERP Management System" width="50" height="50">Location View</div>
            <div class="details-text">Separate location entries for students, teachers and other staffs</div>
          </div>
          <div class="mobile-app-features-row">
            <div class="titel-text"><img class="img" src="images/app-features-icon-7.png" alt="Library ERP Management System" title="Library ERP Management System" width="50" height="50">Library Management</div>
            <div class="details-text">To manage available books, its issues and returns </div>
          </div>
          <div class="mobile-app-features-row">
            <div class="titel-text"><img class="img" src="images/app-features-icon-8.png" alt="Vehicle Tracking ERP System" title="Vehicle Tracking ERP System" width="50" height="50">Vehicle Tracking</div>
            <div class="details-text">Parents can be worry-free by tracking their children's vehicle status </div>
          </div>
          <div class="mobile-app-features-row">
            <div class="titel-text"><img class="img"src="images/app-features-icon-9.png" alt="Sms &amp; Notifications ERP System" title="SMS and Notifications ERP System" width="50" height="50">Circular</div>
            <div class="details-text">Ease of communication with Student/Parent</div>
          </div>
          <div class="mobile-app-features-row">
            <div class="titel-text"><img class="img"src="images/app-features-icon-10.png" alt="Student Tracking ERP System" title="Student Tracking ERP System" width="50" height="50">Student Tracking</div>
            <div class="details-text">Parents/Teachers can keep eye on their children activities</div>
          </div>
        </div>
      </div>
    </div>
   
    
    <!-- End Row --> 
  </div>
  <!-- End Container --> 

  <style>
    .work-process {
    z-index: 2;
    padding: 40px 0 40px;
    /*background: url(../images/app-features-main-bg.jpg);*/
    background-repeat: no-repeat;
    background-size: cover;
    background-attachment: fixed;
    background-position: 50% 50%;
}
.mobile-app-features-row .details-text {
    color: #000;
    font-size: 16px;
    line-height: 22px;
/*    font-family: 'robotoregular';*/
 font-: 500;
    margin: 0px;
    padding: 0px;
    text-align: center;
}
.mobile-app-features-row {
    width: auto;
    height: auto;
    margin: 0px 0px 30px 0px;
    padding: 0px;
}
.mobile-app-features-row .titel-text img {
    margin: 0px 8px;
}
img {
    max-width: 100%;
}
.mobile-app-features-row .titel-text {
    color: #000;
    font-size: 20px;
/*    margin: 12px 0px 20px 0px;*//*somu 08/11/2023*/
    padding: 12px 0px;
     font-weight: bold;
/*    font-family: 'robotomedium';*/
/*    line-height: 50px;*//*somu 08/11/2023*/
}
 @media (max-width: 700px) {
   .titel-text{
/*    display: flex;*/
/*    justify-content: center;*/
    font-size: 10px !important;
    margin: 3px 0px 0px 0px ;
/*     line-height: 42px ;*/ 
/*somu 08/11/2023*/
  }
  .mobile-app-features-row .details-text {
    font-size: 13px !important;
  }
  .mobile1{
   /* display: flex;
    justify-content: center;*/
    margin-top:15px;
    height: 218px;
    width:200px;
  }
  .mobile2{
    display: flex;
    justify-content: center;
  }
  .text-left{
/*    padding-top:65px;*/
  }
 .mobile-app-features-row {
  
    margin: 0px 0px 0px 0px;
    
}
.tab-con-item .view {
  border-radius: 6px;
}
body{
  line-height: 16px;
}
.text-right, .mobile2, .text-left{
  max-width: 33%;
}
.img,.details-text{
  display:none;
}
.row {
   
    /* margin-right: 0px !important; 
     margin-left: 0px !important; */
}


 }
 @media(max-width: 400px){
  .mobile-app-features-row .titel-text {
    color: #000;
    font-size: 20px;
/*    margin: 12px 0px 20px 0px;*//*somu 08/11/2023*/
    padding: 9px 0px;
     font-weight: bold;
/*    font-family: 'robotomedium';*/
/*    line-height: 50px;*//*somu 08/11/2023*/
}

 }
  </style>
</section>	<!--  about app end-->

	<!--  about app start-->
	<!-- <section class="contact-section pdt- pdb-70 pdb-lg-90" data-background="images/bg/abs-bg1.png">
		<div class="container">
            <h1 class="" style="padding:30px 0px 30px 0px; text-align: center;">Integration</h1>
			<div class="row mrb-">

                        <div class="col-md-6 how-img">
                            <img src="images/about/partners.jpg" class="rounded-circle img-fluid" alt=""/>
                        </div>
                        <div class="col-md-6">
                            <h4>Whatsapp </h4>
                                        <h4 class="subheading"></h4>
                        <p class="text-muted">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.    </p>
                        </div>
			</div>

<style>
	.how-section1{
    margin-top:-15%;
    padding: 10%;
}
.how-section1 h4{
    color: #ffa500;
    font-weight: bold;
    font-size: 30px;
}
.how-section1 .subheading{
    color: #3931af;
    font-size: 20px;
}
.how-section1 .row
{
/*    margin-top: 10%;*/
}
.how-img 
{
    text-align: center;
}
.how-img img{
    width: 73%;
}
</style>
		</div>
	</section> -->

        <!-- About Section Start -->
    <section class="about-section anim-object pdt-30 pdb-50 pdb-lg-80">
        <div class="container">
            <h1 style="text-align: center;">Integration</h1>
            <div class="row align-items-center">
                <div class="col-md-12 col-xl-6">
                    <div class="about-image-block mrb-lg-60">
                         <img class="img-full" src="images/about/api.png" alt=""> 
                     

                    </div>
                </div>
                <div class="col-md-12 col-xl-6">
                    <h2 class="title-under-line mrb-70">WhatsApp, Biometric, Geo Location, Payment GateWay<br><span class="f-weight-400"></span></h2>
                    <!-- <h5 class="mrb-30 text-primary-color">Trusted Business Consulting Service Provider</h5> -->
                    <p class="mrb-40">Our comprehensive school management software offers a seamless solution for educational institutions, integrating essential features such as WhatsApp and SMS APIs for efficient communication between educators, students, and parents. With biometric authentication, we ensure the utmost security and accountability. Geo-location tracking enhances student safety, allowing administrators to monitor real-time whereabouts. Additionally, our payment gateway simplifies fee collection and financial transactions. This all-in-one platform streamlines school operations, fostering better communication, security, and financial management for a holistic and efficient educational experience. </p>
                    <!--<div class="signature mrb-30"><img src="images/about/signature.webp" alt=""></div>-->
                    <!-- <a href="#" class="cs-btn-one btn-gradient-color btn-lg">Read More</a> -->
                </div>
            </div>

             

           
            
        </div>
        <style type="">
           /* @media(max-width:700px){
                .about-section{
                    padding-top:0px;
                }
            }*/
        </style>
    </section>
    <!-- About Section End -->	<!--  about app end-->
	
	<!-- Feature Section Start -->
	<section class="feature-section pdt-30   bg-silver-light bg-no-repeat" data-background="images/bg/abs-bg5.webp">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-xl-4">
					<div class="feature-box mrb-lg-60">
						<div class="feature-thumb">
							<img class="img-full" src="images/feature/f1.webp" alt="">
						</div>
						<div class="feature-content">
							<div class="title">
								<h3>LIGHTING SPEED</h3>
							</div>
							<div class="para">
								<p>We know that internet access is not always blazing fast so we have made our application as light as possible.<br><br></p>
							</div>
							<div class="link">
								<a href="#"><i class="fas fa-long-arrow-alt-right"></i></a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-xl-4">
					<div class="feature-box mrb-lg-60">
						<div class="feature-thumb">
							<img class="img-full" src="images/feature/f2.webp" alt="">
						</div>
						<div class="feature-content">
							<div class="title">
								<h3>WEB BASED</h3>
							</div>
							<div class="para">
								<p>There is no need to install any kind of software on client machines. School Erp can be accessed from anywhere through internet. </p>
							</div>
							<div class="link">
								<a href="#"><i class="fas fa-long-arrow-alt-right"></i></a>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 col-xl-4">
					<div class="feature-box">
						<div class="feature-thumb">
							<img class="img-full" src="images/feature/f3.webp" alt="">
						</div>
						<div class="feature-content">
							<div class="title">
								<h3>USER FRIENDLY</h3>
							</div>
							<div class="para">
								<p>Just about anyone working knowledge of computers will able to handle School Erp. The whole software is based on simplicity itself.</p>
							</div>
							<div class="link">
								<a href="#"><i class="fas fa-long-arrow-alt-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Feature Section End -->
	
	 <!-- <section class="feature-section pdt-30   bg-silver-light bg-no-repeat" data-background="images/bg/abs-bg5.webp" style="background-image: url(&quot;images/bg/abs-bg5.webp&quot;);">
		<div class="container">

 

			<div class="row">

   <div class="col-md-12 col-xl-12 text-center">             
<h2> Our Features </h2> <br><br>
</div>

				<div class="col-md-12 col-xl-4 text-center service-box2">
				
				     <img class="img-full" src="images/bg/1.webp" alt=""> 
				
					 
                    <h4 class="title2">Conduct Your Student Online Exam With School ERP</h4> -->
                         <!-- somu 31/10/2023 -->
							 
							 <!--<a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>-->
							 
 				<!-- </div>


				<div class="col-md-12 col-xl-4 text-center service-box2">
				
					  <img class="img-full" src="images/bg/2.webp" alt=""> 
                    <h4 class="title2">Examination Software Enabled Payment gateway Feature</h4>  --><!-- somu 31/10/2023 -->
							 
							 <!--<a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>-->
			  <!-- </div>


				<div class="col-md-12 col-xl-4 text-center service-box2">
				
					 <img class="img-full" src="images/bg/3.webp" alt=""> 
                    <h4 class="title2">Send Fee Reminder With Phone Pay Link On WhatsApp/Sms </h4> -->
                    <!-- somu 31/10/2023 --> 
							 
							 <!--<a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>-->
			  <!-- </div>


				<div class="col-md-12 col-xl-4 text-center service-box2">
				
					 <img class="img-full" src="images/bg/4.webp" alt=""> 
                <h4 class="title2">Send Student Report Progress Card WhatsApp/Sms/Email</h4> --> <!-- somu 31/10/2023 -->
							 
							 <!--<a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>-->
			  <!-- </div>


				<div class="col-md-12 col-xl-4 text-center service-box2">
				
					 <img class="img-full" src="images/bg/5.webp" alt=""> 
                  <h4 class="title2">Send Fee Reminder With Dynamic Qr Code WhatsApp/Sms </h4>  --><!-- somu 31/10/2023 -->
							 
							 <!--<a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>-->
			 <!--  </div>


				<div class="col-md-12 col-xl-4 text-center service-box2">
				
					<img class="img-full" src="images/bg/6.webp" alt=""> 
               <h4 class="title2">Send Student Report Progress Card WhatsApp/Sms/Email </h4>  --><!-- somu 31/10/2023 -->
							 
							 <!--<a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>-->
			 <!--  </div>


				<div class="col-md-12 col-xl-4 text-center service-box2">
				
					 <img class="img-full" src="images/bg/7.webp" alt=""> 
                 <h4 class="title2">Fee Collect Using Payment Gateway/ Phonepe/ Qr Code </h4> --><!-- somu 31/10/2023 --> 
							 
							 <!--<a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>-->
			 <!--  </div>


				<div class="col-md-12 col-xl-4 text-center service-box2">
				
					 <img class="img-full" src="images/bg/8.webp" alt=""> 
                    <h4 class="title2">Print Qr Code On Invoice And Fee Reminder </h4>  --><!-- somu 31/10/2023 -->
							 
							 <!--<a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>-->
			  <!-- </div>


  
				<div class="col-md-12 col-xl-4 text-center service-box2">
				
					 <img class="img-full" src="images/bg/9.webp" alt=""> 
                    <h4 class="title2">Accept Payment Via Website and Mobile App</h4>  --><!-- somu 31/10/2023 -->
							 
							 <!--<a class="cs-btn-one btn-gradient-color btn-xs" style="margin-top:10px; margin-bottom:10px;" href="#">ERP Software </a>-->
			  <!-- </div>



			
			</div>
		</div>
	</section> --><!-- somu 31/10/2023 -->
	
	<!-- About Section Start -->
	<section class="about-section anim-object pdt-70 pdb-50 pdb-lg-80">
		<div class="container">
			<div class="row align-items-center">
				
				<div class="col-md-12 col-xl-6">
					<h2 class="title-under-line mrb-70">We have 13+ <br> <span class="f-weight-400">Years Business Experiences</span></h2>
					<h5 class="mrb-30 text-primary-color">Trusted Business Consulting Service Provider</h5>
					<p class="mrb-40">Welcome to School ERP, We are one of the market leading company who provides world-class global service to its associated Clients, also we provide consistent support and help to the Clients in better understanding of our products and services. We are the team of young and passionate people who are ready to face tough challenges on the path of success. </p>
					<!--<div class="signature mrb-30"><img src="images/about/signature.webp" alt=""></div>-->
					<!-- <a href="#" class="cs-btn-one btn-gradient-color btn-lg">Read More</a> -->
				</div>
				<div class="col-md-12 col-xl-6">
					<div class="about-image-block mrb-lg-60">
						 <img class="img-full" src="images/about/3.webp" alt=""> 
					 

					</div>
				</div>
			</div>
			
		</div>
	</section>
	<!-- About Section End -->
	<!-- Service Section Start -->
	
	<!-- Service Section End -->
	<!-- Team Section Titile Start -->
	
	<!-- Team Section Titile End -->
	<!-- Team Section Start -->
	<!-- Team Section End -->
	<!-- Divider Section Start -->
	<!--<section class="pdb-110" data-background="images/bg/3.webp" data-overlay-dark="8">-->
	<!--	<div class="section-content">-->
	<!--		<div class="container">-->
	<!--			<div class="row">-->
	<!--				<div class="col-lg-8">-->
	<!--					<div class="popup-video-block video-popup">-->
	<!--						<img class="img-full d-none d-lg-block" src="images/bg/vid.webp" alt="">-->
	<!--							<a href="#" class="popup-video popup-youtube">-->
	<!--							<i class="webexflaticon flaticon-play-button-2" aria-hidden="true"></i>-->
	<!--							<span class="pulse-animation"></span>-->
	<!--						</a>-->
	<!--					</div>-->
	<!--				</div>-->
	<!--				<div class="col-lg-4 mrb-sm-110">-->
	<!--					<div class="request-a-call-back-form">-->
	<!--						<h3 class="mrt-0 mrb-20 solid-bottom-line">Feel Free to Contact Us</h3>-->
	<!--						<p class="mrb-30"> </p>-->
	<!--						<form action="#">-->
	<!--							<div class="row">-->
	<!--								<div class="col-lg-12">-->
	<!--									<div class="form-group">-->
	<!--										<input type="text" placeholder="Name" class="form-control">-->
	<!--									</div>-->
	<!--								</div>-->
	<!--								<div class="col-lg-12">-->
	<!--									<div class="form-group">-->
	<!--										<input type="text" placeholder="Phone" class="form-control">-->
	<!--									</div>-->
	<!--								</div>-->
	<!--								<div class="col-lg-12">-->
	<!--									<div class="form-group">-->
	<!--										<input type="email" placeholder="Email" class="form-control">-->
	<!--									</div>-->
	<!--								</div>-->
	<!--								<div class="col-lg-12">-->
	<!--									<div class="form-group">-->
	<!--										<select name="categories" class="custom-select-categories" required="">-->
	<!--											<option value="">Choose S Type</option>-->
	<!--											<option>Computer</option>-->
	<!--											<option>Business</option>-->
	<!--											<option>Chemistry</option>-->
	<!--											<option>Physics</option>-->
	<!--											<option>Photoshop</option>-->
	<!--											<option>Management</option>-->
	<!--										</select>-->
	<!--									</div>-->
	<!--								</div>-->
	<!--								<div class="col-lg-12">-->
	<!--									<div class="form-group mrb-0">-->
	<!--										<button type="submit" class="cs-btn-one btn-primary-color btn-md btn-block">Request for Submit</button>-->
	<!--									</div>-->
	<!--								</div>-->
	<!--							</div>-->
	<!--						</form>-->
	<!--					</div>-->
	<!--				</div>-->
	<!--			</div>-->
	<!--		</div>-->
	<!--	</div>-->
	<!--</section>-->
	<!-- Divider Section End -->
	<!-- Case Study Section Start -->
	<!-- <section class="case-study-section anim-object2 pdt-30">
		<div class="section-title">
			<div class="container">
				<div class="row">
					<div class="col-lg-5">
						<div class="section-title-left-part mrb-sm-30">
							<h2 class="title">Mobile App</h2>
						</div>
					</div>
					 
				</div>
			</div>
		</div>
		<div class="section-content">
			<div class="container-fluid">
				<div class="row">
					<div class="owl-carousel project-items-4col long-gap-left">
						<div class="case-study-item">
							<div class="case-study-thumb">
								<img class="img-full" src="images/case-study/1.webp" alt="">
								<div class="case-study-link-icon">
									<a href="#"><i class="webex-icon-attachment1"></i></a>
								</div>
								<div class="case-study-details p-4">
									<h6 class="case-study-category side-line mrb-5">Consulting</h6>
									<h4 class="case-study-title">Business Solution</h4>
								</div>
							</div>
						</div> --><!-- somu 1/11/2023 -->
						<!-- <div class="case-study-item">
							<div class="case-study-thumb">
								<img class="img-full" src="images/case-study/2.webp" alt="">
								<div class="case-study-link-icon">
									<a href="#"><i class="webex-icon-attachment1"></i></a>
								</div> --><!-- somu 1/11/2023 -->
								<!--<div class="case-study-details p-4">
									<h6 class="case-study-category side-line mrb-5">Consulting</h6>
									<h4 class="case-study-title">Business Solution</h4>
								</div>-->
							<!-- </div>
						</div> --><!-- somu 1/11/2023 -->
						 
						 <!-- <div class="case-study-item">
							<div class="case-study-thumb">
								<img class="img-full" src="images/case-study/4.webp" alt="">
								<div class="case-study-link-icon">
									<a href="#"><i class="webex-icon-attachment1"></i></a>
								</div> --><!-- somu 1/11/2023 -->
								<!--<div class="case-study-details p-4">
									<h6 class="case-study-category side-line mrb-5">Consulting</h6>
									<h4 class="case-study-title">Business Solution</h4>
								</div>-->
							<!-- </div>
						</div><div class="case-study-item">
							<div class="case-study-thumb">
								<img class="img-full" src="images/case-study/5.webp" alt="">
								<div class="case-study-link-icon">
									<a href="#"><i class="webex-icon-attachment1"></i></a>
								</div> --><!-- somu 1/11/2023 -->
								<!--<div class="case-study-details p-4">
									<h6 class="case-study-category side-line mrb-5">Consulting</h6>
									<h4 class="case-study-title">Business Solution</h4>
								</div>-->
							<!-- </div>
						</div><div class="case-study-item">
							<div class="case-study-thumb">
								<img class="img-full" src="images/case-study/6.webp" alt="">
								<div class="case-study-link-icon">
									<a href="#"><i class="webex-icon-attachment1"></i></a>
								</div> --><!-- somu 1/11/2023 -->
								<!--<div class="case-study-details p-4">
									<h6 class="case-study-category side-line mrb-5">Consulting</h6>
									<h4 class="case-study-title">Business Solution</h4>
								</div>-->
							<!-- </div>
						</div><div class="case-study-item">
							<div class="case-study-thumb">
								<img class="img-full" src="images/case-study/7.webp" alt="">
								<div class="case-study-link-icon">
									<a href="#"><i class="webex-icon-attachment1"></i></a>
								</div> --><!-- somu 1/11/2023 -->
								<!--<div class="case-study-details p-4">
									<h6 class="case-study-category side-line mrb-5">Consulting</h6>
									<h4 class="case-study-title">Business Solution</h4>
								</div>-->
							<!-- </div>
						</div><div class="case-study-item">
							<div class="case-study-thumb">
								<img class="img-full" src="images/case-study/8.webp" alt="">
								<div class="case-study-link-icon">
									<a href="#"><i class="webex-icon-attachment1"></i></a>
								</div> --><!-- somu 1/11/2023 -->
								<!--<div class="case-study-details p-4">
									<h6 class="case-study-category side-line mrb-5">Consulting</h6>
									<h4 class="case-study-title">Business Solution</h4>
								</div>-->
							<!-- </div>
						</div>
						 
					</div>
				</div>
			</div>
		</div>
	</section> --> <!-- somu 1/11/2023 -->
	<!-- Case Study Section End -->
	<!-- testimonials start -->

	<!-- testimonials end -->

	<!-- Clients Section Start -->

	<section class="pdt-0 pdb-0">
		<div class="section-content">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
					<h1 align="center" >Our Clients </h1>
						<div class="owl-carousel client-items">
		
							<div class="client-item">
								<img src="images/nclients/1.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/2.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/3.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/4.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/5.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/6.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/7.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/8.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/9.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/10.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/11.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/12.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/13.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/14.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/15.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/16.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/17.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/18.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/19.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/20.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/21.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/22.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/23.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/24.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/25.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/26.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/27.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/28.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/29.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/30.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/31.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/32.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/33.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/34.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/35.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/36.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/37.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/38.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/39.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/40.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/41.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/42.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/43.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/44.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/45.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/46.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/47.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/48.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/49.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/50.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/51.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/52.png" alt="">
							</div>
							<div class="client-item">
								<img src="images/nclients/53.png" alt="">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<style>
			@media (max-width: 740px){
				.owl-carousel .owl-item img {
                     display: block;
                     width: 40%;
                    margin: 0 auto;
                   }
			}
		</style>
	</section>
	
	
	<!-- Clients Section End -->
	<!-- News Section Start -->
	<!--<section class="bg-silver-light pdt-30 pdb-80" data-background="images/bg/abs-bg4.webp">
		<div class="section-title mrb-30 mrb-md-60">
			<div class="container">
				<div class="row">
					<div class="col-lg-8 col-xl-6">
						<h5 class="mrb-15 text-primary-color sub-title-side-line">News And Updates</h5>
						<h2 class="mrb-30">Let's Checkout our All Latest News</h2>
					</div>
					<div class="col-lg-4 col-xl-6 align-self-center text-left text-lg-right">
						<a href="#" class="cs-btn-one btn-gradient-color btn-md">All News</a>
					</div>
				</div>
			</div>
		</div>
		<div class="section-content">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-lg-6 col-xl-4">
						<div class="news-wrapper mrb-30 mrb-sm-40">
							<div class="news-thumb">
								<img class="img-full" src="images/news/01.webp" alt="">
								<div class="news-top-meta">
									<span class="entry-category">Business</span>
								</div>
							</div>
							<div class="news-details">
								<div class="news-description mb-20">
									<h4 class="the-title mrb-30"><a href="#">Tech Entrepreneur Credits Paper For Success</a></h4>
									<div class="news-bottom-meta">
										<span class="entry-date mrr-20"><i class="far fa-calendar-alt mrr-10 text-primary-color"></i>01 Jan, 2020</span>
										<span class="entry-author"><i class="far fa-user mrr-10 text-primary-color"></i>Admin</span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-lg-6 col-xl-4">
						<div class="news-wrapper mrb-30 mrb-sm-40">
							<div class="news-thumb">
								<img class="img-full" src="images/news/02.webp" alt="">
								<div class="news-top-meta">
									<span class="entry-category">Business</span>
								</div>
							</div>
							<div class="news-details">
								<div class="news-description mb-20">
									<h4 class="the-title mrb-30"><a href="#">Tech Entrepreneur Credits Paper For Success</a></h4>
									<div class="news-bottom-meta">
										<span class="entry-date mrr-20"><i class="far fa-calendar-alt mrr-10 text-primary-color"></i>01 Jan, 2020</span>
										<span class="entry-author"><i class="far fa-user mrr-10 text-primary-color"></i>Admin</span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-lg-6 col-xl-4">
						<div class="news-wrapper mrb-30 mrb-sm-40">
							<div class="news-thumb">
								<img class="img-full" src="images/news/03.webp" alt="">
								<div class="news-top-meta">
									<span class="entry-category">Business</span>
								</div>
							</div>
							<div class="news-details">
								<div class="news-description mb-20">
									<h4 class="the-title mrb-30"><a href="#">Tech Entrepreneur Credits Paper For Success</a></h4>
									<div class="news-bottom-meta">
										<span class="entry-date mrr-20"><i class="far fa-calendar-alt mrr-10 text-primary-color"></i>01 Jan, 2020</span>
										<span class="entry-author"><i class="far fa-user mrr-10 text-primary-color"></i>Admin</span>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>-->
	<!-- News Section End -->
	<!-- Testimonials Section Start -->
	<!--<section class="request-a-call-back pdt-80 pdb-110 pdb-lg-70" data-background="images/bg/abs-bg7.webp">
		<div class="section-title text-center wow fadeInUp" data-wow-delay="0ms" data-wow-duration="1500ms">
			<div class="container">
				<div class="row">
					<div class="col"></div>
					<div class="col-lg-8">
						<div class="title-box-center">
							<h5 class="shadow-text">Reviews</h5>
							<h5 class="sub-title-center text-primary-color line-top-center mrb-30">Testimonials</h5>
							<h2 class="title">What People and Clients Think About Us?</h2>
						</div>
					</div>
					<div class="col"></div>
				</div>
			</div>
		</div>
		<div class="section-content">
			<div class="container">
				<div class="row">
					<div class="owl-carousel testimonial-items-2col mrb-lg-40">
						<div class="testimonial-item">
							<span class="quote-icon fas fa-quote-right"></span>
							<div class="testimonial-thumb">
								<img src="images/testimonials/testimonial-img1.webp" alt="">
							</div>
							<h4 class="client-name">Aurther Maxwell</h4>
							<h6 class="client-designation">CEO, Apple Inc.</h6>
							<div class="testimonial-content">
								<p class="comments">Lorem ipsum dolor sit amet, consectetur adipisicing elit oluptatibus blanditiis amet optio fugiat nisi est repellendus iusto quis harum laboriosam nostrum unde distinctio</p>
								<ul class="star-rating">
									<li><i class="webex-icon-star-full text-primary-color"></i></li>
									<li><i class="webex-icon-star-full text-primary-color"></i></li>
									<li><i class="webex-icon-star-full text-primary-color"></i></li>
									<li><i class="webex-icon-star-half text-primary-color"></i></li>
									<li><i class="webex-icon-star-empty text-primary-color"></i></li>
								</ul>
							</div>
						</div>
						<div class="testimonial-item">
							<span class="quote-icon fas fa-quote-right"></span>
							<div class="testimonial-thumb">
								<img src="images/testimonials/testimonial-img2.webp" alt="">
							</div>
							<h4 class="client-name">Aurther Maxwell</h4>
							<h6 class="client-designation">CEO, Apple Inc.</h6>
							<div class="testimonial-content">
								<p class="comments">Lorem ipsum dolor sit amet, consectetur adipisicing elit oluptatibus blanditiis amet optio fugiat nisi est repellendus iusto quis harum laboriosam nostrum unde distinctio</p>
								<ul class="star-rating">
									<li><i class="webex-icon-star-full text-primary-color"></i></li>
									<li><i class="webex-icon-star-full text-primary-color"></i></li>
									<li><i class="webex-icon-star-full text-primary-color"></i></li>
									<li><i class="webex-icon-star-half text-primary-color"></i></li>
									<li><i class="webex-icon-star-empty text-primary-color"></i></li>
								</ul>
							</div>
						</div>
						<div class="testimonial-item">
							<span class="quote-icon fas fa-quote-right"></span>
							<div class="testimonial-thumb">
								<img src="images/testimonials/testimonial-img3.webp" alt="">
							</div>
							<h4 class="client-name">Aurther Maxwell</h4>
							<h6 class="client-designation">CEO, Apple Inc.</h6>
							<div class="testimonial-content">
								<p class="comments">Lorem ipsum dolor sit amet, consectetur adipisicing elit oluptatibus blanditiis amet optio fugiat nisi est repellendus iusto quis harum laboriosam nostrum unde distinctio</p>
								<ul class="star-rating">
									<li><i class="webex-icon-star-full text-primary-color"></i></li>
									<li><i class="webex-icon-star-full text-primary-color"></i></li>
									<li><i class="webex-icon-star-full text-primary-color"></i></li>
									<li><i class="webex-icon-star-half text-primary-color"></i></li>
									<li><i class="webex-icon-star-empty text-primary-color"></i></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>-->
	<!-- Testimonials Section End -->
	<!-- Footer Area Start -->

	
	 <!-- GetButton.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            call: "+919893070156", // Call phone number
            whatsapp: "+919893070156", // WhatsApp number
            call_to_action: "Message us", // Call to action
            button_color: "#FF6550", // Color of button
            position: "left", // Position may be 'right' or 'left'
            order: "whatsapp,call", // Order of buttons
        };
        var proto = 'https:', host = "getbutton.io", url = proto + '//static.' + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /GetButton.io widget -->


<!-- Footer Area Start -->
	<footer class="footer">
		<div class="footer-main-area" data-background="images/footer-bg.png">
			<div class="container">
				<div class="row">
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
						<!--	<img src="images/footer_logo.png" alt="" class="mrb-20">-->
							<address class="mrb-25">
								<p class="text-light-gray">D-326 New Minal,
Near Gate No.5, Bhopal <br/>Madhya Pradesh, INDIA.</p>
								<div class="mrb-10"><a href="#" class="text-light-gray"><i class="fas fa-phone-alt mrr-10"></i>+91 98930-70156 </a></div>
								<div class="mrb-10"><a href="#" class="text-light-gray"><i class="fas fa-envelope mrr-10"></i>info@schoolerpindia.com </a></div>
								<div class="mrb-0"><a href="#" class="text-light-gray"><i class="fas fa-globe mrr-10"></i>www.schoolerpindia.com</a></div>
							</address>
							<ul class="social-list">
								<li><a href= "https://www.facebook.com/schoolerps/" target="_blank"><i class="fab fa-facebook-f"></i></a></li>
								<!-- <li><a href="#"><i class="fa-brands fa-linkedin-in" target="_blank"></i></a></li> -->
								<li><a href="https://www.instagram.com/school_erp_india/" target="_blank"><i class="fab fa-instagram"></i></a></li>
								<li><a href="https://www.youtube.com/@schoolerpindia" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
							</ul>
						</div>
					</div>
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30"> School Solutions </h5>
							<ul class="footer-widget-list">
	 <li > <a   href="admission-management.php"> Online Admission / Enrollment</a> </li>
 <li ><a   href="student-management.php">Student Management</a> </li>
 <li ><a   href="fees-management.php">Fees Management</a> </li>
<li ><a   href="progress-card.php">Progress Card</a> </li>
<li ><a   href="alumni_management.php">Alumni Management  </a> </li>
							</ul>
						</div>
					</div>
					<!--<div class="col-xl-2 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Services</h5>
							<ul class="footer-widget-list">
								<li><a href="#">Home</a></li>
								<li><a href="#">About</a></li>
								<li><a href="#">Team</a></li>
								<li><a href="#">Service</a></li>
								<li><a href="#">News</a></li>
								<li><a href="#">Policy</a></li>
								<li><a href="#">Contact</a></li>
							</ul>
						</div>
					</div>
					<div class="col-xl-4 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Newsletter</h5>
							<p class="text-light-gray">Seamlessly visualize quality intellectual capital without superior collaboration and idea sharing listically</p>
							<input type="text" class="form-control" placeholder="Enter Your Email">
							<a href="#" class="cs-btn-one btn-gradient-color btn-sm has-icon mrt-20"><i class="webexflaticon flaticon-send"></i>Submit Now</a>
						</div>
					</div>-->
					
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30">Integrations</h5>
							<ul class="footer-widget-list">
								<li > <a   href="attendance-machine.php"> Attendance Machine  </a> </li>
<li ><a   href="payment-gateway.php">Payment Gateway </a> </li>
<li ><a   href="fee-via-dynamic-qr-code.php">Fee Via Dynamic QR Code   </a> </li>
<li ><a   href="sms-gateway.php">SMS/Whatsup Gateway  </a> </li>
<li ><a   href="googlemeet-zoom.php">Google Meet/Zoom/Webex</a> </li>
							</ul>
						</div>
					</div>
					
					<div class="col-xl-3 col-lg-6 col-md-6">
						<div class="widget footer-widget">
							<h5 class="widget-title text-white mrb-30"> Our Services</h5>
							<ul class="footer-widget-list">
							<li><a href="dynamic_website.php">Dynamic Website</a></li>
								 
<li ><a   href="student-app.php">Student App</a> </li>
<li ><a   href="teacher-app.php">Teacher App</a></li>
<li ><a   href="admin-app.php">Admin App</a></li>
<li ><a   href="student-web-login.php">Student Web Login</a></li>
							</ul>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<div class="footer-bottom-area">
			<div class="container">
				<div class="row">
					<div class="col-xl-12">
						<div class="text-center">
							<span class="text-light-gray" style="float: left;" >Copyright � 2021 by <a class="text-primary-color" target="_blank" href="#"> School ERp India</a> | All rights reserved    </span>
			
			 <a class="text-primary-color" style="float: right;color: white;"    href="privace-policy.php"> 
      Privacy Policy | Terms of Service | Refund & Cancellation 
 </a>
			 
						</div>
						
						
						
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer Area End --> 
	
	<!-- Footer Area End -->
	<!-- BACK TO TOP SECTION -->
	<div class="back-to-top bg-gradient-color">
		<i class="fab fa-angle-up"></i>
	</div>
	<!-- Integrated important scripts here -->
	<script src="js/jquery.v1.12.4.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery-core-plugins.js"></script>
	<script src="js/main.js"></script>
	
	<script type="text/javascript">


    var slides = document.querySelectorAll(".slide");
var dots = document.querySelectorAll(".dot");
var index = 0;


function prevSlide(n){
  index+=n;
  console.log("prevSlide is called");
  changeSlide();
}

function nextSlide(n){
  index+=n;
  changeSlide();
}

changeSlide();

function changeSlide(){
    
  if(index>slides.length-1)
    index=0;
  
  if(index<0)
    index=slides.length-1;
  
  
  
    for(let i=0;i<slides.length;i++){
      slides[i].style.display = "none";
      
      dots[i].classList.remove("active");
      
      
    }
    
    slides[index].style.display = "block";
    dots[index].classList.add("active");

  

}



	
	</script>
<!-- intro_sec js start -->
<script src="js/somu_main2.js"></script> 
<script src="js/somu_rTabs2.js" type="text/javascript"></script> 
<script type="text/javascript">
            $(function() {
                $("#tabauto").rTabs({
                    bind : 'hover',
                    defaultShow:true,
                    auto: false
                });
        
        $("#tab").rTabs();
        
        $("#tab2").rTabs({
                    bind : 'click',
                    animation : 'left'
                });

               $("#gallery").rTabs({
                    bind : 'hover'
                    /*animation : 'fadein'*/
                });
            })
</script> <!-- WhatsHelp.io widget-->
<!-- intro_sec js end -->





</script>

</body>

</html>